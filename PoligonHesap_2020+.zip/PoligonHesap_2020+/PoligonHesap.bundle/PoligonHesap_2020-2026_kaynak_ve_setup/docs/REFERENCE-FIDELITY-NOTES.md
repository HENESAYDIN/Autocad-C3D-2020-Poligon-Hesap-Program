# Reference fidelity notes

## User sources

- Shared conversation supplied by user: https://chatgpt.com/share/6abf5422-91c0-83eb-9c1c-4117474d49a7
- User upload: `/home/ubuntu/upload/polhesap.zip`
- Extracted source root: `/home/ubuntu/work/polhesap/pol hesap/`
- Reference video: `/home/ubuntu/work/polhesap/pol hesap/ekran kayıtları/dayalı poligon.mp4`
- VBA source extraction: `/home/ubuntu/work/polhesap/Pol2020_vba_dump.txt`
- Actual generated examples: `/home/ubuntu/work/polhesap/pol hesap/programın ürettiği dosyalar/Özet Karne Çıktı/`

## Video-observed application flow

- Main form title is `Poligon Hesabı AutoCAD®2020 - TXT Veri Akışı`.
- Main window places calculation/profile and precision choices on the left, project/operator/date metadata in the center, route-control fields and a two-column `Noktalar / Hesap Raporu` status list on the right.
- Route fields are `Şehir/Kasaba Adı`, `Güzergah No`, `Semt Alınan`, `Başlangıç`, `Son`, and `Semt Kapanan`.
- Calculation modes are closed, tied (`Dayalı`), and open; profile choices include BÖHYY 2025, BÖHYY 2018, and Dizi Nirengi BÖHYY 2018; precision includes cm and mm.
- Button sequence shown: `Veri Girişi`, `Nokta Al`, `Rasat Karne`, `Özet Karne`, `Güzergah`, `Veri Kontrolü`, `Hesap`, `Hesap Raporu`, `Kanava Çiz`, `Excel'e Aktar`, `Yardım`, `Çıkış`.
- Report window has four tabs: `Hesap Karne`, `Açı Ölçümü`, `Kenar Ölçümü`, `Koordinat Liste`; each has copy-to-clipboard behavior and a visible output-file path.
- CAD view shows a 100 m coordinate grid, boundary, coordinate labels, cyan traverse line, control/new point labels and a separate calculation table to the right.
- The Excel frame at 00:02:17 shows the generated workbook being opened; the actual workbook example is the stronger formatting source.

## Verified output examples

### TXT

Dayalı sample output set in `Özet Karne Çıktı/dayalı pol/`:
- `PoligonHesap_1.txt` (legacy fixed-width table with metadata, alternating point/measurement rows, closure summary and two attribution lines)
- `PoligonAçı_1.txt`
- `PoligonKenar_1.txt`
- `PoligonKoord_1.txt`

The samples are CRLF, ISO-8859/Windows-1254-style text. Report labels and fixed-width column order must be retained; use the route number in filenames.

### Excel

`dayalı pol/Kitap1.xlsx` is the Dayalı-style example. It has three sheets: `Koordine.Özet`, `Hesap.Karne`, and empty `Sayfa1`. The first sheet has 13 merged ranges and styles the coordinate summary; the second has 13 merged ranges and styles the interleaved traverse calculation table plus closure summary. The workbook is 14,167 bytes. `Kitap2.xlsx` is a second route example with the same sheets and style IDs.

Other mode examples exist at:
- `açık pol/AcikPoligon_a3.xlsx` (two styled sheets)
- `kapalı pol/PoligonHesap_k1.xlsx` (three styled sheets including `Poligon Kenar`)

### DXF

Dayalı DXF examples: `PoligonKanava_1.dxf` and `PoligonKanava_11.dxf`. They are AutoCAD R11/R12 (`AC1009`) ASCII DXF. The first sample contains 23 LINE, 36 TEXT, 9 POINT and 1 CIRCLE entities and uses layers including `PH_Limit`, `PH_GYazi`, `PH_Yazi`, `PH_Grid`, `PH_EskiPol`, `PH_PolAdi`, `PH_PolKot`, `PH_YeniPol`, `PH_Guzg`. It has a 100 m grid, coordinates in drawing X=stored Y and drawing Y=stored X, scale label `1:1000`, route-title/metadata, control-point labels/elevations, new-point labels and direction glyphs.

## Source-derived behavior

- VBA importer formats: point row `Name Y X [Z]`; Rasat row `Station Target Face1 Face2 HorizontalDistance`; summary row `Name Angle [Distance]`.
- File dialogs in VBA accept TXT/NCN, XLS/XLSX, and CSV for point/Rasat/summary inputs.
- Original output folder is `Özet Karne Çıktı`; report and DXF filenames include route number, e.g. `PoligonKanava_1.dxf`.
- `PoligonTabloOrtak.bas` defines the report table width as 125 drawing units and the nine logical columns, with header/title/metadata, coordinate/angle/edge fields and error summaries. `PT_CreateTableDrwgExact` creates the tied-polygon table at a user-selected point.

## Known validation boundary

This Sandbox can compile against the supplied AutoCAD 2020 managed reference DLLs and run core regression tests, but it does not host AutoCAD 2020. A final visual/runtime check of the DWG drawing and WinForms interaction must be done in the user's AutoCAD 2020 environment.
