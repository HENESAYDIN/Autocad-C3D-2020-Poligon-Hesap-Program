# AutoCAD / Civil 3D 2018–2026 uyumluluk matrisi

**Araştırma tarihi:** 3 Ekim 2026. Bu tablo Autodesk’in yayınladığı managed API/runtime rehberlerini ve ürün update/build tablolarını temel alır. `Series` eşlemesi AutoCAD release-number tablosundandır; Civil 3D’ye aynı AutoCAD release series uygulanması AutoCAD-based product yapısına dayalıdır ve gerçek hostta doğrulanmalıdır.

## Runtime ve profile hedefleri

| Yıl/ürün | Autodesk release series | Runtime hedefi | Installer davranışı |
|---|---|---|---|
| AutoCAD/Civil 3D 2018 | R22.0 | .NET Framework 4.6 | Release başına DLL |
| AutoCAD/Civil 3D 2019 | R23.0 | .NET Framework 4.7 | Release başına DLL |
| AutoCAD/Civil 3D 2020 | R23.1 | .NET Framework 4.7 | Release başına DLL |
| AutoCAD/Civil 3D 2021 | R24.0 | .NET Framework 4.8 | Release başına DLL |
| AutoCAD/Civil 3D 2022 | R24.1 | .NET Framework 4.8 | Release başına DLL |
| AutoCAD/Civil 3D 2023 | R24.2 | .NET Framework 4.8 | Release başına DLL |
| AutoCAD/Civil 3D 2024 | R24.3 | .NET Framework 4.8 | Release başına DLL |
| AutoCAD 2025 | R25.0 | .NET 8 through Update 1.3; .NET 10 from 1.4 | `AutoCAD` platformunda runtime başına ayrı bundle |
| Civil 3D 2025 | R25.0 | .NET 8; 2025 .NET 10 update cutoff yayınlanmış değil | Yalnız bilinen C3D build listesi allowlist’te |
| AutoCAD 2026 | R25.1 | .NET 8 through Update 1.1; .NET 10 from 1.2 | `AutoCAD` platformunda runtime başına ayrı bundle |
| Civil 3D 2026 | R25.1 | .NET 8 through Update 2.2.1; .NET 10 from 2.2.2 | `Civil3D` platformunda runtime başına ayrı bundle |

**Installer’ın neden birden çok bundle ürettiği:** Autodesk `RuntimeRequirements` release `Series` ve `Platform` filtreleri sunar, ancak aynı release içindeki minor update seviyesini filtrelemez. Bu yüzden 2025/2026 için yalnız yıllık series’e bakan tek manifest eski .NET 8 hostuna .NET 10 DLL’i yükleyebilir. Tek Setup.exe, Windows Registry’deki `ProductInfo` update/build bilgisine göre yalnız doğru `.bundle` alt klasörünü kurar.

## Ürün/update build sınırları

- AutoCAD 2025: Autodesk .NET 10 geçişi Update 1.4+ için bildirilmiştir; önceki .NET 8 update sınırı 1.3’tür. Autodesk update notlarındaki ProductInfo/BuildVer eşiklerinde 2025.1.3 için `V.171.0.0`, 2025.1.4 için `V.189.0.0` kullanılır. 1.4 için Registry değeri gerçek Windows makinede doğrulanmalıdır.
- AutoCAD 2026: Autodesk geçiş duyurusu Update 1.2+ .NET 10’u işaret eder. Autodesk build tablosu Update 1.1’i `W.164.0.0`, Update 1.2’yi `W.179.0.0` olarak listeler.
- Civil 3D 2025: Autodesk API kılavuzu .NET 8’i anlatır. 16 Eylül 2026 tarihli Autodesk .NET 10 gereksinim sayfası 2025.2.6’yı son ilgili update olarak listeler ve .NET 10 güncellemelerini planlanan/koordineli update’ler olarak belirtir; released .NET 10 geçiş update numarası belirtilmez. Bu nedenle kaynakta 2025 C3D .NET 10 profile’ı uydurulmamış, yalnız bilinen .NET 8 build’leri kabul edilmiştir.
- Civil 3D 2026: Autodesk geçiş gereksinim sayfası `2026.2.2` update’ini ister. Resmî build tablosunda 2026.2.1 `13.8.1704.0`, 2026.2.2 `13.8.1809.0` olarak görünür. Registry update-key algılaması hostta doğrulanmalıdır.
- Aynı bilgisayardaki birden fazla Autodesk ürününün uyumlu update seviyelerinde tutulması gerekir; Autodesk .NET 10 rehberleri paylaşılan bileşenler/bağımlılıklar için koordineli güncelleme uyarısı verir.

## Build ve doğrulama

[`installer/supported-versions.json`](../installer/supported-versions.json) 14 derleme profilini ve Windows installer seçim kurallarını taşır. Eski sürümler kendi release API’lerine; modern sürümler ürün ve runtime update cohort’una ait API DLL’lerine karşı derlenmelidir. Autodesk host DLL’leri dağıtım paketine kopyalanmaz.

Yerel doğrulamalar: Core regression **73 assertion geçti**; update/runtime seçim testleri **15 assertion geçti**; 14 profilin synthetic PE fixture’larıyla bundle üretimi ve NSIS syntax/build testi başarılı. Ancak Sandbox Linux’ta 2018–2026 Windows Autodesk SDK/host yoktur; gerçek profile DLL’leri ve kullanıcıya verilecek nihai setup burada üretilmiş değildir. Registry detection, build sürümleri, load/komut/çizim/DXF davranışı Windows AutoCAD/Civil 3D hostlarında test edilmelidir.

## Resmî kaynaklar

- [AutoCAD release number ↔ ürün yılı](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/Release-numbers-differ-from-version-year-numbers-in-AutoCAD-products.html)
- [AutoCAD managed .NET compatibility table](https://help.autodesk.com/view/OARX/2025/ENU/?guid=GUID-A6C680F2-DE2E-418A-A182-E4884073338A)
- [AutoCAD 2025 .NET development guidance](https://help.autodesk.com/cloudhelp/2025/ENU/OARX-DevGuide-Managed/files/GUID-450FD531-B6F6-4BAE-9A8C-8230AAC48CB4.htm)
- [AutoCAD 2026 .NET 10 transition notice](https://help.autodesk.com/view/ACD/2026/ENU/?caas=caas%2Fsfdcarticles%2Fsfdcarticles%2FAutoCAD-2026-1-2-and-Toolset-Products-Crashes-After-Updating-To-NET-10-Based-Builds.html)
- [Autodesk AutoCAD product .NET 10 update requirements](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/AutoCAD-and-Toolsets-Requirements-for-products-affected-by-the-Microsoft-NET-10-transition.html)
- [Autodesk general .NET 10 update guidance](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/Autodesk-Products-What-customers-need-to-know-about-Microsoft-NET-10-updates.html)
- [Civil 3D 2025 .NET Core development guide](https://help.autodesk.com/view/CIV3D/2025/ENU/?guid=GUID-E6657034-71E5-4753-8AFD-139DC612B86D)
- [Civil 3D 2026 .NET Core development guide](https://help.autodesk.com/view/CIV3D/2026/ENU/?guid=GUID-E6657034-71E5-4753-8AFD-139DC612B86D)
- [Civil 3D .NET 10 update requirements](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/Civil-3D-Requirements-for-products-affected-by-the-Microsoft-NET-10-transition.html)
- [Civil 3D product build versions](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/How-to-determine-the-Civil-3D-build-version-based-on-Civil-3D-software-release.html)
- [Autodesk registry-based AutoCAD detection](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/What-registry-key-or-system-path-can-be-best-used-to-automatically-detect-AutoCAD-installation-on-a-PC.html)
- [Autodesk ProductInfo BuildVer update-registry example](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/How-to-detect-if-AutoCAD-LT-2020-1-3-has-been-installed-in-the-system-registry.html)
- [AutoCAD update Product Version/Build number table](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/How-to-tie-the-Product-Version-or-Build-number-with-the-AutoCAD-update.html)
- [Autodesk AutoLoader RuntimeRequirements reference](https://help.autodesk.com/view/ACDLTM/2026/ENU/?caas=caas/documentation/ACD/2014/ENU/files/GUID-1591CA01-EF87-48CD-952B-772FE26037F1-htm.html)
