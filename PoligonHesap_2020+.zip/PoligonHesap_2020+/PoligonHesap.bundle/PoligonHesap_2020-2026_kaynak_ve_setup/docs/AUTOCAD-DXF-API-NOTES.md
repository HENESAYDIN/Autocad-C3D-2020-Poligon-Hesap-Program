# AutoCAD DXF API notes

## Sources

- Autodesk, [AutoCAD R12 DXF Reference](https://damassets.autodesk.net/content/dam/autodesk/www/developer-network/platform-technologies/autocad-dxf-archive/acad_r12_dxf.pdf). Used earlier to cross-check group-code structure and handles in the now-retired handwritten writer.
- Autodesk Support, [Saving as R12 DXF format from AutoCAD](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/Save-as-R12-DXF-format-from-AutoCAD.html). Autodesk documents the limitations of R12 output, including removal of newer objects/layout features and proxy objects.
- Autodesk Support, [AutoCAD DXF read error / “Press ENTER to continue”](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/Press-ENTER-to-continue-and-The-following-error-was-encountered-DXF-read-error-when-trying-to-open-a-DXF-file-in-AutoCAD.html).

## Verified local API surface

The supplied AutoCAD 2020 `acdbmgd.dll` (assembly version 23.1) exposes:

```csharp
Database.DxfOut(string fileName, int precision, DwgVersion version)
```

The API metadata defines `DwgVersion.AC1009` (value `0x10`) as the R12/AC1009 format. A small compile probe using `db.DxfOut("x.dxf", 16, DwgVersion.AC1009)` succeeded against the supplied AutoCAD 2020 managed references. The guessed symbolic name `DwgVersion.Acad12` does not exist; use `AC1009`.

The production plugin now builds an isolated AutoCAD `Database`, draws the map in it, calls `UpdateExt(true)`, and invokes this native export overload. A header/EOF check guards the temporary output before it replaces the requested target. The `Database.DxfOut` result itself could not be run or opened in this Linux Sandbox, so Windows AutoCAD verification is still required.
