# DXF Türkçe karakter ve Arial doğrulaması

## 2026-10-03 çoklu sürüm portu durumu

Bu dosyanın altındaki 1.0.4 inceleme, o dönemin 2020/R23.1 teslimatına aittir. Aynı `DxfR12PostProcessor` düzeltmesi 1.1.0 ortak Core’a aktarılmış, `AutoCadDxfExporter` üretim yoluna bağlanmış ve regressions test sayısı **70’ten 73’e** çıkarılmıştır. Bu yeni source tree’de Core testleri 73 assertion ile geçti. Burada gerçek 2018–2026 host DLL’leriyle Windows Setup yeniden derlenip AutoCAD’de host açılışı yapılmadı; bakınız [`IMPLEMENTATION-STATUS.md`](IMPLEMENTATION-STATUS.md).

## Gerçek DXF incelemesi

Gönderilen `ÖzetKarneÇıktı.zip` içindeki iki DXF’in ikisi de AC1009/R12 idi. Header’da `$DWGCODEPAGE` yoktu; STYLE tablosundaki `PH-TSTYLE` font dosyası ise `txt` olarak yazılmıştı. TEXT değerlerinin ham baytları CP1254 Türkçe metinle uyumluydu; ancak codepage kaydı eksik olduğunda AutoCAD farklı ANSI kod sayfası kullanıp `İ/Ş/ı` harflerini bozabilir. Arial hatası, `arial.ttf` kelimesini dosya içinde arayan kontrolün gerçek STYLE grubunu doğrulamamasından ve native dışa aktarıcının `txt` yazmasından kaynaklandı.

## 1.0.4 kaynak düzeltmesi

AutoCAD’in native `Database.DxfOut(..., DwgVersion.AC1009)` yapısı korunuyor. Dışa aktarımdan sonra grup kodu normalizer’ı `$DWGCODEPAGE` değişkenini `ANSI_1254` yapar/ekler ve `PH-TSTYLE` kaydının grup kodu 3 font değerini `arial.ttf` olarak sabitler. Böylece CP1254 ile yazılmış Türkçe metin doğru codepage ile yorumlanır ve kullanılan text style gerçek Arial font dosyasını işaret eder. Export öncesinde yalnız geçici DBText metinlerine uygulanan `\\U+nnnn` dönüşümü de korunmuştur.

Core testleri **70 assertion** ile geçti. Normalizer, gönderilen iki gerçek DXF’te doğrulandı: header `ANSI_1254`, `PH-TSTYLE` fontu `arial.ttf`, başlık ve şehir/kasaba metinleri CP1254 çözümlemesinde doğru. Plugin AutoCAD 2020 managed DLL’leriyle derlendi; AutoLoader manifesti R23.1 kontrolünden geçti ve **1.0.4 `dist/PoligonHesap_Setup.exe`** üretildi. Autodesk API DLL’leri kurucuya eklenmedi.

## AutoCAD’de son host doğrulaması

1. AutoCAD’i tamamen kapatın.
2. Yeni 1.0.4 Setup.exe’yi yönetici olarak yükleyip AutoCAD’i yeniden açın.
3. **Hesapla** ile yeni kanava DXF’i oluşturup açın.
4. `POLİGON KANAVASI`, `Şehir/Kasaba Adı`, güzergâh ve diğer yazılarda `Ş/ş, Ğ/ğ, İ/ı, Ü/ü, Ö/ö, Ç/ç` karakterlerini kontrol edin.
5. Gerekirse DXF metin dosyasının header’ında `$DWGCODEPAGE` / `ANSI_1254`; STYLE tablosunda `PH-TSTYLE` / `arial.ttf` bulunduğunu doğrulayın.

> Windows AutoCAD host’u bu Sandbox’ta yok. Bu nedenle 1.0.4’ün kullanıcı bilgisayarındaki görünümü, yeni kurucuyla üretilmiş DXF üzerinden doğrulanmalıdır. Sorun sürerse yalnızca o yeni DXF’i ve AutoCAD `ABOUT` tam sürüm/build bilgisini paylaşın.
