# Teslim notu — Poligon Hesap 1.1.0 (AutoCAD/Civil 3D 2018–2026)

1.0.4 DXF düzeltmesi korunarak Core’a taşındı. Eklenti, AutoCAD’in native `Database.DxfOut(..., AC1009)` yolunu kullanır; sonuç R12 DXF’te `ANSI_1254` ve `PH-TSTYLE` → `arial.ttf` normalizasyonu uygular. Kullanıcının açık DWG’si değiştirilmez.

Ürün artık 14 ayrı derleme profili kullanır: 2018–2024 legacy .NET Framework; AutoCAD 2025 ve 2026 için update düzeyine göre ayrı .NET 8/.NET 10; Civil 3D 2025 için bilinen .NET 8 build allowlist’i; Civil 3D 2026 için .NET 8/.NET 10 profilleri. Tek NSIS Setup, registry `ProductInfo` BuildVer/update bilgisine göre yalnız doğru izole `.bundle` klasörlerini kurar. Autodesk API DLL’leri dağıtıma dahil edilmez.

## Doğrulama

- Core portable suite: **73 assertion PASS**.
- Runtime/update selection suite: **15 assertion PASS**.
- 14 sentetik profile paketiyle bundle staging ve NSIS Setup derlemesi başarılı; sentetik içerikler testten sonra silindi.
- Gerçek Autodesk SDK’ları ve Windows host bu Sandbox’ta bulunmadığından gerçek eklenti DLL’leri, host load testleri ve son kullanıcı Setup.exe’si üretilmedi.

## Gerçek Windows build için sonraki adım

`installer/autodesk-managed-paths.example.json` dosyasını `autodesk-managed-paths.json` adıyla kopyalayın; her profile’a o ürün/update runtime’ının gerçek managed DLL dizinini verin. Windows makinede .NET Framework targeting pack’leri, .NET 8/10 SDK, Visual Studio MSBuild, Python 3 ve NSIS bulunmalı; sonra `Build-AutoCAD2018Plus.ps1` çalıştırılmalı. Build scripti 14 profile’ın tümünü derlemeden Setup üretmez. Gerçek release öncesi AutoCAD/Civil 3D update registry seçimleri, plugin load, komut, hesaplama ve R12 DXF açılışı hostlarda test edilmelidir. Autodesk kaynakları ve runtime matrisi [`AUTOCAD-2018-2026-COMPATIBILITY.md`](AUTOCAD-2018-2026-COMPATIBILITY.md) dosyasındadır.
