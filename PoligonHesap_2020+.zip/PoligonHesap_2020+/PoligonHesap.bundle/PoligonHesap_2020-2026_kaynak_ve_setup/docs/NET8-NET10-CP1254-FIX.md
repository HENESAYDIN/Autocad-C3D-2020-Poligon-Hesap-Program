# AutoCAD 2025–2026: CP1254 / Encoding 1254 düzeltmesi

## Belirti

Paylaşılan AutoCAD 2026 görüntüsünde şu hata yer alıyor:

> No data is available for encoding 1254. For information on defining a custom encoding, see the documentation for the Encoding.RegisterProvider method.

## Neden

Uygulama, Türkçe Windows kod sayfasını (`Encoding.GetEncoding(1254)`) kullanarak Rasat/kayıt ve DXF metinlerini okuyor/yazıyor. .NET 8 ve .NET 10 bu codepage sağlayıcısını varsayılan olarak kaydetmez. Bu yüzden çalışma zamanı, kod sayfası 1254 için sağlayıcı bulunamadığını bildirir. Bu, AutoCAD 2026 API referanslarının kendisinden değil, modern .NET çalışma zamanı encoding kayıt davranışından kaynaklanır.

## Kaynakta yapılan düzeltme

- AutoCAD eklenti başlangıcında, yalnız `NETCOREAPP` derlemelerinde `Encoding.RegisterProvider(CodePagesEncodingProvider.Instance)` çağrılır. .NET Framework 2018–2024 derlemeleri bu modern .NET çağrısından etkilenmez.
- .NET 8/10 hostlarının paylaşılan framework'ünde `System.Text.Encoding.CodePages.dll` assembly'si bulunur; eklenti bu framework sağlayıcısını kullanır ve aynı assembly'yi bundle içine çoğaltmaz.
- Bundle staging regresyonu 14 profildeki manifestleri doğrular ve Autodesk/framework assembly'lerinin özel bundle bağımlılığı olarak eklenmediğini kontrol eder.

Bu sağlayıcı kaydı yapıldıktan sonra mevcut `Encoding.GetEncoding(1254)` çağrıları Türkçe ANSI codepage verilerini kullanabilir. DXF tarafında var olan `ANSI_1254` dışa aktarma/fix davranışı korunur.

## Runtime hedefleri

- AutoCAD 2025: Update 1.3 ve öncesi .NET 8; Update 1.4+ .NET 10.
- AutoCAD 2026: Update 1.1 ve öncesi .NET 8; Update 1.2+ .NET 10.
- Civil 3D profilleri ayrıca ürün/update matrisindeki belgelenmiş eşiklere göre seçilir.

Güncel geçiş bilgisi: [Autodesk .NET 10 gereksinimleri](https://www.autodesk.com/support/technical/article/caas/sfdcarticles/sfdcarticles/AutoCAD-and-Toolsets-Requirements-for-products-affected-by-the-Microsoft-NET-10-transition.html).

## Kabul testi

Windows üzerindeki gerçek AutoCAD 2025/2026 hostlarında şu kullanım akışları test edilmelidir:

1. Eklenti yüklenirken exception olmaması ve `POLHESAP` komutunun açılması.
2. Türkçe karakterler içeren Rasat/koordinat dosyası okuma ve hesaplama.
3. Hesap raporu ve DXF çıktısı üretme; DXF'in AutoCAD'de açılması ve `İ/ı/Ş/ş/Ğ/ğ/Ü/ü/Ö/ö/Ç/ç` karakterlerinin doğruluğu.
4. Her AutoCAD update cohort'unda doğru net8/net10 bundle'ın kurulması.

Bu sandbox'ta Windows AutoCAD hostu çalışmadığından bu son kabul testleri yapılamadı. `bash build-and-test.sh` portable regression ve bundle staging testlerini çalıştırır; Windows'ta API referanslarıyla derleme ve gerçek AutoCAD testleri ayrıca gereklidir.
