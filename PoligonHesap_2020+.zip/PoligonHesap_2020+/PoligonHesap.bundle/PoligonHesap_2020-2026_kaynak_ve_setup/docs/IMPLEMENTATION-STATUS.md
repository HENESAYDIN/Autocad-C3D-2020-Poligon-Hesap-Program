# Uygulama durumu — 1.1.0 update-aware multi-runtime portu

## Devralınan 1.0.4 ürününün incelemesi

- 1.0.4 Setup PE32/NSIS installer; içinde 2020 plugin/Core DLL’i bulunuyor ve manifest yalnız R23.1’i hedefliyor.
- Plugin referansları AutoCAD 2020 managed API DLL’lerine bağlı. Başka yıla 2020 DLL’i kopyalamak güvenli değil.
- 1.0.4 DXF son işlemesi (`ANSI_1254`, `PH-TSTYLE` → `arial.ttf`) ortak Core’a taşındı.

## 1.1.0 kaynak değişiklikleri

- 2018–2024: release başına .NET Framework profilleri (4.6 / 4.7 / 4.8).
- AutoCAD 2025: .NET 8 Update 1.3 ve öncesi, .NET 10 Update 1.4+ olarak ayrı profiller.
- Civil 3D 2025: Autodesk’in yayınlanmış kılavuzuna göre .NET 8; bilinmeyen build’leri allowlist dışında bırakır. Resmî bir released .NET 10 eşiği henüz belirtilmedi.
- AutoCAD 2026: .NET 8 Update 1.1 ve öncesi, .NET 10 Update 1.2+ ayrı profiller.
- Civil 3D 2026: .NET 8 Update 2.2.1 ve öncesi, .NET 10 Update 2.2.2+ ayrı profiller.
- Tek NSIS Setup, Registry `ProductInfo` update/build anahtarlarıyla seçtiği izole `.bundle` klasörlerini kurar. Autodesk AutoLoader’ın `RuntimeRequirements` filtresi yalnız Series/Platform düzeyinde kullanılır; minor-update seçimi installer’da yapılır.
- Build/installer profilleri `supported-versions.json` dosyasında tek kaynak olarak tanımlandı. Her host/runtime profile kendi managed API referansı ve ayrı assembly name kullanır; Autodesk API DLL’leri dağıtılmaz.

## Doğrulama

- Portable Core regression suite: **73 assertion geçti**.
- Runtime profile selector regression suite: **15 assertion geçti**.
- 14 profile için synthetic PE fixture’larıyla package-bundle doğrulaması ve NSIS Setup derlemesi başarılı; sentetik DLL/Setup fixture’ları silindi.
- Python generator `py_compile`, JSON/TFM profili doğrulaması geçti.

## Gerçek build öncesi tamamlanması gereken Windows doğrulaması

Sandbox Linux ortamında Autodesk managed API DLL’leri ve gerçek AutoCAD/Civil 3D host’u yok; bu nedenle 14 gerçek plugin DLL’i ve son kullanıcı Setup.exe’si üretilmedi. `installer/autodesk-managed-paths.json` her profile’ın gerçek `accoremgd.dll`, `acdbmgd.dll`, `acmgd.dll`, `AdWindows.dll` klasörleriyle doldurulmalı; ardından Windows PowerShell’de `Build-AutoCAD2018Plus.ps1` çalıştırılmalı. 2025/2026 ProductInfo anahtar adları ve BuildVer değerleri gerçek hostlarda, özellikle update cohort seçimiyle test edilmelidir. Civil 3D 2025 .NET 10 update yayımlanınca resmi runtime eşiği teyit edilip matrix/detector güncellenmelidir.

Her host release için AutoLoader yüklemesi, komut/Ribbon, hesaplama, çizim ve R12 DXF’in native açılış testi yapılmadan paket son kullanıcı dağıtımına hazır sayılmaz. Kaynak ve runtime kanıtları [`AUTOCAD-2018-2026-COMPATIBILITY.md`](AUTOCAD-2018-2026-COMPATIBILITY.md) dosyasındadır.
