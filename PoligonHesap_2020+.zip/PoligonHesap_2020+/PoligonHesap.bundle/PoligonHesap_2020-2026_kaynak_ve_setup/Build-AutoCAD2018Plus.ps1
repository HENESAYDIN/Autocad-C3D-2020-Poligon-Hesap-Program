[CmdletBinding()]
param(
    [string]$ManagedPathsFile = (Join-Path $PSScriptRoot 'installer/autodesk-managed-paths.json'),
    [string]$Configuration = 'Release',
    [switch]$SkipCoreTests
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$installerDir = Join-Path $root 'installer'
$matrixPath = Join-Path $installerDir 'supported-versions.json'
$matrix = Get-Content -Raw -LiteralPath $matrixPath | ConvertFrom-Json
if (-not (Test-Path -LiteralPath $ManagedPathsFile)) {
    throw "Managed API path map is required. Copy installer/autodesk-managed-paths.example.json to installer/autodesk-managed-paths.json and set every profile path."
}
$managedPaths = Get-Content -Raw -LiteralPath $ManagedPathsFile | ConvertFrom-Json

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { $python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $python) { throw 'Python 3 is required to stage and validate the ApplicationPlugins bundles.' }
$nsis = Get-Command makensis -ErrorAction SilentlyContinue
if (-not $nsis) { throw 'NSIS (makensis) is required to create the final Windows Setup.exe.' }

$legacyProject = Join-Path $root 'src/PoligonHesap.AutoCAD/PoligonHesap.AutoCAD.csproj'
$modernProject = Join-Path $root 'src/PoligonHesap.AutoCAD/PoligonHesap.AutoCAD.Modern.csproj'
$publishRoot = Join-Path $root 'build/publish'
$packageRoot = Join-Path $installerDir 'Packages'
New-Item -ItemType Directory -Force -Path $publishRoot | Out-Null

$frameworkBuilds = @($matrix.profiles | Where-Object { $_.runtime -eq 'netfx' })
if ($frameworkBuilds.Count -gt 0) {
    $msbuild = Get-Command msbuild -ErrorAction SilentlyContinue
    if (-not $msbuild) { throw 'Visual Studio Build Tools/MSBuild is required for .NET Framework profiles.' }
}
$modernBuilds = @($matrix.profiles | Where-Object { $_.runtime -in @('net8','net10') })
if ($modernBuilds.Count -gt 0) {
    $dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
    if (-not $dotnet) { throw '.NET SDK 8 and 10 are required by the modern profile matrix.' }
}

foreach ($v in $matrix.profiles) {
    $profileId = [string]$v.id
    $year = [int]$v.year
    $pathKey = [string]$v.managed_api_key
    $managedPathProperty = $managedPaths.PSObject.Properties[$pathKey]
    if (-not $managedPathProperty -or [string]::IsNullOrWhiteSpace([string]$managedPathProperty.Value)) {
        throw "No managed API directory is configured for profile '$profileId' (key '$pathKey') in $ManagedPathsFile."
    }
    $managedPath = [Environment]::ExpandEnvironmentVariables([string]$managedPathProperty.Value)
    foreach ($dll in @('accoremgd.dll','acdbmgd.dll','acmgd.dll','AdWindows.dll')) {
        $candidate = Join-Path $managedPath $dll
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            throw "Profile '$profileId' reference set is incomplete: missing $candidate. Use that exact product/update's managed API DLLs; do not mix runtime cohorts or copy another year's DLLs."
        }
    }

    $output = Join-Path $publishRoot $profileId
    New-Item -ItemType Directory -Force -Path $output | Out-Null
    $framework = [string]$v.target_framework
    if ([string]::IsNullOrWhiteSpace($framework) -or $framework -eq 'TBD') {
        throw "Profile '$profileId' target_framework is not verified in supported-versions.json."
    }
    $suffix = [string]$v.assembly_suffix
    $pluginName = "PoligonHesap.AutoCAD$year$suffix.dll"

    if ($v.runtime -eq 'netfx') {
        $tfm = $framework
        if ($tfm -notmatch '^v') { $tfm = "v$tfm" }
        & $msbuild.Source $legacyProject '/nologo' '/m' "/p:Configuration=$Configuration" '/p:Platform=AnyCPU' "/p:TargetFrameworkVersion=$tfm" "/p:AutoCADYear=$year" "/p:AutoCADBuildSuffix=$suffix" "/p:AutoCADManagedPath=$managedPath" "/p:AutoCADOutputDir=$output\"
        if ($LASTEXITCODE -ne 0) { throw "MSBuild failed for profile '$profileId' (exit $LASTEXITCODE)." }
    }
    elseif ($v.runtime -in @('net8','net10')) {
        $coreFramework = $framework -replace '-windows$',''
        & $dotnet.Source 'build' $modernProject '--configuration' $Configuration "-p:AutoCADYear=$year" "-p:AutoCADBuildSuffix=$suffix" "-p:AutoCADTargetFramework=$framework" "-p:AutoCADCoreTargetFramework=$coreFramework" "-p:AutoCADManagedPath=$managedPath" "-p:AutoCADOutputDir=$output\"
        if ($LASTEXITCODE -ne 0) { throw ".NET SDK build failed for profile '$profileId' (exit $LASTEXITCODE)." }
    }
    else { throw "Unsupported runtime family '$($v.runtime)' for profile '$profileId'." }

    $core = Join-Path $output 'PoligonHesap.Core.dll'
    foreach ($file in @((Join-Path $output $pluginName),$core)) {
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Build profile '$profileId' did not create $file." }
        if ((Get-Item -LiteralPath $file).Length -lt 1024) { throw "Build output looks invalid: $file" }
    }
    Write-Host "Built $($v.label) ($framework) using $managedPath"
}

if (-not $SkipCoreTests) {
    $testProject = Join-Path $root 'tests/PoligonHesap.Core.Tests/PoligonHesap.Core.Tests.csproj'
    $testOutput = Join-Path $root 'build/windows-tests'
    New-Item -ItemType Directory -Force -Path $testOutput | Out-Null
    $testFramework = 'v4.8'
    & $msbuild.Source $testProject '/nologo' '/m' "/p:Configuration=$Configuration" '/p:Platform=AnyCPU' "/p:TargetFrameworkVersion=$testFramework" "/p:OutputPath=$testOutput\" "/p:AutoCADOutputDir=$testOutput\"
    if ($LASTEXITCODE -ne 0) { throw "Core regression test build failed (exit $LASTEXITCODE)." }
    $testExe = Join-Path $testOutput 'PoligonHesap.Core.Tests.exe'
    if (-not (Test-Path -LiteralPath $testExe -PathType Leaf)) { throw "Core regression test EXE was not created: $testExe" }
    & $testExe
    if ($LASTEXITCODE -ne 0) { throw "Core regression tests failed (exit $LASTEXITCODE)." }
}

& $python.Source (Join-Path $installerDir 'package-bundle.py') '--matrix' $matrixPath '--build-root' $publishRoot '--bundle-root' $packageRoot
if ($LASTEXITCODE -ne 0) { throw "Bundle staging failed (exit $LASTEXITCODE)." }

$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Force -Path $dist | Out-Null
$setup = Join-Path $dist 'PoligonHesap_Setup.exe'
if (Test-Path -LiteralPath $setup) { Remove-Item -LiteralPath $setup -Force }
Push-Location $installerDir
try {
    & $nsis.Source '-V3' 'PoligonHesap_Setup.nsi'
    if ($LASTEXITCODE -ne 0) { throw "NSIS failed (exit $LASTEXITCODE)." }
}
finally { Pop-Location }
if (-not (Test-Path -LiteralPath $setup -PathType Leaf)) { throw "Setup.exe was not produced: $setup" }
Write-Host "SUCCESS: one update-aware installer created at $setup"
