# Birleşik Poligon Hesap Setup teslimi

Tek `PoligonHesap_Setup.exe` içinde eski 2020–2024 bundle ve AutoCAD 2025/2026 için dört modern bundle (her yıl için net8 ve net10) paketlenmiştir. Legacy iki DLL byte bazında korunmuş, legacy manifest R23.1–R24.3 ile sınırlandırılmıştır.

Kurucu BuildVer eşiklerine göre AutoCAD 2025'te `V.188` ve altı net8, `V.189+` net10; AutoCAD 2026'da `W.178` ve altı net8, `W.179+` net10 seçer. Bilinmeyen profil kurulmaz. AutoCAD 2025 DLL'leri AutoCAD 2026'nın aynı runtime'ına ait API DLL referanslarıyla derlenmiştir; gerçek 2025 hostunda API uyumluluğu test edilmedi ve garanti edilmez. Civil 3D 2025/2026 kapsam dışıdır.

Kurucu eski setup gibi yönetici izni istemez; `%APPDATA%\\Autodesk\\ApplicationPlugins` altına kurulur ve `HKCU` `Poligon Hesap` uninstall kaydını kullanır. 73 çekirdek assertion, 15 tam-matris runtime/profile testi, .NET 8/10 CP1254 round-trip, 2025/2026 runtime selector testleri ve NSIS paket doğrulaması geçti. Setup içinden beş bundle çıkarılıp manifest aralıkları ve DLL imzaları doğrulandı; iki legacy DLL'in SHA-256 orijinal ile aynı.

Sandbox'ta gerçek AutoCAD hostu bulunmadığı için uygulama açılışı, komut, hesap ve DXF kabul testi yapılmadı; dijital imza da eklenmedi. Son dağıtımdan önce AutoCAD 2025 net8/net10 ve 2026 net8/net10 hostlarında test edilmelidir.

Yeniden üretim betiği: [`Build-AutoCAD2020-2026.ps1`](Build-AutoCAD2020-2026.ps1). Birleşik kurulum yönergesi: [`installer/combined2020-2026/README.md`](installer/combined2020-2026/README.md).
