#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
: "${AUTOCAD_YEAR:?Set AUTOCAD_YEAR to one legacy host year (2018-2024)}"
: "${AUTOCAD_REF_DIR:?Set AUTOCAD_REF_DIR to that exact release's AutoCAD managed DLL directory}"
: "${NET_FRAMEWORK_SDK:?Set NET_FRAMEWORK_SDK to the verified Mono reference profile, e.g. 4.7-api}"
case "$AUTOCAD_YEAR" in 2018|2019|2020|2021|2022|2023|2024) ;; *) echo "Mono script supports legacy .NET Framework builds only (2018-2024); use Build-AutoCAD2018Plus.ps1/.NET SDK for newer hosts." >&2; exit 2 ;; esac
for name in accoremgd.dll acdbmgd.dll acmgd.dll AdWindows.dll; do
  test -f "$AUTOCAD_REF_DIR/$name" || { echo "Missing $AUTOCAD_REF_DIR/$name; use the API references for AutoCAD $AUTOCAD_YEAR, not another year." >&2; exit 2; }
done
WPF_REF_DIR="${WPF_REF_DIR:-/usr/lib/mono/$NET_FRAMEWORK_SDK}"
for name in PresentationCore.dll PresentationFramework.dll System.Xaml.dll WindowsBase.dll; do
  test -f "$WPF_REF_DIR/$name" || { echo "Missing $WPF_REF_DIR/$name; set WPF_REF_DIR to the matching Framework reference assemblies." >&2; exit 2; }
done
"$ROOT/build-and-test.sh"
OUT="$ROOT/build/publish/$AUTOCAD_YEAR"
mkdir -p "$OUT"
mcs -sdk:"$NET_FRAMEWORK_SDK" -langversion:6 -target:library \
  -r:System.Core -r:System.Drawing -r:System.Windows.Forms \
  -r:"$WPF_REF_DIR/PresentationCore.dll" -r:"$WPF_REF_DIR/PresentationFramework.dll" -r:"$WPF_REF_DIR/System.Xaml.dll" -r:"$WPF_REF_DIR/WindowsBase.dll" \
  -r:"$AUTOCAD_REF_DIR/accoremgd.dll" \
  -r:"$AUTOCAD_REF_DIR/acdbmgd.dll" \
  -r:"$AUTOCAD_REF_DIR/acmgd.dll" \
  -r:"$AUTOCAD_REF_DIR/AdWindows.dll" \
  -r:"$ROOT/build/PoligonHesap.Core.dll" \
  -out:"$OUT/PoligonHesap.AutoCAD$AUTOCAD_YEAR.dll" \
  "$ROOT/src/PoligonHesap.AutoCAD/PluginEntry.cs" \
  "$ROOT/src/PoligonHesap.AutoCAD/DrawingService.cs" \
  "$ROOT/src/PoligonHesap.AutoCAD/AutoCadDxfExporter.cs" \
  "$ROOT/src/PoligonHesap.AutoCAD/PoligonPalette.cs" \
  "$ROOT/src/PoligonHesap.AutoCAD/RibbonService.cs"
cp "$ROOT/build/PoligonHesap.Core.dll" "$OUT/PoligonHesap.Core.dll"
echo "Built AutoCAD $AUTOCAD_YEAR plugin: $OUT/PoligonHesap.AutoCAD$AUTOCAD_YEAR.dll"
