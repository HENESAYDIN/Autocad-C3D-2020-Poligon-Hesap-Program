!define PRODUCT_VERSION "1.1.0"
!define SUPPORTED_YEAR_RANGE "2018–2026"
Var DetectedReleases
Var UnsupportedReleases
Var HasSupportedRelease
Var ProductSubKey
Var EnumIndex
Var UpdateIndex
Var UpdateKey
Var RegistryValue
Var BuildNumber
Var Use_2018
Var Use_2019
Var Use_2020
Var Use_2021
Var Use_2022
Var Use_2023
Var Use_2024
Var Use_2025_autocad_net10
Var Use_2025_autocad_net8
Var Use_2025_civil3d_net8
Var Use_2026_autocad_net10
Var Use_2026_autocad_net8
Var Use_2026_civil3d_net10
Var Use_2026_civil3d_net8

Function DetectAutoCADReleases
  StrCpy $DetectedReleases ""
  StrCpy $UnsupportedReleases ""
  StrCpy $HasSupportedRelease "0"
  SetRegView 64
  StrCpy $Use_2018 "0"
  StrCpy $Use_2019 "0"
  StrCpy $Use_2020 "0"
  StrCpy $Use_2021 "0"
  StrCpy $Use_2022 "0"
  StrCpy $Use_2023 "0"
  StrCpy $Use_2024 "0"
  StrCpy $Use_2025_autocad_net10 "0"
  StrCpy $Use_2025_autocad_net8 "0"
  StrCpy $Use_2025_civil3d_net8 "0"
  StrCpy $Use_2026_autocad_net10 "0"
  StrCpy $Use_2026_autocad_net8 "0"
  StrCpy $Use_2026_civil3d_net10 "0"
  StrCpy $Use_2026_civil3d_net8 "0"
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R22.0" 0
  StrCmp $ProductSubKey "" +3
  StrCpy $Use_2018 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - 2018 AutoCAD/Civil 3D"
  StrCpy $HasSupportedRelease "1"
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R23.0" 0
  StrCmp $ProductSubKey "" +3
  StrCpy $Use_2019 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - 2019 AutoCAD/Civil 3D"
  StrCpy $HasSupportedRelease "1"
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R23.1" 0
  StrCmp $ProductSubKey "" +3
  StrCpy $Use_2020 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - 2020 AutoCAD/Civil 3D"
  StrCpy $HasSupportedRelease "1"
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R24.0" 0
  StrCmp $ProductSubKey "" +3
  StrCpy $Use_2021 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - 2021 AutoCAD/Civil 3D"
  StrCpy $HasSupportedRelease "1"
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R24.1" 0
  StrCmp $ProductSubKey "" +3
  StrCpy $Use_2022 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - 2022 AutoCAD/Civil 3D"
  StrCpy $HasSupportedRelease "1"
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R24.2" 0
  StrCmp $ProductSubKey "" +3
  StrCpy $Use_2023 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - 2023 AutoCAD/Civil 3D"
  StrCpy $HasSupportedRelease "1"
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R24.3" 0
  StrCmp $ProductSubKey "" +3
  StrCpy $Use_2024 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - 2024 AutoCAD/Civil 3D"
  StrCpy $HasSupportedRelease "1"
  StrCpy $EnumIndex 0
Detect_autocad_2025_Loop:
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R25.0" $EnumIndex
  StrCmp $ProductSubKey "" Detect_autocad_2025_Done
  ReadRegStr $RegistryValue HKLM "${CAD_ROOT}\R25.0\$ProductSubKey\ProductInfo\AutoCAD 2025" "BuildVer"
  StrCmp $RegistryValue "" Detect_autocad_2025_Increment
  StrCpy $BuildNumber $RegistryValue 1 0
  StrCmp $BuildNumber "V" Detect_autocad_2025_PrefixOK Detect_autocad_2025_Unsupported
Detect_autocad_2025_PrefixOK:
  StrCpy $BuildNumber $RegistryValue 1 1
  StrCmp $BuildNumber "." Detect_autocad_2025_DotOK Detect_autocad_2025_Unsupported
Detect_autocad_2025_DotOK:
  StrCpy $BuildNumber $RegistryValue 3 2
  IntCmp $BuildNumber 189 Detect_autocad_2025_Switch Detect_autocad_2025_SwitchScan Detect_autocad_2025_Switch
Detect_autocad_2025_SwitchScan:
  StrCpy $UpdateIndex 0
Detect_autocad_2025_UpdateLoop:
  EnumRegKey $UpdateKey HKLM "${CAD_ROOT}\R25.0\$ProductSubKey\ProductInfo" $UpdateIndex
  StrCmp $UpdateKey "" Detect_autocad_2025_Default
  StrCmp $UpdateKey "AutoCAD 2025.1.4" Detect_autocad_2025_Switch Detect_autocad_2025_UpdateIncrement
Detect_autocad_2025_UpdateIncrement:
  IntOp $UpdateIndex $UpdateIndex + 1
  Goto Detect_autocad_2025_UpdateLoop
Detect_autocad_2025_Switch:
  StrCpy $Use_2025_autocad_net10 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - AutoCAD 2025 .NET 10 (Update 1.4+)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_autocad_2025_End
Detect_autocad_2025_Default:
  StrCpy $Use_2025_autocad_net8 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - AutoCAD 2025 .NET 8 (through Update 1.3)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_autocad_2025_End
Detect_autocad_2025_Unsupported:
  StrCpy $UnsupportedReleases "$UnsupportedReleases$\r$\n  - AutoCAD 2025: build $RegistryValue için runtime profili doğrulanmamış."
  Goto Detect_autocad_2025_End
Detect_autocad_2025_Increment:
  IntOp $EnumIndex $EnumIndex + 1
  Goto Detect_autocad_2025_Loop
Detect_autocad_2025_Done:
Detect_autocad_2025_End:
  StrCpy $EnumIndex 0
Detect_civil3d_2025_Loop:
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R25.0" $EnumIndex
  StrCmp $ProductSubKey "" Detect_civil3d_2025_Done
  ReadRegStr $RegistryValue HKLM "${CAD_ROOT}\R25.0\$ProductSubKey\ProductInfo\Civil 3D 2025" "BuildVer"
  StrCmp $RegistryValue "" Detect_civil3d_2025_Increment
  StrCmp $RegistryValue "13.7.145.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.154.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.161.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.765.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.1175.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.1276.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.1327.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.1371.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.1402.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.1429.0" Detect_civil3d_2025_Default
  StrCmp $RegistryValue "13.7.1458.0" Detect_civil3d_2025_Default
  Goto Detect_civil3d_2025_Unsupported
Detect_civil3d_2025_Default:
  StrCpy $Use_2025_civil3d_net8 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - Civil 3D 2025 .NET 8 (documented release)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_civil3d_2025_End
Detect_civil3d_2025_Unsupported:
  StrCpy $UnsupportedReleases "$UnsupportedReleases$\r$\n  - Civil 3D 2025: build $RegistryValue için runtime profili doğrulanmamış."
  Goto Detect_civil3d_2025_End
Detect_civil3d_2025_Increment:
  IntOp $EnumIndex $EnumIndex + 1
  Goto Detect_civil3d_2025_Loop
Detect_civil3d_2025_Done:
Detect_civil3d_2025_End:
  StrCpy $EnumIndex 0
Detect_autocad_2026_Loop:
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R25.1" $EnumIndex
  StrCmp $ProductSubKey "" Detect_autocad_2026_Done
  ReadRegStr $RegistryValue HKLM "${CAD_ROOT}\R25.1\$ProductSubKey\ProductInfo\AutoCAD 2026" "BuildVer"
  StrCmp $RegistryValue "" Detect_autocad_2026_Increment
  StrCpy $BuildNumber $RegistryValue 1 0
  StrCmp $BuildNumber "W" Detect_autocad_2026_PrefixOK Detect_autocad_2026_Unsupported
Detect_autocad_2026_PrefixOK:
  StrCpy $BuildNumber $RegistryValue 1 1
  StrCmp $BuildNumber "." Detect_autocad_2026_DotOK Detect_autocad_2026_Unsupported
Detect_autocad_2026_DotOK:
  StrCpy $BuildNumber $RegistryValue 3 2
  IntCmp $BuildNumber 179 Detect_autocad_2026_Switch Detect_autocad_2026_SwitchScan Detect_autocad_2026_Switch
Detect_autocad_2026_SwitchScan:
  StrCpy $UpdateIndex 0
Detect_autocad_2026_UpdateLoop:
  EnumRegKey $UpdateKey HKLM "${CAD_ROOT}\R25.1\$ProductSubKey\ProductInfo" $UpdateIndex
  StrCmp $UpdateKey "" Detect_autocad_2026_Default
  StrCmp $UpdateKey "AutoCAD 2026.1.2" Detect_autocad_2026_Switch Detect_autocad_2026_UpdateIncrement
Detect_autocad_2026_UpdateIncrement:
  IntOp $UpdateIndex $UpdateIndex + 1
  Goto Detect_autocad_2026_UpdateLoop
Detect_autocad_2026_Switch:
  StrCpy $Use_2026_autocad_net10 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - AutoCAD 2026 .NET 10 (Update 1.2+)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_autocad_2026_End
Detect_autocad_2026_Default:
  StrCpy $Use_2026_autocad_net8 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - AutoCAD 2026 .NET 8 (through Update 1.1)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_autocad_2026_End
Detect_autocad_2026_Unsupported:
  StrCpy $UnsupportedReleases "$UnsupportedReleases$\r$\n  - AutoCAD 2026: build $RegistryValue için runtime profili doğrulanmamış."
  Goto Detect_autocad_2026_End
Detect_autocad_2026_Increment:
  IntOp $EnumIndex $EnumIndex + 1
  Goto Detect_autocad_2026_Loop
Detect_autocad_2026_Done:
Detect_autocad_2026_End:
  StrCpy $EnumIndex 0
Detect_civil3d_2026_Loop:
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R25.1" $EnumIndex
  StrCmp $ProductSubKey "" Detect_civil3d_2026_Done
  ReadRegStr $RegistryValue HKLM "${CAD_ROOT}\R25.1\$ProductSubKey\ProductInfo\Civil 3D 2026" "BuildVer"
  StrCmp $RegistryValue "" Detect_civil3d_2026_Increment
  StrCmp $RegistryValue "13.8.1809.0" Detect_civil3d_2026_Switch
  StrCmp $RegistryValue "13.8.280.0" Detect_civil3d_2026_Default
  StrCmp $RegistryValue "13.8.946.0" Detect_civil3d_2026_Default
  StrCmp $RegistryValue "13.8.1516.0" Detect_civil3d_2026_Default
  StrCmp $RegistryValue "13.8.1704.0" Detect_civil3d_2026_Default
  StrCpy $UpdateIndex 0
Detect_civil3d_2026_UpdateLoop:
  EnumRegKey $UpdateKey HKLM "${CAD_ROOT}\R25.1\$ProductSubKey\ProductInfo" $UpdateIndex
  StrCmp $UpdateKey "" Detect_civil3d_2026_Unsupported
  StrCmp $UpdateKey "Civil 3D 2026.2.2" Detect_civil3d_2026_Switch Detect_civil3d_2026_UpdateIncrement
Detect_civil3d_2026_UpdateIncrement:
  IntOp $UpdateIndex $UpdateIndex + 1
  Goto Detect_civil3d_2026_UpdateLoop
Detect_civil3d_2026_Switch:
  StrCpy $Use_2026_civil3d_net10 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - Civil 3D 2026 .NET 10 (Update 2.2.2+)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_civil3d_2026_End
Detect_civil3d_2026_Default:
  StrCpy $Use_2026_civil3d_net8 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - Civil 3D 2026 .NET 8 (through Update 2.2.1)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_civil3d_2026_End
Detect_civil3d_2026_Unsupported:
  StrCpy $UnsupportedReleases "$UnsupportedReleases$\r$\n  - Civil 3D 2026: build $RegistryValue için runtime profili doğrulanmamış."
  Goto Detect_civil3d_2026_End
Detect_civil3d_2026_Increment:
  IntOp $EnumIndex $EnumIndex + 1
  Goto Detect_civil3d_2026_Loop
Detect_civil3d_2026_Done:
Detect_civil3d_2026_End:
FunctionEnd
