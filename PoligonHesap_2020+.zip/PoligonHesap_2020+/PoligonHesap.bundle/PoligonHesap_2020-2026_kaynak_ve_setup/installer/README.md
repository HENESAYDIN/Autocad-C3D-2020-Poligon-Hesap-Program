# Installer ve update-profili build zinciri

`PoligonHesap_Setup.exe` tek dağıtım dosyasıdır. Kurucu çalışırken Autodesk `ProductInfo` registry alt anahtarlarını inceler ve algılanan profile’lar için ayrı `.bundle` klasörü kurar. Profile’ların tamamı aynı `PackageContents.xml` içinde toplanmaz; AutoLoader release series ve platforma göre doğru izole paketi seçer.

## Runtime profilleri

- 2018–2024: release series başına bir .NET Framework DLL’i; `Platform="AutoCAD*|Civil3D"`.
- 2018–2024 .NET Framework paketlerinde CP1254 değişikliği yoktur; önceki çalışan kurulum davranışı korunur.
- AutoCAD 2025: `.NET 8` ve `.NET 10` ayrı DLL/bundle; update `ProductInfo` anahtarı ve V.189 build eşiğiyle seçilir.
- Civil 3D 2025: Autodesk’in son bilinen/doğrulanmış .NET 8 build’leri allowlist’ten seçilir. .NET 10 update cutoff yayımlanana kadar bilinmeyen build’lerde profile kurulmaz.
- AutoCAD 2026: `.NET 8` ve `.NET 10`; update 1.2 / W.179 eşiğiyle seçilir.
- Civil 3D 2026: `.NET 8` ve `.NET 10`; `Civil 3D 2026.2.2` ProductInfo update alt anahtarıyla seçilir.

Update/profile kuralları [`supported-versions.json`](supported-versions.json) içindedir. `package-bundle.py`, bu tek matristen `AutoCADReleaseDetection.nsh`, `InstallProfiles.nsh` ve `CleanupProfiles.nsh` üretir; eksik DLL/build profili varsa staging’i reddeder. Modern .NET 8/10 hostlarının kendi paylaşılan framework'ünde bulunan `System.Text.Encoding.CodePages` sağlayıcısı eklenti başlangıcında kaydedilir; bu framework assembly bundle'a ikinci kez kopyalanmaz. Autodesk API DLL’leri pakete asla konmaz.

## Windows build için API yolları

1. `autodesk-managed-paths.example.json` dosyasını `autodesk-managed-paths.json` olarak kopyalayın.
2. Her profil anahtarını doğru ürün, release ve update runtime’ının managed DLL klasörüne yönlendirin. `2025-AutoCAD-Net8` gibi eski update profilleri için son .NET 10 kurulumundan farklı bir SDK referans klasörü gerekebilir.
3. Her dizinde `accoremgd.dll`, `acdbmgd.dll`, `acmgd.dll`, `AdWindows.dll` bulunmalıdır.
4. Windows PowerShell’de repository root’undan `./Build-AutoCAD2018Plus.ps1` çalıştırın. MSBuild, .NET 8/10 SDK, .NET Framework targeting pack’leri, Python 3 ve `makensis` gereklidir.

`Build-AutoCAD2018Plus.ps1` 14 profile’ı ayrı output’a derler, her profile için tek `.bundle` üretir ve NSIS ile tek Setup.exe paketler. Gerçek build öncesi [`../README.md`](../README.md) içindeki host/SDK sınırlamalarını okuyun. Linux CI’de `bash ../build-and-test.sh` çekirdek hesap, runtime seçim ve modern codepage paketleme regresyonlarını çalıştırır; synthetic NSIS smoke testi ayrı build akışında uygulanabilir.

## Windows host kabul testi

Gerçek Autodesk kurulumu bulunan Windows makinede şu senaryolar doğrulanmalıdır:

1. Yalnız 2018–2024 kurulu: release series’e göre doğru tek legacy bundle kurulmalı.
2. AutoCAD 2025 Update 1.3: net8 bundle; AutoCAD 2025 Update 1.4+: net10 bundle.
3. AutoCAD 2026 Update 1.1: net8; Update 1.2+: net10.
4. Civil 3D 2025 matristeki bilinen build’lerden biri: net8; daha yeni, matriste olmayan build: kurulum atlanmalı ve kullanıcıya bildirilmelidir.
5. Civil 3D 2026 Update 2.2.1: net8; Update 2.2.2+: net10.
6. AutoCAD ve Civil 3D aynı bilgisayarda: her ürün için uygun bundle seçilmeli; Autodesk’in koordineli update gereksinimi kullanıcıya hatırlatılmalı.
7. Kurulum tekrarında eski PoligonHesap profile bundle’ları temizlenmeli; kaldırıcı tüm oluşturulan bundle klasörlerini kaldırmalı.

Autodesk’in 2025/2026 ProductInfo anahtar yapısı ve BuildVer değerleri gerçek Windows hostta doğrulanmadan Setup.exe’yi son kullanıcıya dağıtmayın.
