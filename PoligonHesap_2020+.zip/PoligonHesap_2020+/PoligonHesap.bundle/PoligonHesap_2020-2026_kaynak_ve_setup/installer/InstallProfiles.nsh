  ${If} $Use_2018 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2018.bundle"
    File /r "Packages\PoligonHesap_2018.bundle\*.*"
    DetailPrint "Kuruldu: 2018 AutoCAD/Civil 3D"
  ${EndIf}
  ${If} $Use_2019 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2019.bundle"
    File /r "Packages\PoligonHesap_2019.bundle\*.*"
    DetailPrint "Kuruldu: 2019 AutoCAD/Civil 3D"
  ${EndIf}
  ${If} $Use_2020 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2020.bundle"
    File /r "Packages\PoligonHesap_2020.bundle\*.*"
    DetailPrint "Kuruldu: 2020 AutoCAD/Civil 3D"
  ${EndIf}
  ${If} $Use_2021 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2021.bundle"
    File /r "Packages\PoligonHesap_2021.bundle\*.*"
    DetailPrint "Kuruldu: 2021 AutoCAD/Civil 3D"
  ${EndIf}
  ${If} $Use_2022 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2022.bundle"
    File /r "Packages\PoligonHesap_2022.bundle\*.*"
    DetailPrint "Kuruldu: 2022 AutoCAD/Civil 3D"
  ${EndIf}
  ${If} $Use_2023 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2023.bundle"
    File /r "Packages\PoligonHesap_2023.bundle\*.*"
    DetailPrint "Kuruldu: 2023 AutoCAD/Civil 3D"
  ${EndIf}
  ${If} $Use_2024 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2024.bundle"
    File /r "Packages\PoligonHesap_2024.bundle\*.*"
    DetailPrint "Kuruldu: 2024 AutoCAD/Civil 3D"
  ${EndIf}
  ${If} $Use_2025_autocad_net8 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2025-autocad-net8.bundle"
    File /r "Packages\PoligonHesap_2025-autocad-net8.bundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2025 .NET 8 (through Update 1.3)"
  ${EndIf}
  ${If} $Use_2025_autocad_net10 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2025-autocad-net10.bundle"
    File /r "Packages\PoligonHesap_2025-autocad-net10.bundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2025 .NET 10 (Update 1.4+)"
  ${EndIf}
  ${If} $Use_2025_civil3d_net8 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2025-civil3d-net8.bundle"
    File /r "Packages\PoligonHesap_2025-civil3d-net8.bundle\*.*"
    DetailPrint "Kuruldu: Civil 3D 2025 .NET 8 (documented release)"
  ${EndIf}
  ${If} $Use_2026_autocad_net8 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2026-autocad-net8.bundle"
    File /r "Packages\PoligonHesap_2026-autocad-net8.bundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2026 .NET 8 (through Update 1.1)"
  ${EndIf}
  ${If} $Use_2026_autocad_net10 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2026-autocad-net10.bundle"
    File /r "Packages\PoligonHesap_2026-autocad-net10.bundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2026 .NET 10 (Update 1.2+)"
  ${EndIf}
  ${If} $Use_2026_civil3d_net8 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2026-civil3d-net8.bundle"
    File /r "Packages\PoligonHesap_2026-civil3d-net8.bundle\*.*"
    DetailPrint "Kuruldu: Civil 3D 2026 .NET 8 (through Update 2.2.1)"
  ${EndIf}
  ${If} $Use_2026_civil3d_net10 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2026-civil3d-net10.bundle"
    File /r "Packages\PoligonHesap_2026-civil3d-net10.bundle\*.*"
    DetailPrint "Kuruldu: Civil 3D 2026 .NET 10 (Update 2.2.2+)"
  ${EndIf}
