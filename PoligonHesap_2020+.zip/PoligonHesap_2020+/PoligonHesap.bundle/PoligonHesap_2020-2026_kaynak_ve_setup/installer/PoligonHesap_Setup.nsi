Unicode true
!include "LogicLib.nsh"
!define PRODUCT_NAME "Poligon Hesap"
!define UNINSTALL_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\PoligonHesap"
!define CAD_ROOT "SOFTWARE\Autodesk\AutoCAD"
!include "AutoCADReleaseDetection.nsh"

Name "${PRODUCT_NAME} ${PRODUCT_VERSION}"
OutFile "../dist/PoligonHesap_Setup.exe"
InstallDir "$PROGRAMFILES64\Autodesk\ApplicationPlugins"
RequestExecutionLevel admin
ShowInstDetails show
ShowUninstDetails show

Page instfiles
UninstPage uninstConfirm
UninstPage instfiles

Function .onInit
  Call DetectAutoCADReleases
  ${If} $HasSupportedRelease != "1"
    MessageBox MB_ICONSTOP|MB_OK "Desteklenen AutoCAD/Civil 3D ${SUPPORTED_YEAR_RANGE} profili bulunamadı. Bilinmeyen ürün/update kayıtları:$\r$\n$UnsupportedReleases$\r$\nHiçbir dosya kurulmadı."
    Abort
  ${EndIf}
  MessageBox MB_ICONINFORMATION|MB_OK "Bulunan ve eşlenen profiller:$\r$\n$DetectedReleases$\r$\n$\r$\nRuntime profili doğrulanamayan ürün/build kayıtları:$\r$\n$UnsupportedReleases$\r$\n$\r$\n2025/2026 runtime seçimi Autodesk ProductInfo BuildVer/update kayıtlarına göre yapılır. İlgili Autodesk ürünlerini aynı sürüm/update ailesinde tutun ve AutoCAD/Civil 3D’yi yeniden başlatın."
FunctionEnd

Section "Install Poligon Hesap" SEC_INSTALL
  SetRegView 64
  ; Önce bu kurucunun önceki profil paketlerini kaldır; yalnızca algılanan eşleşmeleri tekrar kur.
  !include "CleanupProfiles.nsh"
  !include "InstallProfiles.nsh"
  WriteUninstaller "$INSTDIR\PoligonHesap_Uninstall.exe"
  WriteRegStr HKLM "${UNINSTALL_KEY}" "DisplayName" "${PRODUCT_NAME} AutoCAD/Civil 3D ${SUPPORTED_YEAR_RANGE} Add-in"
  WriteRegStr HKLM "${UNINSTALL_KEY}" "DisplayVersion" "${PRODUCT_VERSION}"
  WriteRegStr HKLM "${UNINSTALL_KEY}" "Publisher" "PoligonHesap"
  WriteRegStr HKLM "${UNINSTALL_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKLM "${UNINSTALL_KEY}" "UninstallString" '"$INSTDIR\PoligonHesap_Uninstall.exe"'
  WriteRegDWORD HKLM "${UNINSTALL_KEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UNINSTALL_KEY}" "NoRepair" 1
  DetailPrint "Eşleşen ürün/update profilleri kuruldu. Autodesk ürünlerini yeniden başlatın."
SectionEnd

Section "Uninstall"
  SetRegView 64
  DeleteRegKey HKLM "${UNINSTALL_KEY}"
  !include "CleanupProfiles.nsh"
  Delete "$INSTDIR\PoligonHesap_Uninstall.exe"
  RMDir "$INSTDIR"
SectionEnd
