  ${If} $Use_2025_autocad_net8 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2025-autocad-net8.bundle"
    File /r "Packages\PoligonHesap_2025-autocad-net8.bundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2025 .NET 8 (built with 2026 net8 API refs; test required)"
  ${EndIf}
  ${If} $Use_2025_autocad_net10 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2025-autocad-net10.bundle"
    File /r "Packages\PoligonHesap_2025-autocad-net10.bundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2025 .NET 10 (built with 2026 net10 API refs; test required)"
  ${EndIf}
  ${If} $Use_2026_autocad_net8 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2026-autocad-net8.bundle"
    File /r "Packages\PoligonHesap_2026-autocad-net8.bundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2026 .NET 8 (through Update 1.1)"
  ${EndIf}
  ${If} $Use_2026_autocad_net10 == "1"
    SetOutPath "$INSTDIR\PoligonHesap_2026-autocad-net10.bundle"
    File /r "Packages\PoligonHesap_2026-autocad-net10.bundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2026 .NET 10 (Update 1.2+)"
  ${EndIf}
