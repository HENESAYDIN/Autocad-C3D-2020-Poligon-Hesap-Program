  RMDir /r "$INSTDIR\PoligonHesap_2025-autocad-net8.bundle"
  RMDir /r "$INSTDIR\PoligonHesap_2025-autocad-net10.bundle"
  RMDir /r "$INSTDIR\PoligonHesap_2026-autocad-net8.bundle"
  RMDir /r "$INSTDIR\PoligonHesap_2026-autocad-net10.bundle"
