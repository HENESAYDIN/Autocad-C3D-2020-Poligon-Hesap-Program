Var UseLegacyBundle
Var LegacyDetectedReleases
Var LegacyProductSubKey

Function DetectLegacyReleases
  StrCpy $UseLegacyBundle "0"
  StrCpy $LegacyDetectedReleases ""
  SetRegView 64

  EnumRegKey $LegacyProductSubKey HKLM "${CAD_ROOT}\R23.1" 0
  StrCmp $LegacyProductSubKey "" DetectLegacy2021
  StrCpy $UseLegacyBundle "1"
  StrCpy $LegacyDetectedReleases "$LegacyDetectedReleases$\r$\n  - AutoCAD 2020"

DetectLegacy2021:
  EnumRegKey $LegacyProductSubKey HKLM "${CAD_ROOT}\R24.0" 0
  StrCmp $LegacyProductSubKey "" DetectLegacy2022
  StrCpy $UseLegacyBundle "1"
  StrCpy $LegacyDetectedReleases "$LegacyDetectedReleases$\r$\n  - AutoCAD 2021"

DetectLegacy2022:
  EnumRegKey $LegacyProductSubKey HKLM "${CAD_ROOT}\R24.1" 0
  StrCmp $LegacyProductSubKey "" DetectLegacy2023
  StrCpy $UseLegacyBundle "1"
  StrCpy $LegacyDetectedReleases "$LegacyDetectedReleases$\r$\n  - AutoCAD 2022"

DetectLegacy2023:
  EnumRegKey $LegacyProductSubKey HKLM "${CAD_ROOT}\R24.2" 0
  StrCmp $LegacyProductSubKey "" DetectLegacy2024
  StrCpy $UseLegacyBundle "1"
  StrCpy $LegacyDetectedReleases "$LegacyDetectedReleases$\r$\n  - AutoCAD 2023"

DetectLegacy2024:
  EnumRegKey $LegacyProductSubKey HKLM "${CAD_ROOT}\R24.3" 0
  StrCmp $LegacyProductSubKey "" DetectLegacyDone
  StrCpy $UseLegacyBundle "1"
  StrCpy $LegacyDetectedReleases "$LegacyDetectedReleases$\r$\n  - AutoCAD 2024"

DetectLegacyDone:
FunctionEnd
