Unicode true
!include "LogicLib.nsh"
!define PRODUCT_NAME "Poligon Hesap"
!define UNINSTALL_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\PoligonHesap"
!define CAD_ROOT "SOFTWARE\Autodesk\AutoCAD"
!include "AutoCADReleaseDetection.nsh"
!include "LegacyDetection.nsh"

Name "${PRODUCT_NAME} ${PRODUCT_VERSION}"
OutFile "../../dist/PoligonHesap_Setup.exe"
InstallDir "$APPDATA\Autodesk\ApplicationPlugins"
RequestExecutionLevel user
ShowInstDetails show
ShowUninstDetails show

Page instfiles
UninstPage uninstConfirm
UninstPage instfiles

Function .onInit
  Call DetectAutoCADReleases
  Call DetectLegacyReleases
  ${If} $HasSupportedRelease != "1"
    ${AndIf} $UseLegacyBundle != "1"
    MessageBox MB_ICONSTOP|MB_OK "Desteklenen AutoCAD 2020-2024 veya AutoCAD 2025/2026 runtime profili bulunamadi. Runtime profili dogrulanamayan build: $UnsupportedReleases. Hicbir dosya kurulmedi."
    Abort
  ${EndIf}
  MessageBox MB_ICONINFORMATION|MB_OK "Kurulum profilleri: 2020-2024 legacy DLL: $LegacyDetectedReleases; modern profiller: $DetectedReleases. AutoCAD 2025 .NET 8 Update 1.3'e kadar, .NET 10 Update 1.4+; AutoCAD 2026 .NET 8 Update 1.1'e kadar, .NET 10 Update 1.2+. 2025 DLL'leri AutoCAD 2026 API referanslariyla derlendi; 2025 host uyumlulugu test edilmelidir."
FunctionEnd

Section "Install Poligon Hesap" SEC_INSTALL
  SetRegView 64
  ; Eski, genis R22-R26 manifestini kaldirip yalniz AutoCAD 2020-2024 kapsamindaki legacy paketi yerleştir.
  RMDir /r "$INSTDIR\PoligonHesap.bundle"
  ${If} $UseLegacyBundle == "1"
    SetOutPath "$INSTDIR\PoligonHesap.bundle"
    File /r "LegacyBundle\*.*"
    DetailPrint "Kuruldu: AutoCAD 2020-2024 legacy bundle"
  ${EndIf}

  ; Modern update cohorts: yalniz algilanan AutoCAD 2026 runtime bundle kurulur.
  !include "CleanupProfiles.nsh"
  !include "InstallProfiles.nsh"
  WriteUninstaller "$INSTDIR\PoligonHesap_Uninstall.exe"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "DisplayName" "${PRODUCT_NAME} AutoCAD 2020-2024 / 2026 Add-in"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "DisplayVersion" "${PRODUCT_VERSION}"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "Publisher" "PoligonHesap"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "UninstallString" '"$INSTDIR\PoligonHesap_Uninstall.exe"'
  WriteRegDWORD HKCU "${UNINSTALL_KEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINSTALL_KEY}" "NoRepair" 1
  DetailPrint "Yalniz bulunan AutoCAD profilleri kuruldu. AutoCAD'i yeniden baslatin."
SectionEnd

Section "Uninstall"
  SetRegView 64
  DeleteRegKey HKCU "${UNINSTALL_KEY}"
  RMDir /r "$INSTDIR\PoligonHesap.bundle"
  !include "CleanupProfiles.nsh"
  Delete "$INSTDIR\PoligonHesap_Uninstall.exe"
  RMDir "$INSTDIR"
SectionEnd
