!define PRODUCT_VERSION "1.1.0"
!define SUPPORTED_YEAR_RANGE "2025–2026"
Var DetectedReleases
Var UnsupportedReleases
Var HasSupportedRelease
Var ProductSubKey
Var EnumIndex
Var UpdateIndex
Var UpdateKey
Var RegistryValue
Var BuildNumber
Var Use_2025_autocad_net10
Var Use_2025_autocad_net8
Var Use_2026_autocad_net10
Var Use_2026_autocad_net8

Function DetectAutoCADReleases
  StrCpy $DetectedReleases ""
  StrCpy $UnsupportedReleases ""
  StrCpy $HasSupportedRelease "0"
  SetRegView 64
  StrCpy $Use_2025_autocad_net10 "0"
  StrCpy $Use_2025_autocad_net8 "0"
  StrCpy $Use_2026_autocad_net10 "0"
  StrCpy $Use_2026_autocad_net8 "0"
  StrCpy $EnumIndex 0
Detect_autocad_2025_Loop:
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R25.0" $EnumIndex
  StrCmp $ProductSubKey "" Detect_autocad_2025_Done
  ReadRegStr $RegistryValue HKLM "${CAD_ROOT}\R25.0\$ProductSubKey\ProductInfo\AutoCAD 2025" "BuildVer"
  StrCmp $RegistryValue "" Detect_autocad_2025_Increment
  StrCpy $BuildNumber $RegistryValue 1 0
  StrCmp $BuildNumber "V" Detect_autocad_2025_PrefixOK Detect_autocad_2025_Unsupported
Detect_autocad_2025_PrefixOK:
  StrCpy $BuildNumber $RegistryValue 1 1
  StrCmp $BuildNumber "." Detect_autocad_2025_DotOK Detect_autocad_2025_Unsupported
Detect_autocad_2025_DotOK:
  StrCpy $BuildNumber $RegistryValue 3 2
  IntCmp $BuildNumber 189 Detect_autocad_2025_Switch Detect_autocad_2025_SwitchScan Detect_autocad_2025_Switch
Detect_autocad_2025_SwitchScan:
  StrCpy $UpdateIndex 0
Detect_autocad_2025_UpdateLoop:
  EnumRegKey $UpdateKey HKLM "${CAD_ROOT}\R25.0\$ProductSubKey\ProductInfo" $UpdateIndex
  StrCmp $UpdateKey "" Detect_autocad_2025_Default
  StrCmp $UpdateKey "AutoCAD 2025.1.4" Detect_autocad_2025_Switch Detect_autocad_2025_UpdateIncrement
Detect_autocad_2025_UpdateIncrement:
  IntOp $UpdateIndex $UpdateIndex + 1
  Goto Detect_autocad_2025_UpdateLoop
Detect_autocad_2025_Switch:
  StrCpy $Use_2025_autocad_net10 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - AutoCAD 2025 .NET 10 (built with 2026 net10 API refs; test required)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_autocad_2025_End
Detect_autocad_2025_Default:
  StrCpy $Use_2025_autocad_net8 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - AutoCAD 2025 .NET 8 (built with 2026 net8 API refs; test required)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_autocad_2025_End
Detect_autocad_2025_Unsupported:
  StrCpy $UnsupportedReleases "$UnsupportedReleases$\r$\n  - AutoCAD 2025: build $RegistryValue için runtime profili doğrulanmamış."
  Goto Detect_autocad_2025_End
Detect_autocad_2025_Increment:
  IntOp $EnumIndex $EnumIndex + 1
  Goto Detect_autocad_2025_Loop
Detect_autocad_2025_Done:
Detect_autocad_2025_End:
  StrCpy $EnumIndex 0
Detect_autocad_2026_Loop:
  EnumRegKey $ProductSubKey HKLM "${CAD_ROOT}\R25.1" $EnumIndex
  StrCmp $ProductSubKey "" Detect_autocad_2026_Done
  ReadRegStr $RegistryValue HKLM "${CAD_ROOT}\R25.1\$ProductSubKey\ProductInfo\AutoCAD 2026" "BuildVer"
  StrCmp $RegistryValue "" Detect_autocad_2026_Increment
  StrCpy $BuildNumber $RegistryValue 1 0
  StrCmp $BuildNumber "W" Detect_autocad_2026_PrefixOK Detect_autocad_2026_Unsupported
Detect_autocad_2026_PrefixOK:
  StrCpy $BuildNumber $RegistryValue 1 1
  StrCmp $BuildNumber "." Detect_autocad_2026_DotOK Detect_autocad_2026_Unsupported
Detect_autocad_2026_DotOK:
  StrCpy $BuildNumber $RegistryValue 3 2
  IntCmp $BuildNumber 179 Detect_autocad_2026_Switch Detect_autocad_2026_SwitchScan Detect_autocad_2026_Switch
Detect_autocad_2026_SwitchScan:
  StrCpy $UpdateIndex 0
Detect_autocad_2026_UpdateLoop:
  EnumRegKey $UpdateKey HKLM "${CAD_ROOT}\R25.1\$ProductSubKey\ProductInfo" $UpdateIndex
  StrCmp $UpdateKey "" Detect_autocad_2026_Default
  StrCmp $UpdateKey "AutoCAD 2026.1.2" Detect_autocad_2026_Switch Detect_autocad_2026_UpdateIncrement
Detect_autocad_2026_UpdateIncrement:
  IntOp $UpdateIndex $UpdateIndex + 1
  Goto Detect_autocad_2026_UpdateLoop
Detect_autocad_2026_Switch:
  StrCpy $Use_2026_autocad_net10 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - AutoCAD 2026 .NET 10 (Update 1.2+)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_autocad_2026_End
Detect_autocad_2026_Default:
  StrCpy $Use_2026_autocad_net8 "1"
  StrCpy $DetectedReleases "$DetectedReleases$\r$\n  - AutoCAD 2026 .NET 8 (through Update 1.1)"
  StrCpy $HasSupportedRelease "1"
  Goto Detect_autocad_2026_End
Detect_autocad_2026_Unsupported:
  StrCpy $UnsupportedReleases "$UnsupportedReleases$\r$\n  - AutoCAD 2026: build $RegistryValue için runtime profili doğrulanmamış."
  Goto Detect_autocad_2026_End
Detect_autocad_2026_Increment:
  IntOp $EnumIndex $EnumIndex + 1
  Goto Detect_autocad_2026_Loop
Detect_autocad_2026_Done:
Detect_autocad_2026_End:
FunctionEnd
