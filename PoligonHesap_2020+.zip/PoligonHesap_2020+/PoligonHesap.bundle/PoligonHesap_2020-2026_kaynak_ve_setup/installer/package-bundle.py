#!/usr/bin/env python3
"""Stage release/product/runtime-specific Autodesk ApplicationPlugins bundles."""
import argparse
import json
import re
import shutil
import sys
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path

FORBIDDEN_HOST_DLLS = {"accoremgd.dll", "acdbmgd.dll", "acmgd.dll", "adwindows.dll"}
VALID_RUNTIMES = {"netfx", "net8", "net10"}


def safe_id(value):
    return re.sub(r"[^A-Za-z0-9_]", "_", value)


def plugin_name(profile):
    return f"PoligonHesap.AutoCAD{int(profile['year'])}{profile.get('assembly_suffix', '')}"


def bundle_name(profile):
    return f"PoligonHesap_{profile['id']}.bundle"


def load_matrix(path, require_targets=True):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    profiles = data.get("profiles", [])
    selectors = data.get("selectors", [])
    if not profiles:
        raise ValueError("supported-versions.json has no profiles")
    profile_by_id = {}
    for profile in profiles:
        pid = profile.get("id", "")
        if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9-]*", pid):
            raise ValueError(f"invalid profile id: {pid!r}")
        if pid in profile_by_id:
            raise ValueError(f"duplicate profile id: {pid}")
        year = int(profile["year"])
        runtime = profile.get("runtime")
        tfm = profile.get("target_framework", "TBD")
        if runtime not in VALID_RUNTIMES:
            raise ValueError(f"{pid}: unsupported runtime family {runtime!r}")
        if require_targets and tfm == "TBD":
            raise ValueError(f"{pid}: target_framework has not been verified")
        if runtime == "netfx" and require_targets and not re.fullmatch(r"v4\.\d+(?:\.\d+)?", tfm):
            raise ValueError(f"{pid}: invalid .NET Framework target {tfm!r}")
        if runtime in {"net8", "net10"} and require_targets:
            expected = f"{runtime}.0-windows"
            if tfm != expected:
                raise ValueError(f"{pid}: expected {expected}, got {tfm!r}")
        if not re.fullmatch(r"R\d+\.\d+", profile.get("series", "")):
            raise ValueError(f"{pid}: invalid Autodesk release Series")
        if not profile.get("platform") or not profile.get("managed_api_key"):
            raise ValueError(f"{pid}: platform and managed_api_key are required")
        profile_by_id[pid] = profile

    selector_ids = set()
    for selector in selectors:
        sid = selector.get("id", "")
        if not sid or sid in selector_ids:
            raise ValueError(f"missing or duplicate selector id: {sid!r}")
        selector_ids.add(sid)
        if selector.get("kind") == "series":
            refs = [selector.get("profile")]
        elif selector.get("kind") == "product-info":
            refs = [selector.get("default_profile")]
            if selector.get("switch_profile"):
                refs.append(selector["switch_profile"])
            if not selector.get("product_info"):
                raise ValueError(f"{sid}: product_info key is required")
        else:
            raise ValueError(f"{sid}: unsupported selector kind {selector.get('kind')!r}")
        for ref in refs:
            if ref not in profile_by_id:
                raise ValueError(f"{sid}: references unknown profile {ref!r}")
            if profile_by_id[ref]["series"] != selector["series"]:
                raise ValueError(f"{sid}: selector/profile Series mismatch")
        if selector.get("switch_profile") and not selector.get("switch_update_key"):
            raise ValueError(f"{sid}: switch_update_key required when switch_profile is set")
    if not selectors:
        raise ValueError("supported-versions.json has no selectors")
    return data, profiles, selectors


def render_nsis_detection(data, profiles, selectors):
    years = [int(p["year"]) for p in profiles]
    vars_ = sorted({safe_id(p["id"]) for p in profiles})
    lines = [
        f'!define PRODUCT_VERSION "{data["product_version"]}"',
        f'!define SUPPORTED_YEAR_RANGE "{min(years)}–{max(years)}"',
        'Var DetectedReleases', 'Var UnsupportedReleases', 'Var HasSupportedRelease',
        'Var ProductSubKey', 'Var EnumIndex', 'Var UpdateIndex', 'Var UpdateKey', 'Var RegistryValue', 'Var BuildNumber',
    ]
    lines.extend(f'Var Use_{v}' for v in vars_)
    lines += ['', 'Function DetectAutoCADReleases', '  StrCpy $DetectedReleases ""',
              '  StrCpy $UnsupportedReleases ""', '  StrCpy $HasSupportedRelease "0"', '  SetRegView 64']
    lines.extend(f'  StrCpy $Use_{v} "0"' for v in vars_)

    for selector in selectors:
        sid = safe_id(selector["id"])
        series = selector["series"]
        if selector["kind"] == "series":
            profile_id = safe_id(selector["profile"])
            label = profiles_by_id(profiles)[selector["profile"]]["label"]
            lines += [
                f'  EnumRegKey $ProductSubKey HKLM "${{CAD_ROOT}}\\{series}" 0',
                '  StrCmp $ProductSubKey "" +3',
                f'  StrCpy $Use_{profile_id} "1"',
                f'  StrCpy $DetectedReleases "$DetectedReleases$\\r$\\n  - {label}"',
                '  StrCpy $HasSupportedRelease "1"',
            ]
            continue

        default_id = safe_id(selector["default_profile"])
        switch_id = safe_id(selector["switch_profile"]) if selector.get("switch_profile") else None
        product_info = selector["product_info"]
        loop = f"Detect_{sid}_Loop"
        increment = f"Detect_{sid}_Increment"
        done = f"Detect_{sid}_Done"
        choose_default = f"Detect_{sid}_Default"
        choose_switch = f"Detect_{sid}_Switch"
        switch_scan = f"Detect_{sid}_SwitchScan"
        unsupported = f"Detect_{sid}_Unsupported"
        end = f"Detect_{sid}_End"
        lines += [
            '  StrCpy $EnumIndex 0',
            f'{loop}:',
            f'  EnumRegKey $ProductSubKey HKLM "${{CAD_ROOT}}\\{series}" $EnumIndex',
            f'  StrCmp $ProductSubKey "" {done}',
            f'  ReadRegStr $RegistryValue HKLM "${{CAD_ROOT}}\\{series}\\$ProductSubKey\\ProductInfo\\{product_info}" "BuildVer"',
            f'  StrCmp $RegistryValue "" {increment}',
        ]
        allowed_builds = selector.get("supported_build_versions", [])
        switch_builds = selector.get("switch_build_versions", [])
        for build in switch_builds:
            lines.append(f'  StrCmp $RegistryValue "{build}" {choose_switch}')
        for build in allowed_builds:
            lines.append(f'  StrCmp $RegistryValue "{build}" {choose_default}')
        if switch_id:
            update_loop = f"Detect_{sid}_UpdateLoop"
            update_increment = f"Detect_{sid}_UpdateIncrement"
            update_root = f'${{CAD_ROOT}}\\{series}\\$ProductSubKey\\ProductInfo'
            prefix = selector.get("build_prefix")
            threshold = selector.get("switch_build_number")
            if prefix:
                prefix_ok = f"Detect_{sid}_PrefixOK"
                dot_ok = f"Detect_{sid}_DotOK"
                lines += [
                    '  StrCpy $BuildNumber $RegistryValue 1 0',
                    f'  StrCmp $BuildNumber "{prefix}" {prefix_ok} {unsupported}',
                    f'{prefix_ok}:',
                    '  StrCpy $BuildNumber $RegistryValue 1 1',
                    f'  StrCmp $BuildNumber "." {dot_ok} {unsupported}',
                    f'{dot_ok}:',
                ]
            if threshold is not None:
                lines += [
                    '  StrCpy $BuildNumber $RegistryValue 3 2',
                    f'  IntCmp $BuildNumber {int(threshold)} {choose_switch} {switch_scan} {choose_switch}',
                    f'{switch_scan}:',
                ]
            lines += [
                '  StrCpy $UpdateIndex 0',
                f'{update_loop}:',
                f'  EnumRegKey $UpdateKey HKLM "{update_root}" $UpdateIndex',
                f'  StrCmp $UpdateKey "" {unsupported if (allowed_builds or switch_builds) else choose_default}',
                f'  StrCmp $UpdateKey "{selector["switch_update_key"]}" {choose_switch} {update_increment}',
                f'{update_increment}:',
                '  IntOp $UpdateIndex $UpdateIndex + 1',
                f'  Goto {update_loop}',
                f'{choose_switch}:',
                f'  StrCpy $Use_{switch_id} "1"',
                f'  StrCpy $DetectedReleases "$DetectedReleases$\\r$\\n  - {profiles_by_id(profiles)[selector["switch_profile"]]["label"]}"',
                '  StrCpy $HasSupportedRelease "1"',
                f'  Goto {end}',
                f'{choose_default}:',
            ]
        elif allowed_builds:
            lines += [f'  Goto {unsupported}', f'{choose_default}:']
        lines += [
            f'  StrCpy $Use_{default_id} "1"',
            f'  StrCpy $DetectedReleases "$DetectedReleases$\\r$\\n  - {profiles_by_id(profiles)[selector["default_profile"]]["label"]}"',
            '  StrCpy $HasSupportedRelease "1"',
            f'  Goto {end}',
        ]
        if allowed_builds or switch_builds or selector.get("build_prefix"):
            lines += [
                f'{unsupported}:',
                f'  StrCpy $UnsupportedReleases "$UnsupportedReleases$\\r$\\n  - {selector["product_info"]}: build $RegistryValue için runtime profili doğrulanmamış."',
                f'  Goto {end}',
            ]
        lines += [
            f'{increment}:',
            '  IntOp $EnumIndex $EnumIndex + 1',
            f'  Goto {loop}',
            f'{done}:',
            f'{end}:',
        ]
    lines += ['FunctionEnd', '']
    return '\n'.join(lines)


def profiles_by_id(profiles):
    return {p["id"]: p for p in profiles}


def resolve_runtime_profile(selector, build_ver, update_keys=()):
    """Return the configured profile id, or None when an update is unverified."""
    if not build_ver:
        return None
    switch_profile = selector.get("switch_profile")
    prefix = selector.get("build_prefix")
    if prefix and not re.match(rf"^{re.escape(prefix)}\.\d+\.", build_ver):
        return None
    if build_ver in selector.get("switch_build_versions", []):
        return switch_profile
    allowed = selector.get("supported_build_versions", [])
    if allowed and build_ver in allowed:
        return selector["default_profile"]
    if allowed and not switch_profile:
        return None
    if switch_profile:
        if selector.get("switch_update_key") in set(update_keys):
            return switch_profile
        threshold = selector.get("switch_build_number")
        if threshold is not None:
            pattern = rf"^{re.escape(prefix)}\.(\d+)\." if prefix else r"^[A-Za-z]\.(\d+)\."
            match = re.match(pattern, build_ver)
            if match and int(match.group(1)) >= int(threshold):
                return switch_profile
            if not match:
                return None
        if allowed:
            return None
    return selector["default_profile"]


def render_nsis_install_profiles(profiles):
    lines = []
    for p in profiles:
        var = safe_id(p["id"])
        name = bundle_name(p)
        lines += [
            f'  ${{If}} $Use_{var} == "1"',
            f'    SetOutPath "$INSTDIR\\{name}"',
            f'    File /r "Packages\\{name}\\*.*"',
            f'    DetailPrint "Kuruldu: {p["label"]}"',
            '  ${EndIf}',
        ]
    return '\n'.join(lines) + '\n'


def render_nsis_cleanup(profiles):
    return '\n'.join(f'  RMDir /r "$INSTDIR\\{bundle_name(p)}"' for p in profiles) + '\n'


def write_installer_includes(matrix_path, data, profiles, selectors):
    installer = Path(matrix_path).parent
    (installer / "AutoCADReleaseDetection.nsh").write_text(
        render_nsis_detection(data, profiles, selectors), encoding="utf-8")
    (installer / "InstallProfiles.nsh").write_text(
        render_nsis_install_profiles(profiles), encoding="utf-8")
    (installer / "CleanupProfiles.nsh").write_text(
        render_nsis_cleanup(profiles), encoding="utf-8")


def make_manifest(profile, product_version):
    year = int(profile["year"])
    name = plugin_name(profile)
    package = ET.Element("ApplicationPackage", {
        "SchemaVersion": "1.0",
        "AppVersion": product_version,
        "ProductCode": "{" + str(uuid.uuid5(uuid.NAMESPACE_URL, "poligonhesap:" + profile["id"])).upper() + "}",
        "Name": "Poligon Hesap",
        "Description": f"Poligon Hesap {profile['label']} add-in",
        "Author": "PoligonHesap",
    })
    ET.SubElement(package, "CompanyDetails", {"Name": "PoligonHesap"})
    components = ET.SubElement(package, "Components")
    ET.SubElement(components, "RuntimeRequirements", {
        "OS": "Win64",
        "Platform": profile["platform"],
        "SeriesMin": profile["series"],
        "SeriesMax": profile["series"],
    })
    ET.SubElement(components, "ComponentEntry", {
        "AppName": name,
        "AppDescription": profile["label"],
        "AppType": ".Net",
        "ModuleName": f"./Contents/{name}.dll",
        "LoadOnAutoCADStartup": "True",
    })
    ET.SubElement(components, "ComponentEntry", {
        "AppName": f"PoligonHesap.Core.{profile['id']}",
        "AppDescription": f"Poligon Hesap dependency for {profile['label']}",
        "AppType": "Dependency",
        "ModuleName": "./Contents/PoligonHesap.Core.dll",
    })
    return package


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default=str(Path(__file__).with_name("supported-versions.json")))
    ap.add_argument("--build-root", default="build/publish")
    ap.add_argument("--bundle-root", default="Packages")
    ap.add_argument("--emit-installer-detection-only", action="store_true")
    args = ap.parse_args()
    matrix_path = Path(args.matrix)
    data, profiles, selectors = load_matrix(matrix_path, require_targets=not args.emit_installer_detection_only)
    write_installer_includes(matrix_path, data, profiles, selectors)
    if args.emit_installer_detection_only:
        print(f"Generated NSIS update/profile detection for {len(profiles)} profiles and {len(selectors)} selectors.")
        return

    build_root = Path(args.build_root)
    bundle_root = Path(args.bundle_root)
    required = []
    for p in profiles:
        folder = build_root / p["id"]
        plug = plugin_name(p) + ".dll"
        required.extend([folder / plug, folder / "PoligonHesap.Core.dll"])
    missing = [p for p in required if not p.is_file() or p.stat().st_size < 1024]
    if missing:
        raise FileNotFoundError("Missing/invalid profile build output(s):\n" + "\n".join(map(str, missing)))
    for p in required:
        if p.read_bytes()[:2] != b"MZ":
            raise ValueError(f"Not a Windows PE file: {p}")

    if bundle_root.exists():
        shutil.rmtree(bundle_root)
    bundle_root.mkdir(parents=True)
    for profile in profiles:
        package_dir = bundle_root / bundle_name(profile)
        contents = package_dir / "Contents"
        contents.mkdir(parents=True)
        source = build_root / profile["id"]
        plug_name = plugin_name(profile) + ".dll"
        shutil.copy2(source / plug_name, contents / plug_name)
        shutil.copy2(source / "PoligonHesap.Core.dll", contents / "PoligonHesap.Core.dll")
        for item in contents.iterdir():
            if item.name.lower() in FORBIDDEN_HOST_DLLS:
                raise ValueError(f"Autodesk host API assemblies must not be redistributed: {item}")
        tree = ET.ElementTree(make_manifest(profile, data["product_version"]))
        ET.indent(tree, space="  ")
        tree.write(package_dir / "PackageContents.xml", encoding="utf-8", xml_declaration=True)
        parsed = ET.parse(package_dir / "PackageContents.xml").getroot()
        req = parsed.find("./Components/RuntimeRequirements")
        entries = parsed.findall("./Components/ComponentEntry")
        assert req is not None and req.attrib["SeriesMin"] == profile["series"]
        assert req.attrib["Platform"] == profile["platform"]
        assert len(entries) == 2
        assert (contents / plug_name).is_file()
        assert (contents / "PoligonHesap.Core.dll").is_file()
    print(f"Staged and validated {len(profiles)} isolated product/update bundles; update selection is generated in NSIS includes.")
    print(bundle_root.resolve())


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
