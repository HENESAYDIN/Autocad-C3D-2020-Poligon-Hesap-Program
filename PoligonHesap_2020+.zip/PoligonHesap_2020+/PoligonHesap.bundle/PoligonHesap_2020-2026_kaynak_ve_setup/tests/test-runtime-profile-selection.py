#!/usr/bin/env python3
"""Policy-level tests for update-aware AutoCAD/Civil 3D runtime selection."""
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GENERATOR = ROOT / "installer" / "package-bundle.py"
MATRIX = ROOT / "installer" / "supported-versions.json"
spec = importlib.util.spec_from_file_location("package_bundle", GENERATOR)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
data, profiles, selectors = module.load_matrix(MATRIX)
by_id = {s["id"]: s for s in selectors}

cases = [
    ("autocad-2025", "V.171.0.0", (), "2025-autocad-net8"),
    ("autocad-2025", "V.189.0.0", (), "2025-autocad-net10"),
    ("autocad-2025", "V.205.0.0", (), "2025-autocad-net10"),
    ("autocad-2026", "W.164.0.0", (), "2026-autocad-net8"),
    ("autocad-2026", "W.179.0.0", (), "2026-autocad-net10"),
    ("autocad-2026", "W.190.0.0", (), "2026-autocad-net10"),
    ("autocad-2026", "X.190.0.0", (), None),
    ("autocad-2026", "X.190.0.0", ("AutoCAD 2026.1.2",), None),
    ("civil3d-2025", "13.7.1458.0", (), "2025-civil3d-net8"),
    ("civil3d-2025", "13.7.1458.1", (), None),
    ("civil3d-2026", "13.8.1704.0", (), "2026-civil3d-net8"),
    ("civil3d-2026", "13.8.1809.0", (), "2026-civil3d-net10"),
    ("civil3d-2026", "13.8.1809.0", ("Civil 3D 2026.2.2",), "2026-civil3d-net10"),
    ("civil3d-2026", "13.8.1900.0", (), None),
]
for sid, build, keys, expected in cases:
    actual = module.resolve_runtime_profile(by_id[sid], build, keys)
    assert actual == expected, (sid, build, keys, actual, expected)
assert module.resolve_runtime_profile(by_id["autocad-2025"], "", ()) is None
print(f"PASS: {len(cases) + 1} runtime profile selection assertions.")
