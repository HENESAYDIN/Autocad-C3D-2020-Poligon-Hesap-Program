using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using PoligonHesap.Core;

internal static class TestRunner
{
    private static int _assertions;

    private static void AssertTrue(bool value, string message)
    {
        _assertions++;
        if (!value) throw new Exception("ASSERT FAILED: " + message);
    }

    private static void AssertNear(double actual, double expected, double tolerance, string message)
    {
        _assertions++;
        if (Math.Abs(actual - expected) > tolerance)
            throw new Exception("ASSERT FAILED: " + message + " actual=" + actual.ToString("R") + " expected=" + expected.ToString("R"));
    }

    private static TraverseInput Load(string prefix, string back, string start, string end, string forward, string newEnd)
    {
        string fixture = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Fixtures");
        var input = new TraverseInput
        {
            BackReferenceName = back,
            StartName = start,
            EndName = end,
            ForwardReferenceName = forward,
            NewEndName = newEnd
        };
        input.ControlPoints.AddRange(SurveyTextReader.ReadControlPoints(Path.Combine(fixture, prefix + "-coordinates.NCN")));
        input.Observations.AddRange(SurveyTextReader.ReadSummary(Path.Combine(fixture, prefix + "-summary.txt")));
        return input;
    }

    private static SurveyPoint Point(TraverseResult result, string name)
    {
        return result.Points.FirstOrDefault(p => TraverseInput.NormalizeName(p.Name) == TraverseInput.NormalizeName(name));
    }

    private static void TestOpenSample()
    {
        var input = Load("open", "P.A", "P.B", null, null, "5");
        var result = TraverseCalculators.CalculateOpen(input);
        var p5 = Point(result, "5");
        AssertTrue(p5 != null, "open traverse creates point 5");
        AssertTrue(!result.HasKnownEnd, "open traverse is not forced to a known closing control");
        AssertNear(p5.Y, 366197.26827907615, 0.002, "open sample terminal Y");
        AssertNear(p5.X, 4537037.739400991, 0.002, "open sample terminal X");
        string folder = Path.Combine(Path.GetTempPath(), "polhesap-open-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        string xlsx = Path.Combine(folder, "open.xlsx");
        XlsxWriter.Write(xlsx, input, result);
        using (var archive = ZipFile.OpenRead(xlsx))
            AssertTrue(archive.GetEntry("xl/worksheets/sheet1.xml") != null && archive.GetEntry("xl/worksheets/sheet2.xml") != null && archive.GetEntry("xl/styles.xml") != null, "open workbook preserves both styled reference sheets");
        input.NewEndName = "8";
        input.Observations.Add(new TraverseObservation("5", 100.0, 10.0));
        input.Observations.Add(new TraverseObservation("6", 100.0, 10.0));
        var longResult = TraverseCalculators.CalculateOpen(input);
        string longXlsx = Path.Combine(folder, "open-long.xlsx");
        XlsxWriter.Write(longXlsx, input, longResult);
        using (var archive = ZipFile.OpenRead(longXlsx))
            AssertTrue(archive.GetEntry("xl/worksheets/sheet1.xml") != null && archive.GetEntry("xl/worksheets/sheet2.xml") != null, "long open traverse expands styled workbook rows");
    }

    private static void TestClosedSampleAndEndpointIndexFix()
    {
        var input = Load("closed", "P.A", "P.B", "P.A", "P.B", null);
        var result = TraverseCalculators.CalculateClosed(input);
        var end = Point(result, "P.A");
        AssertTrue(end != null, "closed traverse ends on named control P.A");
        AssertNear(end.Y, 368421.49, 0.002, "closed sample terminal Y");
        AssertNear(end.X, 4535340.93, 0.002, "closed sample terminal X");
        AssertTrue(result.CoordinateTolerancePassed, "closed sample coordinate closure passes tolerance");
        AssertTrue(result.AngularTolerancePassed, "closed sample angular closure passes tolerance");
        AssertNear(result.AngularMisclosureGon * 10000.0, -99.0, 3.0, "gon-to-cc display conversion");

        string folder = Path.Combine(Path.GetTempPath(), "polhesap-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        string txt = Path.Combine(folder, "closed.txt");
        string xlsx = Path.Combine(folder, "closed.xlsx");
        string dxf = Path.Combine(folder, "closed.dxf");
        ReportWriter.WriteText(txt, input, result);
        XlsxWriter.Write(xlsx, input, result);
        string requestedDxf = DxfWriter.Write(dxf, input, result);
        AssertTrue(requestedDxf == dxf, "DXF writer returns the requested path when the file is available");
        string report = File.ReadAllText(txt);
        AssertTrue(report.Contains("gon") && report.Contains("cc"), "report clearly distinguishes gon from cc");
        using (var archive = ZipFile.OpenRead(xlsx))
            AssertTrue(archive.GetEntry("xl/worksheets/sheet1.xml") != null && archive.GetEntry("xl/worksheets/sheet2.xml") != null, "xlsx contains both coordinate and calculation sheets");
        string dxfText = File.ReadAllText(dxf, Encoding.GetEncoding(1254));
        AssertTrue(dxfText.Contains("AC1009") && dxfText.Contains("ANSI_1254") && dxfText.Contains("arial.ttf"), "R12 DXF uses the DVB-compatible version, Turkish code page, and Arial style");
        AssertTrue(dxfText.Contains("$EXTMIN") && dxfText.Contains("$EXTMAX") && dxfText.Contains("$LTSCALE\r\n40\r\n25.0") && !dxfText.Contains("$MEASUREMENT"), "R12 DXF declares view extents and legacy linetype scale without a newer header variable");
        int headerSection = dxfText.IndexOf("SECTION\r\n2\r\nHEADER", StringComparison.Ordinal);
        int tablesSection = dxfText.IndexOf("SECTION\r\n2\r\nTABLES", StringComparison.Ordinal);
        int blocksSection = dxfText.IndexOf("SECTION\r\n2\r\nBLOCKS", StringComparison.Ordinal);
        int entitiesSection = dxfText.IndexOf("SECTION\r\n2\r\nENTITIES", StringComparison.Ordinal);
        AssertTrue(headerSection >= 0 && headerSection < tablesSection && tablesSection < blocksSection && blocksSection < entitiesSection, "R12 file writes HEADER, TABLES, BLOCKS, and ENTITIES in AutoCAD order");
        AssertTrue(dxfText.Contains("TABLE\r\n2\r\nVPORT\r\n70\r\n1\r\n0\r\nVPORT\r\n5\r\n") && dxfText.Contains("*ACTIVE") && dxfText.Contains("$VIEWCTR") && dxfText.Contains("$VIEWSIZE"), "R12 file defines a handled active viewport and consistent initial view variables");
        AssertTrue(dxfText.Contains("TABLE\r\n2\r\nVIEW\r\n70\r\n0\r\n0\r\nENDTAB") && dxfText.Contains("TABLE\r\n2\r\nUCS\r\n70\r\n0\r\n0\r\nENDTAB") && dxfText.Contains("TABLE\r\n2\r\nAPPID") && dxfText.Contains("TABLE\r\n2\r\nDIMSTYLE"), "R12 file includes the standard auxiliary symbol tables");
        AssertTrue(dxfText.Contains("0\r\nBLOCK\r\n5\r\n") && dxfText.Contains("$MODEL_SPACE") && dxfText.Contains("$PAPER_SPACE") && dxfText.Contains("0\r\nENDBLK\r\n5\r\n"), "R12 BLOCKS section declares model and paper spaces with mandatory handles");
        AssertTrue(HasCompleteDxfHandles(dxfText), "R12 object handles are unique and match HANDLING/HANDSEED, including all block definitions");
        AssertTrue(dxfText.Contains("HIDDEN") && dxfText.Contains("PH_Grid") && !dxfText.Contains("\r\n48\r\n25"), "DXF grid uses the bundled HIDDEN linetype and R12 global scale");
        byte[] dxfBytes = File.ReadAllBytes(dxf);
        AssertTrue(Enumerable.Range(0, dxfBytes.Length - 1).Any(i => dxfBytes[i] == 13 && dxfBytes[i + 1] == 10), "DXF group-code pairs use Windows CRLF line endings");
        string dxfEntities = dxfText.Substring(dxfText.IndexOf("ENTITIES", StringComparison.Ordinal) + "ENTITIES".Length);
        AssertTrue(dxfEntities.Contains("POLİGON KANAVASI") && dxfEntities.Contains("PH_GYazi") && dxfEntities.Contains("50\r\n90") && !dxfEntities.Contains("P O L İ G O N   H E S A B I"), "plot title and rotated outside grid labels are exported while the calculation table is omitted by default");
        AssertTrue(CountEmptyTextEntities(dxfText) == 0, "map-only DXF contains no empty TEXT entities");
        var reports = ReportWriter.WriteLegacySet(folder, input, result);
        AssertTrue(File.Exists(reports.CalculationPath) && File.Exists(reports.AnglePath) && File.Exists(reports.EdgePath) && File.Exists(reports.CoordinatePath), "legacy workflow writes its four named TXT reports");
        string calculation = File.ReadAllText(reports.CalculationPath, Encoding.GetEncoding(1254));
        string coordinates = File.ReadAllText(reports.CoordinatePath, Encoding.GetEncoding(1254));
        AssertTrue(calculation.Contains(ReportWriter.LegalText), "closed report retains the exact DVB BÖHYY legal statement");
        AssertTrue(!coordinates.Contains("Koordinat Sistemi") && !coordinates.Contains("easting") && coordinates.Contains("Hesap;"), "coordinate report removes the requested coordinate-system footer and keeps the DVB attribution");
        using (var archive = ZipFile.OpenRead(xlsx))
        using (var reader = new StreamReader(archive.GetEntry("xl/worksheets/sheet2.xml").Open()))
            AssertTrue(reader.ReadToEnd().Contains(ReportWriter.LegalText), "closed Excel calculation sheet retains the exact DVB BÖHYY legal statement");
        string tableDxf = Path.Combine(folder, "closed-table.dxf");
        DxfWriter.Write(tableDxf, input, result, true);
        string tableDxfText = File.ReadAllText(tableDxf, Encoding.GetEncoding(1254));
        AssertTrue(tableDxfText.Contains(ReportWriter.LegalText) && tableDxfText.Contains("[S]: "), "optional DXF table carries the DVB legal footer and edge-distance total");
        AssertTrue(tableDxfText.Contains("fl=") && tableDxfText.Contains("fq=") && tableDxfText.Contains("fs=") && tableDxfText.Contains("fx=") && tableDxfText.Contains("fy="), "optional DXF table reports only the fl/fq/fs/fx/fy closure values");
        AssertTrue(!tableDxfText.Contains("Max Boyuna Hata") && !tableDxfText.Contains("Max Enine Hata") && !tableDxfText.Contains("Lineer Kapanma Hatası") && !tableDxfText.Contains("Max Fβ="), "optional DXF table omits the unwanted maximum/linear-closure captions");
        AssertTrue(CountEmptyTextEntities(tableDxfText) == 0, "optional-table DXF omits empty text cells that can trigger AutoCAD DXF-read errors");

        string lockedDxf = Path.Combine(folder, "locked.dxf");
        File.WriteAllText(lockedDxf, "existing drawing remains untouched");
        string alternatePath;
        using (new FileStream(lockedDxf, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
            alternatePath = DxfWriter.Write(lockedDxf, input, result);
        AssertTrue(alternatePath != lockedDxf && File.Exists(alternatePath), "locked DXF is written to a versioned sibling instead of failing");
        AssertTrue(File.ReadAllText(lockedDxf) == "existing drawing remains untouched", "locked original DXF remains untouched");
    }

    private static void TestClosedGenericEndName()
    {
        var input = Load("closed", "P.A", "P.B", "P.A", "P.B", null);
        input.ControlPoints[0].Name = "SON-KONTROL-42";
        input.ControlPoints[1].Name = "SEMT-KONTROL-77";
        input.BackReferenceName = "SON-KONTROL-42";
        input.StartName = "SEMT-KONTROL-77";
        input.EndName = "SON-KONTROL-42";
        input.ForwardReferenceName = "SEMT-KONTROL-77";
        input.Observations[0].StationName = "SEMT-KONTROL-77";
        input.Observations[input.Observations.Count - 1].StationName = "SON-KONTROL-42";
        var result = TraverseCalculators.CalculateClosed(input);
        var end = Point(result, "SON-KONTROL-42");
        AssertTrue(end != null, "selected final point and closing direction reference are not hard-coded to P.A/P.B");
        AssertNear(end.X, 4535340.93, 0.002, "generic closed endpoint coordinate");
    }

    private static void TestDayaliSample()
    {
        var input = Load("dayali", "P.A", "P.B", "P.C", "P.D", null);
        input.Precision = CoordinatePrecision.Centimeter;
        var result = TraverseCalculators.CalculateDayali(input);
        AssertNear(Point(result, "1").Y, 366872.32, 0.03, "dayali sample point 1 Y");
        AssertNear(Point(result, "1").X, 4535974.10, 0.03, "dayali sample point 1 X");
        AssertNear(Point(result, "5").Y, 367172.44, 0.03, "dayali sample point 5 Y");
        AssertNear(Point(result, "5").X, 4536046.40, 0.03, "dayali sample point 5 X");
        string fixture = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Fixtures");
        var raw = SurveyTextReader.ReadRasat(Path.Combine(fixture, "dayali-rasat.txt"));
        var fromRasat = SurveyTextReader.BuildSummaryFromRasat(raw, "P.10", "P.3", "P.4", "P.6");
        AssertTrue(raw.Count == 12 && fromRasat.Count == 6, "two-face Rasat rows build the selected tied traverse chain");
        AssertTrue(fromRasat[fromRasat.Count - 1].StationName == "P.4" && fromRasat[fromRasat.Count - 1].DistanceM == 0.0, "Rasat chain retains the selected final control angle without inventing a closing distance");
        var resolvedSummary = SurveyTextReader.ResolveRouteObservations(input.Observations, new List<RawRasatObservation>(), "P.A", "P.B", "P.C", "P.D", true);
        AssertTrue(resolvedSummary.Count == input.Observations.Count && resolvedSummary[0].StationName == input.Observations[0].StationName, "loaded Summary Karne resolves without asking for a Rasat file");
        var summaryPreferred = SurveyTextReader.ResolveRouteObservations(input.Observations, raw, "P.A", "P.B", "P.C", "P.D", true);
        AssertTrue(summaryPreferred.Count == input.Observations.Count && summaryPreferred[0].StationName == input.Observations[0].StationName, "Summary Karne remains the selected source even if a Rasat grid is also populated");
        var resolvedRasat = SurveyTextReader.ResolveRouteObservations(new List<TraverseObservation>(), raw, "P.10", "P.3", "P.4", "P.6", false);
        AssertTrue(resolvedRasat.Count == fromRasat.Count && resolvedRasat[resolvedRasat.Count - 1].StationName == "P.4", "Rasat still builds the selected traverse when no Summary Karne is chosen");
        var rasatInput = new TraverseInput
        {
            BackReferenceName = "P.10", StartName = "P.3", EndName = "P.4", ForwardReferenceName = "P.6",
            ObservationsFromRasat = true, CityName = "Test", RouteNumber = "R-2"
        };
        rasatInput.ControlPoints.AddRange(new[]
        {
            new SurveyPoint("P.10", 1000.0, 1000.0), new SurveyPoint("P.3", 1100.0, 1000.0),
            new SurveyPoint("P.4", 1500.0, 1050.0), new SurveyPoint("P.6", 1600.0, 1050.0)
        });
        rasatInput.Observations.AddRange(fromRasat);
        rasatInput.RawRasatObservations.AddRange(raw);
        var rasatResult = TraverseCalculators.CalculateDayali(rasatInput);
        AssertTrue(rasatResult.Legs.Count > 0, "Rasat-driven Dayali result is available for workbook reports");
        var edgeInput = new TraverseInput(); edgeInput.RawRasatObservations.AddRange(raw);
        var edgeLeg = new TraverseLegResult { FromName = "ELF-1", ToName = "ELF-2", DistanceM = 154.9085 };
        double first, second, average, difference;
        ReportWriter.GetEdgeMeasurements(edgeInput, edgeLeg, out first, out second, out average, out difference);
        AssertNear(first, 154.908, 0.000001, "first measured edge direction is preserved");
        AssertNear(second, 154.909, 0.000001, "reverse measured edge direction is preserved");
        AssertNear(difference, 0.001, 0.000001, "two-face measured edge difference is computed");
        string folder = Path.Combine(Path.GetTempPath(), "polhesap-dayali-test-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        string xlsx = Path.Combine(folder, "dayali.xlsx");
        XlsxWriter.Write(xlsx, input, result);
        using (var archive = ZipFile.OpenRead(xlsx))
        {
            AssertTrue(archive.GetEntry("xl/worksheets/sheet3.xml") != null && archive.GetEntry("xl/styles.xml") != null, "dayali workbook preserves the original three-sheet styled template");
            using (var reader = new StreamReader(archive.GetEntry("xl/workbook.xml").Open()))
            {
                string xml = reader.ReadToEnd();
                AssertTrue(xml.Contains("Koordine.Özet") && xml.Contains("Hesap.Karne"), "dayali workbook retains the original sheet names");
                AssertTrue(!xml.Contains("Açı.Karne") && !xml.Contains("Kenar.Karne"), "Summary-based Dayali workbook omits Rasat-only angle and edge sheets");
            }
        }
        var summaryWithRasat = Load("dayali", "P.A", "P.B", "P.C", "P.D", null);
        summaryWithRasat.RawRasatObservations.AddRange(raw);
        string summaryWithRasatXlsx = Path.Combine(folder, "dayali-summary-with-rasat-loaded.xlsx");
        XlsxWriter.Write(summaryWithRasatXlsx, summaryWithRasat, result);
        using (var archive = ZipFile.OpenRead(summaryWithRasatXlsx))
        using (var reader = new StreamReader(archive.GetEntry("xl/workbook.xml").Open()))
        {
            string xml = reader.ReadToEnd();
            AssertTrue(!xml.Contains("Açı.Karne") && !xml.Contains("Kenar.Karne"), "Summary-selected workbook still omits Rasat sheets when a Rasat file is loaded");
        }
        string rasatXlsx = Path.Combine(folder, "dayali-rasat.xlsx");
        XlsxWriter.Write(rasatXlsx, rasatInput, rasatResult);
        using (var archive = ZipFile.OpenRead(rasatXlsx))
        {
            using (var reader = new StreamReader(archive.GetEntry("xl/workbook.xml").Open()))
            {
                string xml = reader.ReadToEnd();
                AssertTrue(xml.Contains("Açı.Karne") && xml.Contains("Kenar.Karne"), "Rasat-driven Dayali workbook adds both original-style report sheets");
            }
            using (var reader = new StreamReader(archive.GetEntry("xl/worksheets/sheet3.xml").Open()))
            {
                string xml = reader.ReadToEnd();
                AssertTrue(xml.Contains("P.3") && xml.Contains("P.4"), "Açı.Karne is populated from imported two-face Rasat readings");
            }
            using (var reader = new StreamReader(archive.GetEntry("xl/worksheets/sheet4.xml").Open()))
            {
                string xml = reader.ReadToEnd();
                AssertTrue(xml.Contains("Hata sınırı") && xml.Contains("P.3"), "Kenar.Karne includes measured legs and the DVB distance-error rule");
            }
        }
        var dayaliReports = ReportWriter.WriteLegacySet(folder, input, result);
        AssertTrue(Path.GetFileName(dayaliReports.CalculationPath) == "PoligonHesap_1.txt", "dayali report set uses the legacy route filename");
        string dayaliCalc = File.ReadAllText(dayaliReports.CalculationPath, Encoding.GetEncoding(1254));
        AssertTrue(dayaliCalc.Contains("P O L") && dayaliCalc.Contains(ReportWriter.LegalText), "dayali report retains the reference heading and exact DVB BÖHYY statement");
        AssertTrue(!File.ReadAllText(dayaliReports.CoordinatePath, Encoding.GetEncoding(1254)).Contains("Koordinat Sistemi"), "dayali coordinate report omits the unwanted coordinate-system footer");
        using (var archive = ZipFile.OpenRead(xlsx))
        using (var reader = new StreamReader(archive.GetEntry("xl/worksheets/sheet2.xml").Open()))
            AssertTrue(reader.ReadToEnd().Contains(ReportWriter.LegalText), "dayali Excel calculation sheet retains the exact DVB BÖHYY legal statement");
        string dayaliDxf = Path.Combine(folder, "dayali.dxf");
        DxfWriter.Write(dayaliDxf, input, result);
        string dayaliDxfText = File.ReadAllText(dayaliDxf, Encoding.GetEncoding(1254));
        string dayaliEntities = dayaliDxfText.Substring(dayaliDxfText.IndexOf("ENTITIES", StringComparison.Ordinal) + "ENTITIES".Length);
        AssertTrue(dayaliDxfText.Contains("PH-TSTYLE") && dayaliDxfText.Contains("arial.ttf") && dayaliDxfText.Contains("ANSI_1254") && dayaliEntities.Contains("POLİGON KANAVASI"), "dayali DXF uses the DVB R12 Arial/Turkish format and centered title");
        AssertTrue(!dayaliEntities.Contains("P O L İ G O N   H E S A B I"), "dayali DXF does not add the calculation table automatically");
    }

    private static void WriteDxfSamples(string folder)
    {
        Directory.CreateDirectory(folder);
        var input = Load("closed", "P.A", "P.B", "P.A", "P.B", null);
        var result = TraverseCalculators.CalculateClosed(input);
        string mapPath = Path.Combine(folder, "PoligonHesap-Ornek-AC1009.dxf");
        string tablePath = Path.Combine(folder, "PoligonHesap-Ornek-AC1009-Tablolu.dxf");
        DxfWriter.Write(mapPath, input, result);
        DxfWriter.Write(tablePath, input, result, true);
        if (CountEmptyTextEntities(File.ReadAllText(mapPath, Encoding.GetEncoding(1254))) != 0 ||
            CountEmptyTextEntities(File.ReadAllText(tablePath, Encoding.GetEncoding(1254))) != 0)
            throw new InvalidDataException("Regenerated DXF samples must not contain empty TEXT entities.");
        Console.WriteLine("Wrote AutoCAD R12 samples to: " + folder);
    }

    private static int CountEmptyTextEntities(string dxfText)
    {
        string[] lines = dxfText.Replace("\r\n", "\n").Split('\n');
        int emptyCount = 0;
        for (int i = 0; i + 1 < lines.Length;)
        {
            if (lines[i].Trim() != "0" || lines[i + 1].Trim() != "TEXT")
            {
                i += 2;
                continue;
            }

            i += 2;
            string value = null;
            while (i + 1 < lines.Length && lines[i].Trim() != "0")
            {
                if (lines[i].Trim() == "1") value = lines[i + 1];
                i += 2;
            }
            if (String.IsNullOrWhiteSpace(value)) emptyCount++;
        }
        return emptyCount;
    }

    private static bool HasCompleteDxfHandles(string dxfText)
    {
        string[] lines = dxfText.Replace("\r\n", "\n").Split('\n');
        int count = lines.Length;
        if (count > 0 && lines[count - 1].Length == 0) count--;
        var handles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        bool handling = false, seed = false;
        for (int i = 0; i + 1 < count; i += 2)
        {
            int code;
            if (!Int32.TryParse(lines[i].Trim(), out code)) return false;
            string value = lines[i + 1].Trim();
            if (code == 9 && value == "$HANDLING")
                handling = i + 3 < count && lines[i + 2].Trim() == "70" && lines[i + 3].Trim() == "1";
            if (code == 9 && value == "$HANDSEED")
                seed = i + 3 < count && lines[i + 2].Trim() == "5" && !String.IsNullOrWhiteSpace(lines[i + 3]);
            if (code != 0 || !IsHandleRecord(value)) continue;
            if (i + 3 >= count || lines[i + 2].Trim() != "5") return false;
            string handle = lines[i + 3].Trim();
            if (handle.Length == 0 || !handles.Add(handle)) return false;
        }
        return handling && seed && handles.Count > 0;
    }

    private static void TestDxfR12PostProcessor()
    {
        string dxf = string.Join("\n", new[]
        {
            "0", "SECTION", "2", "HEADER", "9", "$ACADVER", "1", "AC1009", "0", "ENDSEC",
            "0", "SECTION", "2", "TABLES", "0", "TABLE", "2", "STYLE", "70", "1",
            "0", "STYLE", "2", "PH-TSTYLE", "70", "0", "40", "1.0", "41", "1.0", "50", "0.0", "71", "0", "42", "1.0", "3", "txt", "4", "0",
            "0", "ENDTAB", "0", "ENDSEC", "0", "EOF", ""
        });
        string normalized = DxfR12PostProcessor.Normalize(dxf);
        AssertTrue(normalized.Contains("9\n$DWGCODEPAGE\n  3\nANSI_1254") || normalized.Contains("9\n$DWGCODEPAGE\n3\nANSI_1254"), "R12 postprocessor inserts Turkish code page when absent");
        AssertTrue(normalized.Contains("3\narial.ttf"), "R12 postprocessor replaces the PH-TSTYLE txt font with Arial");
        AssertTrue(DxfR12PostProcessor.Normalize(normalized) == normalized, "R12 postprocessor is idempotent");

        string wrongPage = normalized.Replace("ANSI_1254", "ANSI_1252");
        string wrongFont = wrongPage.Replace("arial.ttf", "txt");
        string fixedAgain = DxfR12PostProcessor.Normalize(wrongFont);
        AssertTrue(fixedAgain.Contains("ANSI_1254") && fixedAgain.Contains("arial.ttf"), "R12 postprocessor corrects existing but wrong page/font values");

        bool rejectedVersion = false;
        try { DxfR12PostProcessor.Normalize(dxf.Replace("AC1009", "AC1015")); }
        catch (InvalidDataException) { rejectedVersion = true; }
        AssertTrue(rejectedVersion, "R12 postprocessor refuses to guess when AC1009 header is missing");

        bool rejectedStyle = false;
        try { DxfR12PostProcessor.Normalize(dxf.Replace("PH-TSTYLE", "OTHER")); }
        catch (InvalidDataException) { rejectedStyle = true; }
        AssertTrue(rejectedStyle, "R12 postprocessor refuses a DXF without PH-TSTYLE");
    }

    private static void TestR12UnicodeEscapes()
    {
        string source = "Şehir: İğde, ıslak; ÇÖŞÜĞçöşüğ";
        string encoded = DxfTextEncoding.EscapeNonAscii(source);
        AssertTrue(encoded == "\\U+015Eehir: \\U+0130\\U+011Fde, \\U+0131slak; \\U+00C7\\U+00D6\\U+015E\\U+00DC\\U+011E\\U+00E7\\U+00F6\\U+015F\\U+00FC\\U+011F", "R12 text preserves Turkish upper/lowercase letters as Unicode escapes");
        AssertTrue(encoded.All(c => c <= 0x7f), "escaped R12 text is independent of ANSI code page");
        AssertTrue(DxfTextEncoding.EscapeNonAscii("Route 123 / A-1") == "Route 123 / A-1", "ASCII text remains unchanged");
    }

    private static bool IsHandleRecord(string recordType)
    {
        switch (recordType.ToUpperInvariant())
        {
            case "VPORT": case "LTYPE": case "LAYER": case "STYLE": case "VIEW": case "UCS": case "APPID": case "DIMSTYLE":
            case "BLOCK": case "ENDBLK": case "LINE": case "POINT": case "CIRCLE": case "TEXT":
                return true;
            default:
                return false;
        }
    }

    public static int Main(string[] args)
    {
        try
        {
            if (args.Length == 2 && args[0] == "--write-dxf-samples")
            {
                WriteDxfSamples(args[1]);
                return 0;
            }
            if (args.Length != 0) throw new ArgumentException("Usage: TestRunner.exe [--write-dxf-samples output-directory]");
            TestOpenSample();
            TestClosedSampleAndEndpointIndexFix();
            TestClosedGenericEndName();
            TestDayaliSample();
            TestR12UnicodeEscapes();
            TestDxfR12PostProcessor();
            Console.WriteLine("PASS: " + _assertions + " assertions across open, closed, dayali, Rasat import, four TXT reports, styled XLSX, Unicode escapes and R12 DXF metadata.");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex.ToString());
            return 1;
        }
    }
}
