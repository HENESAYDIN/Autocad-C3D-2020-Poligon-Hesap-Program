#!/usr/bin/env python3
"""Validate the combined legacy 2020-24 + AutoCAD 2026 net8/net10 setup model."""
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "installer/combined2020-2026"


def load_bundle_generator():
    path = ROOT / "installer/package-bundle.py"
    spec = importlib.util.spec_from_file_location("package_bundle", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    bundle = load_bundle_generator()
    matrix_path = INSTALLER / "supported-versions.json"
    _, profiles, selectors = bundle.load_matrix(matrix_path)
    assert [p["id"] for p in profiles] == [
        "2025-autocad-net8", "2025-autocad-net10",
        "2026-autocad-net8", "2026-autocad-net10",
    ]
    selectors_by_id = {s["id"]: s for s in selectors}
    assert selectors_by_id["autocad-2025"]["product_info"] == "AutoCAD 2025"
    assert bundle.resolve_runtime_profile(selectors_by_id["autocad-2025"], "V.188.0.0") == "2025-autocad-net8"
    assert bundle.resolve_runtime_profile(selectors_by_id["autocad-2025"], "V.189.0.0") == "2025-autocad-net10"
    assert bundle.resolve_runtime_profile(selectors_by_id["autocad-2025"], "V.200.0.0") == "2025-autocad-net10"
    assert bundle.resolve_runtime_profile(selectors_by_id["autocad-2025"], "X.189.0.0") is None
    assert selectors_by_id["autocad-2026"]["product_info"] == "AutoCAD 2026"
    assert bundle.resolve_runtime_profile(selectors_by_id["autocad-2026"], "W.178.0.0") == "2026-autocad-net8"
    assert bundle.resolve_runtime_profile(selectors_by_id["autocad-2026"], "W.179.0.0") == "2026-autocad-net10"
    assert bundle.resolve_runtime_profile(selectors_by_id["autocad-2026"], "W.180.0.0") == "2026-autocad-net10"
    assert bundle.resolve_runtime_profile(selectors_by_id["autocad-2026"], "X.179.0.0") is None

    legacy_dir = INSTALLER / "LegacyBundle"
    legacy_xml = ET.parse(legacy_dir / "PackageContents.xml").getroot()
    legacy_req = legacy_xml.find("./Components/RuntimeRequirements")
    assert legacy_req is not None
    assert (legacy_req.get("SeriesMin"), legacy_req.get("SeriesMax")) == ("R23.1", "R24.3")
    assert legacy_req.get("Platform") == "AutoCAD*"
    for name in ["PoligonHesap.AutoCAD2020.dll", "PoligonHesap.Core.dll"]:
        assert (legacy_dir / "Contents" / name).read_bytes()[:2] == b"MZ"

    setup_source = (INSTALLER / "PoligonHesap_Setup.nsi").read_text(encoding="utf-8")
    legacy_detector = (INSTALLER / "LegacyDetection.nsh").read_text(encoding="utf-8")
    assert 'InstallDir "$APPDATA\\Autodesk\\ApplicationPlugins"' in setup_source
    assert "RequestExecutionLevel user" in setup_source
    assert 'WriteRegStr HKCU "${UNINSTALL_KEY}"' in setup_source
    assert 'DeleteRegKey HKCU "${UNINSTALL_KEY}"' in setup_source
    assert "LegacyBundle\\*.*" in setup_source
    assert "PoligonHesap.bundle" in setup_source
    assert "PoligonHesap_2026-autocad-net8.bundle" in (INSTALLER / "InstallProfiles.nsh").read_text()
    assert "PoligonHesap_2026-autocad-net10.bundle" in (INSTALLER / "InstallProfiles.nsh").read_text()
    for series in ["R23.1", "R24.0", "R24.1", "R24.2", "R24.3"]:
        assert series in legacy_detector

    # Exercise the production bundler in an isolated fixture and verify only two 2026 bundles result.
    with tempfile.TemporaryDirectory(prefix="polhesap-combined-test-") as temp:
        temp = Path(temp)
        fake_build = temp / "publish"
        output_packages = temp / "Packages"
        installer_copy = temp / "installer"
        installer_copy.mkdir()
        shutil.copy2(matrix_path, installer_copy / matrix_path.name)
        script = ROOT / "installer/package-bundle.py"
        shutil.copy2(script, installer_copy / script.name)
        for profile in profiles:
            out = fake_build / profile["id"]
            out.mkdir(parents=True)
            for filename in [bundle.plugin_name(profile) + ".dll", "PoligonHesap.Core.dll"]:
                (out / filename).write_bytes(b"MZ" + bytes(2048))
        subprocess.run([
            sys.executable, str(installer_copy / script.name),
            "--matrix", str(installer_copy / matrix_path.name),
            "--build-root", str(fake_build),
            "--bundle-root", str(output_packages),
        ], check=True, capture_output=True, text=True)
        staged = sorted(p.name for p in output_packages.glob("*.bundle"))
        assert staged == [
            "PoligonHesap_2025-autocad-net10.bundle",
            "PoligonHesap_2025-autocad-net8.bundle",
            "PoligonHesap_2026-autocad-net10.bundle",
            "PoligonHesap_2026-autocad-net8.bundle",
        ]
        for profile in profiles:
            package = output_packages / bundle.bundle_name(profile)
            root = ET.parse(package / "PackageContents.xml").getroot()
            req = root.find("./Components/RuntimeRequirements")
            expected_series = "R25.0" if profile["year"] == 2025 else "R25.1"
            assert req is not None and req.get("SeriesMin") == expected_series
            assert len(list((package / "Contents").glob("*.dll"))) == 2

    print("Combined setup passed: legacy R23.1-R24.3 preserved; AutoCAD 2025 V.188 net8 / V.189+ net10; AutoCAD 2026 W.178 net8 / W.179+ net10; four modern bundles.")


if __name__ == "__main__":
    main()
