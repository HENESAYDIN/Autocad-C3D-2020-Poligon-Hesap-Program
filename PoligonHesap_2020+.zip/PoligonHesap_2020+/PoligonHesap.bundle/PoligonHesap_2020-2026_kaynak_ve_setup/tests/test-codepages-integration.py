#!/usr/bin/env python3
"""Regression checks for the .NET 8/10 Windows-1254 provider and staged bundle."""
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    plugin = (ROOT / "src/PoligonHesap.AutoCAD/PluginEntry.cs").read_text(encoding="utf-8")
    modern_project = (ROOT / "src/PoligonHesap.AutoCAD/PoligonHesap.AutoCAD.Modern.csproj").read_text(encoding="utf-8")
    core_project = (ROOT / "src/PoligonHesap.Core/PoligonHesap.Core.Modern.csproj").read_text(encoding="utf-8")
    assert "#if NETCOREAPP" in plugin
    assert "Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);" in plugin
    assert "System.Text.Encoding.CodePages" not in modern_project
    assert "net8.0-windows" in modern_project and "NETCOREAPP" in plugin
    assert "AppendTargetFrameworkToOutputPath" in modern_project
    assert "AppendTargetFrameworkToOutputPath" in core_project

    script_path = ROOT / "installer/package-bundle.py"
    spec = importlib.util.spec_from_file_location("package_bundle", script_path)
    bundle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bundle)
    matrix_path = ROOT / "installer/supported-versions.json"
    matrix, profiles, _ = bundle.load_matrix(matrix_path)

    with tempfile.TemporaryDirectory(prefix="polhesap-codepages-test-") as temp:
        temp = Path(temp)
        build_root = temp / "build"
        bundle_root = temp / "packages"
        for profile in profiles:
            out = build_root / profile["id"]
            out.mkdir(parents=True)
            plugin_name = bundle.plugin_name(profile) + ".dll"
            for name in [plugin_name, "PoligonHesap.Core.dll"]:
                (out / name).write_bytes(b"MZ" + bytes(2048))

        # Use a copied installer directory because the bundler also emits generated NSIS includes.
        installer_copy = temp / "installer"
        installer_copy.mkdir()
        shutil.copy2(matrix_path, installer_copy / matrix_path.name)
        shutil.copy2(script_path, installer_copy / script_path.name)
        subprocess.run([
            sys.executable, str(installer_copy / script_path.name),
            "--matrix", str(installer_copy / matrix_path.name),
            "--build-root", str(build_root),
            "--bundle-root", str(bundle_root),
        ], check=True, capture_output=True, text=True)

        for profile in profiles:
            contents = bundle_root / bundle.bundle_name(profile) / "Contents"
            codepages = contents / "System.Text.Encoding.CodePages.dll"
            assert not codepages.exists(), (profile["id"], "framework assembly must not be privately bundled")
            manifest = bundle_root / bundle.bundle_name(profile) / "PackageContents.xml"
            from xml.etree import ElementTree as ET
            entries = ET.parse(manifest).findall("./Components/ComponentEntry")
            assert len(entries) == 2, (profile["id"], "manifest dependency mismatch")

    print("CodePages integration passed: CP1254 registration, framework-owned provider, and 14 profile manifests.")


if __name__ == "__main__":
    main()
