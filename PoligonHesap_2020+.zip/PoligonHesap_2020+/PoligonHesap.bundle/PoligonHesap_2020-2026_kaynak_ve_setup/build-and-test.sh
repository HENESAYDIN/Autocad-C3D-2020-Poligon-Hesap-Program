#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build"
mkdir -p "$BUILD/Fixtures"
cp "$ROOT"/tests/PoligonHesap.Core.Tests/Fixtures/* "$BUILD/Fixtures/"
mcs -sdk:4.7 -langversion:6 -target:library -r:System.Core -r:System.Xml.Linq \
  -r:System.IO.Compression \
  -r:System.IO.Compression.FileSystem \
  -resource:"$ROOT/src/PoligonHesap.Core/Templates/Dayali.xlsx",PoligonHesap.Core.Templates.Dayali.xlsx \
  -resource:"$ROOT/src/PoligonHesap.Core/Templates/DayaliRasat.xlsx",PoligonHesap.Core.Templates.DayaliRasat.xlsx \
  -resource:"$ROOT/src/PoligonHesap.Core/Templates/Open.xlsx",PoligonHesap.Core.Templates.Open.xlsx \
  -resource:"$ROOT/src/PoligonHesap.Core/Templates/Closed.xlsx",PoligonHesap.Core.Templates.Closed.xlsx \
  -r:System.IO.Compression.FileSystem \
  -out:"$BUILD/PoligonHesap.Core.dll" \
  "$ROOT/src/PoligonHesap.Core/Models.cs" \
  "$ROOT/src/PoligonHesap.Core/TraverseCalculators.cs" \
  "$ROOT/src/PoligonHesap.Core/TextData.cs" \
  "$ROOT/src/PoligonHesap.Core/ReportWriter.cs" \
  "$ROOT/src/PoligonHesap.Core/XlsxWriter.cs" \
  "$ROOT/src/PoligonHesap.Core/DxfWriter.cs" \
  "$ROOT/src/PoligonHesap.Core/DxfTextEncoding.cs" \
  "$ROOT/src/PoligonHesap.Core/DxfR12PostProcessor.cs"
mcs -sdk:4.7 -langversion:6 -r:System.Core \
  -r:System.IO.Compression \
  -r:System.IO.Compression.FileSystem \
  -r:"$BUILD/PoligonHesap.Core.dll" \
  -out:"$BUILD/PoligonHesap.Core.Tests.exe" \
  "$ROOT/tests/PoligonHesap.Core.Tests/TestRunner.cs"
mono "$BUILD/PoligonHesap.Core.Tests.exe"
python3 "$ROOT/tests/test-runtime-profile-selection.py"
python3 "$ROOT/tests/test-codepages-integration.py"
python3 "$ROOT/tests/test-combined-installer.py"
