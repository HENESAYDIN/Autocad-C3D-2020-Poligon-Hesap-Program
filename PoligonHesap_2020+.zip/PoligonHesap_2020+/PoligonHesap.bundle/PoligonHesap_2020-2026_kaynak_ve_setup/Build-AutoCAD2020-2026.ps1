[CmdletBinding()]
param(
    [string]$ManagedApiPathNet8 = 'C:\Program Files\Autodesk\AutoCAD 2026',
    [string]$ManagedApiPathNet10 = '',
    [string]$Configuration = 'Release'
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$installerDir = Join-Path $root 'installer/combined2020-2026'
$matrixPath = Join-Path $installerDir 'supported-versions.json'
$matrix = Get-Content -Raw -LiteralPath $matrixPath | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace($ManagedApiPathNet10)) { $ManagedApiPathNet10 = $ManagedApiPathNet8 }

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { throw '.NET SDK 8 and 10 are required.' }
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) { $python = Get-Command py -ErrorAction SilentlyContinue }
if (-not $python) { throw 'Python 3 is required for bundle staging.' }
$nsis = Get-Command makensis -ErrorAction SilentlyContinue
if (-not $nsis) { throw 'NSIS (makensis) is required to create the Windows Setup.exe.' }

$legacyBundle = Join-Path $installerDir 'LegacyBundle'
foreach ($file in @('PackageContents.xml','Contents/PoligonHesap.AutoCAD2020.dll','Contents/PoligonHesap.Core.dll')) {
    $path = Join-Path $legacyBundle $file
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Legacy 2020–2024 payload is missing: $path" }
}
[xml]$legacyManifest = Get-Content -Raw -LiteralPath (Join-Path $legacyBundle 'PackageContents.xml')
$legacyRuntime = $legacyManifest.SelectSingleNode('/ApplicationPackage/Components/RuntimeRequirements')
if (-not $legacyRuntime -or $legacyRuntime.GetAttribute('SeriesMin') -ne 'R23.1' -or $legacyRuntime.GetAttribute('SeriesMax') -ne 'R24.3') {
    throw 'Legacy manifest must be restricted to AutoCAD 2020–2024 (R23.1–R24.3) so the 2020 DLL cannot load in AutoCAD 2026.'
}
$modernProject = Join-Path $root 'src/PoligonHesap.AutoCAD/PoligonHesap.AutoCAD.Modern.csproj'
$publishRoot = Join-Path $root 'build/publish-autocad2025-2026'
$packageRoot = Join-Path $installerDir 'Packages'
$managedByRuntime = @{
    net8 = [Environment]::ExpandEnvironmentVariables($ManagedApiPathNet8)
    net10 = [Environment]::ExpandEnvironmentVariables($ManagedApiPathNet10)
}

foreach ($profile in $matrix.profiles) {
    $runtime = [string]$profile.runtime
    $managedPath = $managedByRuntime[$runtime]
    foreach ($dll in @('accoremgd.dll','acdbmgd.dll','acmgd.dll','AdWindows.dll')) {
        $candidate = Join-Path $managedPath $dll
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            throw "Profile '$($profile.id)' API references incomplete: $candidate not found. Use the corresponding AutoCAD 2026 net8/net10 API reference folder."
        }
    }
    $output = Join-Path $publishRoot ([string]$profile.id)
    New-Item -ItemType Directory -Force -Path $output | Out-Null
    $coreFramework = ([string]$profile.target_framework) -replace '-windows$',''
    $dotnetArgs = @(
        'build', $modernProject, '--configuration', $Configuration,
        '-p:EnableWindowsTargeting=true',
        "-p:AutoCADYear=$($profile.year)",
        "-p:AutoCADBuildSuffix=$($profile.assembly_suffix)",
        "-p:AutoCADTargetFramework=$($profile.target_framework)",
        "-p:AutoCADCoreTargetFramework=$coreFramework",
        "-p:AutoCADManagedPath=$managedPath",
        "-p:AutoCADOutputDir=$output"
    )
    & $dotnet.Source @dotnetArgs
    if ($LASTEXITCODE -ne 0) { throw "dotnet build failed for $($profile.id) (exit $LASTEXITCODE)." }

    $plugin = "PoligonHesap.AutoCAD$($profile.year)$($profile.assembly_suffix).dll"
    foreach ($file in @((Join-Path $output $plugin),(Join-Path $output 'PoligonHesap.Core.dll'))) {
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Build output missing: $file" }
        if ((Get-Item -LiteralPath $file).Length -lt 1024) { throw "Build output looks invalid: $file" }
    }
    Write-Host "Built $($profile.label) using $managedPath"
}

& $python.Source (Join-Path $root 'installer/package-bundle.py') '--matrix' $matrixPath '--build-root' $publishRoot '--bundle-root' $packageRoot
if ($LASTEXITCODE -ne 0) { throw "Bundle staging failed (exit $LASTEXITCODE)." }

$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Force -Path $dist | Out-Null
$setup = Join-Path $dist 'PoligonHesap_Setup.exe'
if (Test-Path -LiteralPath $setup) { Remove-Item -LiteralPath $setup -Force }
Push-Location $installerDir
try {
    & $nsis.Source '-V3' 'PoligonHesap_Setup.nsi'
    if ($LASTEXITCODE -ne 0) { throw "NSIS failed (exit $LASTEXITCODE)." }
}
finally { Pop-Location }
if (-not (Test-Path -LiteralPath $setup -PathType Leaf)) { throw "Setup.exe was not produced: $setup" }
Write-Host "SUCCESS: combined AutoCAD 2020–2024 + AutoCAD 2025/2026 net8/net10 installer created at $setup"
