using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace PoligonHesap.Core
{
    public sealed class RawRasatObservation
    {
        public string StationName { get; set; }
        public string TargetName { get; set; }
        public double Face1Gon { get; set; }
        public double Face2Gon { get; set; }
        public double DistanceM { get; set; }
    }

    public static class SurveyTextReader
    {
        private static readonly Regex Separators = new Regex("[\\t ;,]+", RegexOptions.Compiled);
        private static readonly XNamespace MainNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly XNamespace RelNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private static readonly XNamespace PackageRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";

        public static List<SurveyPoint> ReadControlPoints(string path)
        {
            var points = new List<SurveyPoint>();
            int lineNo = 0;
            foreach (string[] fields in Rows(path))
            {
                lineNo++;
                if (fields.All(String.IsNullOrWhiteSpace)) continue;
                if (fields.Length < 3) throw new FormatException("Koordinat dosyası, satır " + lineNo + ": Nokta Y X [Z] biçimi bekleniyor.");
                double y, x, z = 0.0;
                if (!TryNumber(fields[1], out y) || !TryNumber(fields[2], out x))
                {
                    if (IsHeader(fields[0])) continue;
                    throw new FormatException("Koordinat dosyası, satır " + lineNo + ": Y ve X sayısal olmalıdır.");
                }
                if (fields.Length > 3 && !String.IsNullOrWhiteSpace(fields[3]) && !TryNumber(fields[3], out z))
                    throw new FormatException("Koordinat dosyası, satır " + lineNo + ": Z sayısal olmalıdır.");
                points.Add(new SurveyPoint(fields[0].Trim(), y, x, z));
            }
            if (points.Count == 0) throw new FormatException("Koordinat dosyasında geçerli nokta yok.");
            return points;
        }

        public static List<TraverseObservation> ReadSummary(string path)
        {
            var rows = new List<TraverseObservation>();
            int lineNo = 0;
            foreach (string[] fields in Rows(path))
            {
                lineNo++;
                if (fields.All(String.IsNullOrWhiteSpace)) continue;
                if (fields.Length < 2) throw new FormatException("Özet dosyası, satır " + lineNo + ": Nokta Açı [Kenar] biçimi bekleniyor.");
                double angle;
                if (!TryNumber(fields[1], out angle))
                {
                    if (IsHeader(fields[0])) continue;
                    throw new FormatException("Özet dosyası, satır " + lineNo + ": Açı sayısal olmalıdır.");
                }
                double distance = 0.0;
                if (fields.Length > 2 && !String.IsNullOrWhiteSpace(fields[2]) && !TryNumber(fields[2], out distance))
                    throw new FormatException("Özet dosyası, satır " + lineNo + ": Kenar uzunluğu sayısal olmalıdır.");
                rows.Add(new TraverseObservation(fields[0].Trim(), angle, distance));
            }
            if (rows.Count == 0) throw new FormatException("Özet dosyasında geçerli kayıt yok.");
            return rows;
        }

        public static List<RawRasatObservation> ReadRasat(string path)
        {
            var rows = new List<RawRasatObservation>();
            int lineNo = 0;
            foreach (string[] fields in Rows(path))
            {
                lineNo++;
                if (fields.All(String.IsNullOrWhiteSpace)) continue;
                if (fields.Length < 5) throw new FormatException("Rasat dosyası, satır " + lineNo + ": İstasyon Hedef Yüz-I Yüz-II Kenar biçimi bekleniyor.");
                double f1, f2, distance;
                if (!TryNumber(fields[2], out f1) || !TryNumber(fields[3], out f2) || !TryNumber(fields[4], out distance))
                {
                    if (IsHeader(fields[0])) continue;
                    throw new FormatException("Rasat dosyası, satır " + lineNo + ": yüz ölçüleri ve yatay mesafe sayısal olmalıdır.");
                }
                rows.Add(new RawRasatObservation { StationName = fields[0].Trim(), TargetName = fields[1].Trim(), Face1Gon = GonMath.Normalize(f1), Face2Gon = GonMath.Normalize(f2), DistanceM = distance });
            }
            if (rows.Count == 0) throw new FormatException("Rasat dosyasında geçerli kayıt yok.");
            return rows;
        }

        public static List<TraverseObservation> BuildSummaryFromRasat(IList<RawRasatObservation> raw, string backReference, string startName, string endName, string forwardReference)
        {
            if (raw == null || raw.Count == 0) throw new ArgumentException("Önce Rasat Karne yükleyin.");
            var route = new List<string> { backReference.Trim(), startName.Trim() };
            var visited = new HashSet<string>(route.Select(TraverseInput.NormalizeName));
            string current = startName.Trim();
            int guard = 0;
            while (TraverseInput.NormalizeName(current) != TraverseInput.NormalizeName(endName))
            {
                var next = raw.FirstOrDefault(r => TraverseInput.NormalizeName(r.StationName) == TraverseInput.NormalizeName(current) && !visited.Contains(TraverseInput.NormalizeName(r.TargetName)));
                if (next == null) throw new FormatException("Rasat içinde " + current + " noktasından devam eden güzergâh kaydı bulunamadı.");
                current = next.TargetName.Trim();
                route.Add(current);
                visited.Add(TraverseInput.NormalizeName(current));
                if (++guard > raw.Count + 2) throw new FormatException("Rasat güzergâh zinciri döngü içeriyor.");
            }
            if (route.Count < 4) throw new FormatException("Dayalı güzergâhta başlangıç, en az bir ara nokta ve son nokta gerekir.");

            var observations = new List<TraverseObservation>();
            for (int i = 1; i < route.Count; i++)
            {
                string station = route[i];
                string previous = route[i - 1];
                string next = i + 1 < route.Count ? route[i + 1] : forwardReference.Trim();
                double backDirection = DirectionAt(raw, station, previous);
                double forwardDirection = DirectionAt(raw, station, next);
                double angle = GonMath.Normalize(forwardDirection - backDirection);
                double distance = 0.0;
                if (i + 1 < route.Count) distance = MeanDistance(raw, station, next);
                observations.Add(new TraverseObservation(station, angle, distance));
            }
            return observations;
        }

        public static List<TraverseObservation> ResolveRouteObservations(IList<TraverseObservation> summaryRows, IList<RawRasatObservation> raw, string backReference, string startName, string endName, string forwardReference, bool preferSummary)
        {
            bool hasSummary = summaryRows != null && summaryRows.Count > 0;
            bool hasRasat = raw != null && raw.Count > 0;
            if (preferSummary)
            {
                if (!hasSummary) throw new InvalidOperationException("Özet Karne seçili ancak kullanılabilir açı/kenar satırı yok.");
                return summaryRows.Select(o => new TraverseObservation(o.StationName, o.AngleGon, o.DistanceM)).ToList();
            }
            if (hasSummary && !hasRasat)
                return summaryRows.Select(o => new TraverseObservation(o.StationName, o.AngleGon, o.DistanceM)).ToList();
            if (!hasRasat)
                throw new InvalidOperationException("Özet Karne yükleyin veya Rasat Karnesi yükleyerek güzergâhı otomatik kurun.");
            return BuildSummaryFromRasat(raw, backReference, startName, endName, forwardReference);
        }

        private static double DirectionAt(IList<RawRasatObservation> raw, string station, string target)
        {
            var row = raw.FirstOrDefault(r => TraverseInput.NormalizeName(r.StationName) == TraverseInput.NormalizeName(station) && TraverseInput.NormalizeName(r.TargetName) == TraverseInput.NormalizeName(target));
            if (row == null) throw new FormatException("Rasat içinde " + station + " -> " + target + " doğrultusu bulunamadı.");
            double face2Reduced = GonMath.Normalize(row.Face2Gon - 200.0);
            return GonMath.Normalize(row.Face1Gon + GonMath.Difference(face2Reduced, row.Face1Gon) / 2.0);
        }

        private static double MeanDistance(IList<RawRasatObservation> raw, string station, string target)
        {
            var forward = raw.FirstOrDefault(r => TraverseInput.NormalizeName(r.StationName) == TraverseInput.NormalizeName(station) && TraverseInput.NormalizeName(r.TargetName) == TraverseInput.NormalizeName(target));
            var reverse = raw.FirstOrDefault(r => TraverseInput.NormalizeName(r.StationName) == TraverseInput.NormalizeName(target) && TraverseInput.NormalizeName(r.TargetName) == TraverseInput.NormalizeName(station));
            if (forward == null && reverse == null) throw new FormatException("Rasat içinde " + station + " -> " + target + " kenarı bulunamadı.");
            if (forward == null) return reverse.DistanceM;
            if (reverse == null) return forward.DistanceM;
            return (forward.DistanceM + reverse.DistanceM) / 2.0;
        }

        private static IEnumerable<string[]> Rows(string path)
        {
            if (String.IsNullOrWhiteSpace(path) || !File.Exists(path)) throw new FileNotFoundException("Girdi dosyası bulunamadı.", path);
            string extension = Path.GetExtension(path).ToLowerInvariant();
            if (extension == ".xlsx" || extension == ".xlsm") return ReadXlsx(path);
            if (extension == ".xls") return ReadXlsWithExcel(path);
            return File.ReadAllLines(path, DetectEncoding(path))
                .Select(line => line.Trim())
                .Where(line => line.Length > 0 && !line.StartsWith("#") && !line.StartsWith(";") && !line.StartsWith("//"))
                .Select(line => Separators.Split(line));
        }

        private static List<string[]> ReadXlsx(string path)
        {
            using (var zip = ZipFile.OpenRead(path))
            {
                var shared = new List<string>();
                var sharedEntry = zip.GetEntry("xl/sharedStrings.xml");
                if (sharedEntry != null)
                {
                    using (var s = sharedEntry.Open())
                    {
                        var x = XDocument.Load(s);
                        foreach (var item in x.Root.Elements(MainNs + "si")) shared.Add(String.Concat(item.Descendants(MainNs + "t").Select(t => (string)t)));
                    }
                }
                var workbookEntry = zip.GetEntry("xl/workbook.xml");
                string sheetPath = "xl/worksheets/sheet1.xml";
                if (workbookEntry != null)
                {
                    using (var s = workbookEntry.Open())
                    {
                        var workbook = XDocument.Load(s);
                        var firstSheet = workbook.Descendants(MainNs + "sheet").FirstOrDefault();
                        if (firstSheet != null)
                        {
                            string rid = (string)firstSheet.Attribute(RelNs + "id");
                            var relEntry = zip.GetEntry("xl/_rels/workbook.xml.rels");
                            if (relEntry != null)
                            {
                                using (var rs = relEntry.Open())
                                {
                                    var rels = XDocument.Load(rs);
                                    var rel = rels.Descendants(PackageRelNs + "Relationship").FirstOrDefault(r => (string)r.Attribute("Id") == rid);
                                    if (rel != null)
                                    {
                                        string target = (string)rel.Attribute("Target");
                                        sheetPath = target.StartsWith("/") ? target.TrimStart('/') : "xl/" + target.Replace("\\", "/");
                                    }
                                }
                            }
                        }
                    }
                }
                var sheetEntry = zip.GetEntry(sheetPath);
                if (sheetEntry == null) sheetEntry = zip.GetEntry("xl/worksheets/sheet1.xml");
                if (sheetEntry == null) throw new InvalidDataException("XLSX içindeki ilk çalışma sayfası bulunamadı.");
                using (var s = sheetEntry.Open())
                {
                    var sheet = XDocument.Load(s);
                    var rows = new List<string[]>();
                    foreach (var row in sheet.Descendants(MainNs + "sheetData").Elements(MainNs + "row"))
                    {
                        var values = new SortedDictionary<int, string>();
                        foreach (var cell in row.Elements(MainNs + "c"))
                        {
                            string address = (string)cell.Attribute("r");
                            int column = ColumnNumber(address);
                            string type = (string)cell.Attribute("t");
                            string value = String.Empty;
                            if (type == "inlineStr") value = String.Concat(cell.Descendants(MainNs + "t").Select(t => (string)t));
                            else
                            {
                                var v = cell.Element(MainNs + "v");
                                value = v == null ? String.Empty : v.Value;
                                if (type == "s")
                                {
                                    int index;
                                    if (Int32.TryParse(value, out index) && index >= 0 && index < shared.Count) value = shared[index];
                                }
                            }
                            values[column] = value;
                        }
                        if (values.Count == 0) continue;
                        string[] rowValues = new string[values.Keys.Max()];
                        foreach (var pair in values) rowValues[pair.Key - 1] = pair.Value;
                        rows.Add(rowValues);
                    }
                    return rows;
                }
            }
        }

        private static List<string[]> ReadXlsWithExcel(string path)
        {
            object app = null, book = null, sheets = null, sheet = null, range = null, cells = null;
            try
            {
                Type appType = Type.GetTypeFromProgID("Excel.Application", false);
                if (appType == null) throw new PlatformNotSupportedException("Eski .xls dosyası için bu bilgisayarda Microsoft Excel kurulmalı; dosyayı .xlsx olarak kaydedip yeniden deneyin.");
                app = Activator.CreateInstance(appType);
                object books = Get(app, "Workbooks");
                book = Invoke(books, "Open", path);
                sheets = Get(book, "Worksheets");
                sheet = Invoke(sheets, "Item", 1);
                range = Get(sheet, "UsedRange");
                object rowObject = Get(range, "Rows"); object columnObject = Get(range, "Columns");
                int rowCount = Convert.ToInt32(Get(rowObject, "Count"), CultureInfo.InvariantCulture);
                int columnCount = Convert.ToInt32(Get(columnObject, "Count"), CultureInfo.InvariantCulture);
                cells = Get(range, "Cells");
                var result = new List<string[]>();
                for (int r = 1; r <= rowCount; r++)
                {
                    var row = new string[columnCount];
                    for (int c = 1; c <= columnCount; c++)
                    {
                        object cell = Invoke(cells, "Item", r, c);
                        object value = Get(cell, "Value2");
                        row[c - 1] = value == null ? String.Empty : Convert.ToString(value, CultureInfo.InvariantCulture);
                    }
                    result.Add(row);
                }
                Invoke(book, "Close", false);
                Invoke(app, "Quit");
                return result;
            }
            catch (PlatformNotSupportedException) { throw; }
            catch (Exception ex) { throw new IOException("Excel .xls dosyası okunamadı: " + ex.Message, ex); }
            finally
            {
                try { if (book != null) Invoke(book, "Close", false); } catch { }
                try { if (app != null) Invoke(app, "Quit"); } catch { }
                Release(app); Release(book); Release(sheets); Release(sheet); Release(range); Release(cells);
            }
        }

        private static object Get(object target, string property)
        {
            return target.GetType().InvokeMember(property, BindingFlags.GetProperty | BindingFlags.Public | BindingFlags.Instance, null, target, null, CultureInfo.InvariantCulture);
        }
        private static object Invoke(object target, string method, params object[] args)
        {
            return target.GetType().InvokeMember(method, BindingFlags.InvokeMethod | BindingFlags.Public | BindingFlags.Instance, null, target, args, CultureInfo.InvariantCulture);
        }
        private static void Release(object value)
        {
            if (value != null && System.Runtime.InteropServices.Marshal.IsComObject(value)) System.Runtime.InteropServices.Marshal.ReleaseComObject(value);
        }
        private static int ColumnNumber(string address)
        {
            int col = 0;
            foreach (char c in address.TakeWhile(Char.IsLetter)) col = col * 26 + Char.ToUpperInvariant(c) - 'A' + 1;
            return Math.Max(1, col);
        }
        private static bool IsHeader(string first)
        {
            string text = (first ?? String.Empty).ToLowerInvariant();
            return text.Contains("nokta") || text.Contains("point") || text.Contains("istasyon") || text.Contains("station") || text.Contains("poligon");
        }
        private static bool TryNumber(string value, out double number)
        {
            try { number = GonMath.ParseNumber(value); return true; } catch { number = 0.0; return false; }
        }
        private static Encoding DetectEncoding(string path)
        {
            using (var reader = new StreamReader(path, true)) { reader.Peek(); return reader.CurrentEncoding; }
        }
    }
}
