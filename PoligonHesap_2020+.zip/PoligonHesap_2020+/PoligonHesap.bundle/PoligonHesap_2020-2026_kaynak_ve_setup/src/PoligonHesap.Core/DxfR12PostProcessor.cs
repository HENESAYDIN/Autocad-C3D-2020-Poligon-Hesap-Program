using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace PoligonHesap.Core
{
    /// <summary>
    /// Normalizes metadata that AutoCAD's AC1009 exporter may omit or replace:
    /// the legacy code page and the primary font file of PH-TSTYLE.
    /// </summary>
    public static class DxfR12PostProcessor
    {
        private sealed class Pair
        {
            public string CodeText;
            public int Code;
            public string Value;
        }

        public static string Normalize(string dxfText)
        {
            if (dxfText == null) throw new ArgumentNullException("dxfText");
            string newline = dxfText.IndexOf("\r\n", StringComparison.Ordinal) >= 0 ? "\r\n" : "\n";
            string normalizedNewlines = dxfText.Replace("\r\n", "\n").Replace('\r', '\n');
            bool trailingNewline = normalizedNewlines.EndsWith("\n", StringComparison.Ordinal);
            string[] lines = normalizedNewlines.Split('\n');
            int lineCount = trailingNewline ? lines.Length - 1 : lines.Length;
            if (lineCount % 2 != 0) throw new InvalidDataException("DXF grup kodları çift satır halinde değil.");

            var pairs = new List<Pair>(lineCount / 2 + 4);
            for (int i = 0; i < lineCount; i += 2)
            {
                int code;
                if (!Int32.TryParse(lines[i].Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out code))
                    throw new InvalidDataException("DXF grup kodu okunamadı: " + lines[i]);
                pairs.Add(new Pair { CodeText = lines[i], Code = code, Value = lines[i + 1] });
            }

            EnsureTurkishCodePage(pairs);
            EnsureArialStyle(pairs);

            var output = new StringBuilder(dxfText.Length + 64);
            for (int i = 0; i < pairs.Count; i++)
            {
                output.Append(pairs[i].CodeText).Append('\n');
                output.Append(pairs[i].Value).Append('\n');
            }
            if (!trailingNewline && output.Length > 0) output.Length--;
            return output.ToString().Replace("\n", newline);
        }

        private static void EnsureTurkishCodePage(List<Pair> pairs)
        {
            for (int i = 0; i < pairs.Count; i++)
            {
                if (pairs[i].Code != 9 || !String.Equals(pairs[i].Value.Trim(), "$DWGCODEPAGE", StringComparison.OrdinalIgnoreCase)) continue;
                if (i + 1 < pairs.Count && pairs[i + 1].Code == 3)
                {
                    pairs[i + 1].Value = "ANSI_1254";
                }
                else
                {
                    pairs.Insert(i + 1, new Pair { CodeText = "  3", Code = 3, Value = "ANSI_1254" });
                }
                return;
            }

            for (int i = 0; i + 1 < pairs.Count; i++)
            {
                if (pairs[i].Code == 9 && String.Equals(pairs[i].Value.Trim(), "$ACADVER", StringComparison.OrdinalIgnoreCase) &&
                    pairs[i + 1].Code == 1 && String.Equals(pairs[i + 1].Value.Trim(), "AC1009", StringComparison.Ordinal))
                {
                    pairs.InsertRange(i + 2, new[]
                    {
                        new Pair { CodeText = "  9", Code = 9, Value = "$DWGCODEPAGE" },
                        new Pair { CodeText = "  3", Code = 3, Value = "ANSI_1254" }
                    });
                    return;
                }
            }
            throw new InvalidDataException("R12 DXF başlığında $ACADVER=AC1009 bulunamadığından ANSI_1254 kod sayfası eklenemedi.");
        }

        private static void EnsureArialStyle(List<Pair> pairs)
        {
            bool styleFound = false;
            for (int i = 0; i < pairs.Count; i++)
            {
                if (pairs[i].Code != 0 || !String.Equals(pairs[i].Value.Trim(), "STYLE", StringComparison.OrdinalIgnoreCase)) continue;
                int end = i + 1;
                while (end < pairs.Count && pairs[end].Code != 0) end++;

                int nameIndex = -1;
                int fontIndex = -1;
                for (int j = i + 1; j < end; j++)
                {
                    if (pairs[j].Code == 2 && String.Equals(pairs[j].Value.Trim(), "PH-TSTYLE", StringComparison.OrdinalIgnoreCase))
                        nameIndex = j;
                    if (pairs[j].Code == 3) fontIndex = j;
                }
                if (nameIndex < 0) { i = end - 1; continue; }

                styleFound = true;
                if (fontIndex >= 0)
                    pairs[fontIndex].Value = "arial.ttf";
                else
                    pairs.Insert(nameIndex + 1, new Pair { CodeText = "  3", Code = 3, Value = "arial.ttf" });
            }
            if (!styleFound) throw new InvalidDataException("R12 DXF STYLE tablosunda PH-TSTYLE bulunamadı.");
        }
    }
}
