using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace PoligonHesap.Core
{
    public sealed class LegacyReportSet
    {
        public string OutputDirectory { get; set; }
        public string CalculationPath { get; set; }
        public string AnglePath { get; set; }
        public string EdgePath { get; set; }
        public string CoordinatePath { get; set; }
        public string CsvPath { get; set; }
    }

    public static class ReportWriter
    {
        private static readonly CultureInfo Invariant = CultureInfo.InvariantCulture;
        private static readonly int[] TableWidths = { 8, 10, 10, 10, 10, 10, 12, 12, 8 };
        private const int BoxWidth = 98;
        public const string LegalText = "Hesap, 2018-Büyük Ölçekli Harita ve Harita Bilgileri Üretim Yönetmeliği ile 04.10.2025 tarihli değişiklik hükümleri dikkate alınarak yapılmıştır.";

        public static LegacyReportSet WriteLegacySet(string outputDirectory, TraverseInput input, TraverseResult result)
        {
            if (String.IsNullOrWhiteSpace(outputDirectory)) throw new ArgumentException("Çıktı klasörü belirtilmedi.");
            if (input == null || result == null) throw new ArgumentNullException("Hesap girdisi/sonucu boş olamaz.");
            Directory.CreateDirectory(outputDirectory);
            string stem = SafeFileStem(input.RouteNumber);
            var files = new LegacyReportSet
            {
                OutputDirectory = outputDirectory,
                CalculationPath = Path.Combine(outputDirectory, "PoligonHesap_" + stem + ".txt"),
                AnglePath = Path.Combine(outputDirectory, "PoligonAçı_" + stem + ".txt"),
                EdgePath = Path.Combine(outputDirectory, "PoligonKenar_" + stem + ".txt"),
                CoordinatePath = Path.Combine(outputDirectory, "PoligonKoord_" + stem + ".txt"),
                CsvPath = Path.Combine(outputDirectory, "PoligonKoord_" + stem + ".csv")
            };
            Write1254(files.CalculationPath, BuildCalculation(input, result));
            Write1254(files.AnglePath, BuildAngles(input, result));
            Write1254(files.EdgePath, BuildEdges(input, result));
            Write1254(files.CoordinatePath, BuildCoordinates(input, result));
            WriteCsv(files.CsvPath, result);
            return files;
        }

        // Kept as a detailed diagnostic report for callers which used the first .NET draft.
        public static void WriteText(string path, TraverseInput input, TraverseResult result)
        {
            using (var writer = new StreamWriter(path, false, new UTF8Encoding(true)))
            {
                writer.WriteLine("POLİGON HESABI — " + ModeName(result.Mode));
                writer.WriteLine("Koordinat kuralı: Y=easting, X=northing; semt 0 gon=kuzey.");
                writer.WriteLine("Açı birimi: gon. 1 gon = 10,000 cc.");
                writer.WriteLine("Başlangıç semti: " + F(result.StartBearingGon, 4) + " gon");
                if (result.HasKnownEnd)
                {
                    writer.WriteLine("Açı kapanma hatası: " + F(result.AngularMisclosureGon, 8) + " gon (" + F(result.AngularMisclosureGon * 10000.0, 2) + " cc)");
                    writer.WriteLine("Açı toleransı: " + F(result.AngularToleranceGon, 8) + " gon (" + F(result.AngularToleranceGon * 10000.0, 2) + " cc)");
                    writer.WriteLine("Açı kontrolü: " + (result.AngularTolerancePassed ? "GEÇTİ" : "TOLERANS DIŞI"));
                    writer.WriteLine("Koordinat kapanması Fy/Fx/Fs: " + F(result.Fy, 4) + " / " + F(result.Fx, 4) + " / " + F(result.Fs, 4) + " m");
                    writer.WriteLine("Koordinat toleransı: " + F(result.CoordinateToleranceM, 4) + " m — " + (result.CoordinateTolerancePassed ? "GEÇTİ" : "TOLERANS DIŞI"));
                    writer.WriteLine("Beklenen son koordinat Y/X: " + F(result.ExpectedEndY, 3) + " / " + F(result.ExpectedEndX, 3));
                }
                else writer.WriteLine("Kapanma kontrolü: UYGULANMAZ (açık poligon yeni bir son nokta üretir).");
                writer.WriteLine("Toplam kenar: " + F(result.TotalDistanceM, 3) + " m");
                writer.WriteLine();
                writer.WriteLine("Nokta;Y (m);X (m);Not");
                foreach (var point in result.Points)
                    writer.WriteLine(E(point.Name) + ";" + F(point.Y, 3) + ";" + F(point.X, 3) + ";" + (result.HasKnownEnd && TraverseInput.NormalizeName(point.Name) == TraverseInput.NormalizeName(input.EndName) ? "hesaplanan son nokta" : String.Empty));
                writer.WriteLine();
                writer.WriteLine("Başlangıç;Bitiş;Açı (gon);Açı düzeltmesi (gon);Semt (gon);Kenar (m);dY (m);dX (m);Düzeltilmiş Y;Düzeltilmiş X");
                foreach (var leg in result.Legs)
                    writer.WriteLine(E(leg.FromName) + ";" + E(leg.ToName) + ";" + F(leg.AngleGon, 4) + ";" + F(leg.AngleCorrectionGon, 8) + ";" + F(leg.BearingGon, 4) + ";" + F(leg.DistanceM, 3) + ";" + F(leg.RawDY, 4) + ";" + F(leg.RawDX, 4) + ";" + F(leg.Y, 3) + ";" + F(leg.X, 3));
                writer.WriteLine();
                writer.WriteLine("Yöntem notu: " + result.Notes);
            }
        }

        public static void WriteCsv(string path, TraverseResult result)
        {
            using (var writer = new StreamWriter(path, false, new UTF8Encoding(true)))
            {
                writer.WriteLine("Point,Y_m,X_m");
                foreach (var point in result.Points)
                    writer.WriteLine(Csv(point.Name) + "," + F(point.Y, 3) + "," + F(point.X, 3));
            }
        }

        public static string ModeName(TraverseMode mode)
        {
            if (mode == TraverseMode.Dayali) return "DAYALI POLİGON";
            if (mode == TraverseMode.Acik) return "AÇIK POLİGON";
            return "KAPALI POLİGON";
        }

        public static string SafeFileStem(string value)
        {
            string text = String.IsNullOrWhiteSpace(value) ? "1" : value.Trim();
            foreach (char c in Path.GetInvalidFileNameChars()) text = text.Replace(c, '_');
            text = text.Replace(' ', '_');
            return text.Length == 0 ? "1" : text;
        }

        public static void GetEdgeMeasurements(TraverseInput input, TraverseLegResult leg, out double first, out double second, out double average, out double difference)
        {
            var observations = input == null ? null : input.RawRasatObservations;
            var forward = observations == null ? null : observations.FirstOrDefault(r => TraverseInput.NormalizeName(r.StationName) == TraverseInput.NormalizeName(leg.FromName) && TraverseInput.NormalizeName(r.TargetName) == TraverseInput.NormalizeName(leg.ToName));
            var reverse = observations == null ? null : observations.FirstOrDefault(r => TraverseInput.NormalizeName(r.StationName) == TraverseInput.NormalizeName(leg.ToName) && TraverseInput.NormalizeName(r.TargetName) == TraverseInput.NormalizeName(leg.FromName));
            first = forward == null ? leg.DistanceM : forward.DistanceM;
            second = reverse == null ? first : reverse.DistanceM;
            average = (first + second) / 2.0;
            difference = Math.Abs(first - second);
        }

        private static string BuildCalculation(TraverseInput input, TraverseResult result)
        {
            var lines = new StringBuilder();
            lines.AppendLine(Border());
            lines.AppendLine(Box(Center("P O L İ G O N   H E S A B I", BoxWidth)));
            lines.AppendLine(Border());
            lines.AppendLine(Box(Left("Şehir/Kasaba Adı: " + Or(input.CityName, "-"), BoxWidth)));
            lines.AppendLine(Box(Left("Güzergah No     : " + Or(input.RouteNumber, "1"), BoxWidth)));
            lines.AppendLine(Border());
            lines.AppendLine(TableBorder());
            lines.AppendLine(TableRow("Nokta", "Kırılma", "Açıklık", "Kenarlar", "DY", "DX", "KOORDİNATLAR Y", "X", "Nokta"));
            lines.AppendLine(TableRow("No", "Açısı (β)", "Açısı (α)", "S(m)", "(m)", "(m)", "Y (m)", "X (m)", "No"));
            lines.AppendLine(TableBorder());
            var legByTo = result.Legs.ToDictionary(l => TraverseInput.NormalizeName(l.ToName), l => l);
            foreach (var p in result.Points)
            {
                TraverseLegResult leg;
                legByTo.TryGetValue(TraverseInput.NormalizeName(p.Name), out leg);
                lines.AppendLine(TableRow(p.Name, leg == null ? "" : F(leg.AngleGon, 4), "", "", "", "", F(p.Y, 2), F(p.X, 2), p.Name));
                if (leg != null)
                    lines.AppendLine(TableRow("", F(leg.AngleCorrectionGon * 10000.0, 0), F(leg.BearingGon, 4), F(leg.DistanceM, 2), F(leg.AdjustedDY, 2), F(leg.AdjustedDX, 2), "", "", ""));
            }
            lines.AppendLine(TableBorder());
            if (result.HasKnownEnd)
            {
                lines.AppendLine(Box(Left("[β]: " + F(result.CalculatedEndBearingGon, 4) + "    [S]: " + F(result.TotalDistanceM, 2) + "    fy: " + F(result.Fy, 2) + "m    fx: " + F(result.Fx, 2) + "m", BoxWidth)));
                lines.AppendLine(Box(Left("FB: " + F(result.AngularMisclosureGon * 10000.0, 0) + "cc    Max FB: " + F(result.AngularToleranceGon * 10000.0, 0) + "cc", BoxWidth)));
                lines.AppendLine(Box(Left("Koordinat kapanması Fs: " + F(result.Fs, 2) + "m    " + (result.CoordinateTolerancePassed ? "OK" : "TOLERANS DIŞI"), BoxWidth)));
            }
            else lines.AppendLine(Box(Left("Açık poligonda kapanış hatası hesaplanmaz.", BoxWidth)));
            lines.AppendLine(Border());
            if (result.Mode == TraverseMode.Dayali || result.Mode == TraverseMode.Kapali) lines.AppendLine(LegalText);
            lines.AppendLine("Hesap; " + DateText(input.CalculationDate) + " tarihinde " + Or(input.OperatorName, Environment.MachineName) + " tarafından yapılmıştır.");
            return lines.ToString();
        }

        private static string BuildAngles(TraverseInput input, TraverseResult result)
        {
            var b = ReportHeader("P O L İ G O N   A Ç I   H E S A B I", input);
            b.AppendLine("+--------+----------+----------+----------+----------+");
            b.AppendLine("| Nokta  | Açı (gon)| Düzeltme | Semt (gon)| Durum    |");
            b.AppendLine("+--------+----------+----------+----------+----------+");
            foreach (var leg in result.Legs)
                b.AppendLine("|" + Fit(leg.FromName, 8) + "|" + Fit(F(leg.AngleGon, 4), 10, true) + "|" + Fit(F(leg.AngleCorrectionGon * 10000.0, 0) + "cc", 10, true) + "|" + Fit(F(leg.BearingGon, 4), 10, true) + "|" + Fit("OK", 10) + "|");
            b.AppendLine("+--------+----------+----------+----------+----------+");
            b.AppendLine("Açı kapanma hatası: " + F(result.AngularMisclosureGon * 10000.0, 0) + " cc");
            b.AppendLine("Açı toleransı: " + F(result.AngularToleranceGon * 10000.0, 0) + " cc");
            b.AppendLine("Sonuç: " + (result.AngularTolerancePassed ? "KAPANDI" : "TOLERANS DIŞI"));
            return b.ToString();
        }

        private static string BuildEdges(TraverseInput input, TraverseResult result)
        {
            var b = ReportHeader("P O L İ G O N   K E N A R   Ö L Ç Ü M Ü   V E   H E S A B I", input);
            b.AppendLine("+------------------+----------+----------+----------+----------+----------+");
            b.AppendLine("| Poligon Kenarı   | I. Ölçü  | II. Ölçü | Ortalama | Fark     | Hata sın.|");
            b.AppendLine("+------------------+----------+----------+----------+----------+----------+");
            foreach (var leg in result.Legs)
            {
                double first, second, average, difference;
                GetEdgeMeasurements(input, leg, out first, out second, out average, out difference);
                double tolerance = 0.006 * Math.Sqrt(Math.Max(average, 0.0)) + 0.02;
                b.AppendLine("|" + Fit(leg.FromName + "<-->" + leg.ToName, 18) + "|" + Fit(F(first, 2), 10, true) + "|" + Fit(F(second, 2), 10, true) + "|" + Fit(F(average, 2), 10, true) + "|" + Fit(F(difference, 2), 10, true) + "|" + Fit(F(tolerance, 6), 10, true) + "|");
            }
            b.AppendLine("+------------------+----------+----------+----------+----------+----------+");
            b.AppendLine("Hata sınırı; D=0.006*Sqr(S)+0.02m");
            b.AppendLine("Ölçü türü: Özet/hesaplanan kenar uzunluğu; Rasat modunda iki yüz ortalaması.");
            return b.ToString();
        }

        private static string BuildCoordinates(TraverseInput input, TraverseResult result)
        {
            var b = ReportHeader("P O L İ G O N   K O O R D İ N E   Ö Z E T   Ç İ Z E L G E S İ", input);
            b.AppendLine("+----------+------------+------------+------------+----------------------+");
            b.AppendLine("|  Nokta   |      Y     |      X     |      Z     |      Düşünceler      |");
            b.AppendLine("| Numarası |     (m)    |     (m)    |     (m)    |   (Açıklama-Notlar)  |");
            b.AppendLine("+----------+------------+------------+------------+----------------------+");
            foreach (var p in input.ControlPoints)
            {
                string role = Role(input, p.Name);
                b.AppendLine("|" + Fit(p.Name, 10) + "|" + Fit(F(p.Y, 3), 12, true) + "|" + Fit(F(p.X, 3), 12, true) + "|" + Fit(F(p.Z, 3), 12, true) + "|" + Fit(role, 22) + "|");
            }
            foreach (var p in result.Points.Where(p => input.FindPoint(p.Name) == null))
                b.AppendLine("|" + Fit(p.Name, 10) + "|" + Fit(F(p.Y, 3), 12, true) + "|" + Fit(F(p.X, 3), 12, true) + "|" + Fit(F(p.Z, 3), 12, true) + "|" + Fit("Yeni Nokta", 22) + "|");
            b.AppendLine("+----------+------------+------------+------------+----------------------+");
            b.AppendLine("Hesap; " + DateText(input.CalculationDate) + " tarihinde " + Or(input.OperatorName, Environment.MachineName) + " tarafından yapılmıştır.");
            return b.ToString();
        }

        private static StringBuilder ReportHeader(string title, TraverseInput input)
        {
            var b = new StringBuilder();
            b.AppendLine(title);
            b.AppendLine(new String('-', Math.Max(56, title.Length)));
            b.AppendLine("Şehir/Kasaba Adı: " + Or(input.CityName, "-"));
            b.AppendLine("Güzergah No     : " + Or(input.RouteNumber, "1"));
            b.AppendLine("Tarih           : " + DateText(input.CalculationDate));
            b.AppendLine("Hesabı Yapan    : " + Or(input.OperatorName, Environment.MachineName));
            b.AppendLine();
            return b;
        }

        private static string Role(TraverseInput input, string name)
        {
            string n = TraverseInput.NormalizeName(name);
            if (n == TraverseInput.NormalizeName(input.BackReferenceName)) return "Semt Alınan";
            if (n == TraverseInput.NormalizeName(input.StartName)) return "Başlangıç";
            if (n == TraverseInput.NormalizeName(input.EndName)) return "Son";
            if (n == TraverseInput.NormalizeName(input.ForwardReferenceName)) return "Semt Kapanan";
            return "Kontrol Noktası";
        }

        private static string DateText(DateTime value)
        {
            return value.ToString("dd.MM.yyyy", CultureInfo.GetCultureInfo("tr-TR"));
        }

        private static void Write1254(string path, string text)
        {
            Encoding encoding;
            try { encoding = Encoding.GetEncoding(1254); }
            catch { encoding = new UTF8Encoding(false); }
            File.WriteAllText(path, text, encoding);
        }

        private static string Border() { return "+" + new String('-', BoxWidth) + "+"; }
        private static string Box(string content) { return "|" + Fit(content, BoxWidth) + "|"; }
        private static string Left(string content, int width) { return Fit(content, width); }
        private static string Center(string content, int width)
        {
            string s = content ?? String.Empty;
            if (s.Length >= width) return s.Substring(0, width);
            int left = (width - s.Length) / 2;
            return new String(' ', left) + s + new String(' ', width - s.Length - left);
        }
        private static string TableBorder()
        {
            return "+" + String.Join("+", TableWidths.Select(w => new String('-', w)).ToArray()) + "+";
        }
        private static string TableRow(params string[] cells)
        {
            var parts = new string[TableWidths.Length];
            for (int i = 0; i < parts.Length; i++) parts[i] = Fit(i < cells.Length ? cells[i] : String.Empty, TableWidths[i], i != 0);
            return "|" + String.Join("|", parts) + "|";
        }
        private static string Fit(string value, int width, bool right = false)
        {
            string s = value ?? String.Empty;
            if (s.Length > width) s = s.Substring(0, width);
            return right ? s.PadLeft(width) : s.PadRight(width);
        }
        private static string Or(string value, string fallback) { return String.IsNullOrWhiteSpace(value) ? fallback : value.Trim(); }
        private static string F(double value, int digits) { return value.ToString("F" + digits, Invariant); }
        private static string F(double value) { return value.ToString("0.####", Invariant); }
        private static string E(string text) { return (text ?? String.Empty).Replace(";", " ").Replace("\r", " ").Replace("\n", " "); }
        private static string Csv(string value) { return "\"" + (value ?? String.Empty).Replace("\"", "\"\"") + "\""; }
    }
}
