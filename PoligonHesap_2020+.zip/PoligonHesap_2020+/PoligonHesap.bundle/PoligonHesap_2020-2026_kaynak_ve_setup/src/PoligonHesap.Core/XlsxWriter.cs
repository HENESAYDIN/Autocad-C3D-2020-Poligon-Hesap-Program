using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Linq;

namespace PoligonHesap.Core
{
    public static class XlsxWriter
    {
        private static readonly XNamespace MainNs = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly XNamespace XmlNs = "http://www.w3.org/XML/1998/namespace";

        public static void Write(string path, TraverseInput input, TraverseResult result)
        {
            if (input == null || result == null) throw new ArgumentNullException("Excel raporu için girdi ve sonuç gereklidir.");
            bool dayaliRasat = result.Mode == TraverseMode.Dayali && input.ObservationsFromRasat && input.RawRasatObservations.Count > 0;
            string resource = result.Mode == TraverseMode.Dayali ? (dayaliRasat ? "DayaliRasat.xlsx" : "Dayali.xlsx") : result.Mode == TraverseMode.Acik ? "Open.xlsx" : "Closed.xlsx";
            string resourceName = "PoligonHesap.Core.Templates." + resource;
            using (Stream template = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
            {
                if (template == null) throw new FileNotFoundException("Gömülü Excel şablonu bulunamadı: " + resourceName);
                string folder = Path.GetDirectoryName(Path.GetFullPath(path));
                if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
                string tmp = path + ".tmp";
                if (File.Exists(tmp)) File.Delete(tmp);
                using (var output = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None)) template.CopyTo(output);
                try
                {
                    using (var zip = ZipFile.Open(tmp, ZipArchiveMode.Update))
                    {
                        if (result.Mode == TraverseMode.Dayali) FillDayali(zip, input, result);
                        else if (result.Mode == TraverseMode.Acik) FillOpen(zip, input, result);
                        else FillClosed(zip, input, result);
                    }
                    if (File.Exists(path)) File.Delete(path);
                    File.Move(tmp, path);
                }
                catch
                {
                    if (File.Exists(tmp)) File.Delete(tmp);
                    throw;
                }
            }
        }

        private static void FillDayali(ZipArchive zip, TraverseInput input, TraverseResult result)
        {
            XDocument summary = ReadSheet(zip, "xl/worksheets/sheet1.xml");
            XDocument calc = ReadSheet(zip, "xl/worksheets/sheet2.xml");
            bool dayaliRasat = input.ObservationsFromRasat && input.RawRasatObservations.Count > 0;
            XDocument angleSheet = dayaliRasat ? ReadSheet(zip, "xl/worksheets/sheet3.xml") : null;
            XDocument edgeSheet = dayaliRasat ? ReadSheet(zip, "xl/worksheets/sheet4.xml") : null;
            int interiorCount = Math.Max(0, result.Points.Count - 2);
            int extraSummary = Math.Max(0, interiorCount - 5);
            if (extraSummary > 0) InsertRows(summary, 11, extraSummary, 10, true);
            SetCell(summary, "C2", ":" + TextOr(input.CityName, ""));
            SetCell(summary, "C3", ":" + TextOr(input.RouteNumber, "1"));
            for (int i = 0; i < interiorCount; i++)
            {
                int row = 6 + i;
                SurveyPoint p = result.Points[i + 1];
                SetCell(summary, "A" + row, p.Name);
                SetCell(summary, "B" + row, p.Y);
                SetCell(summary, "C" + row, p.X);
                SetCell(summary, "D" + row, p.Z);
                SetCell(summary, "E" + row, "Yeni Nokta");
            }
            SetCell(summary, "A" + (11 + extraSummary), Attribution(input));

            int extraCalc = Math.Max(0, result.Legs.Count - 6) * 2;
            if (extraCalc > 0) InsertRows(calc, 19, extraCalc, 18, false);
            SetCell(calc, "C2", ":" + TextOr(input.CityName, ""));
            SetCell(calc, "C3", ":" + TextOr(input.RouteNumber, "1"));
            FillControl(calc, 6, input.FindPoint(input.BackReferenceName), input.BackReferenceName);
            SetCell(calc, "C7", result.StartBearingGon);
            FillPointRow(calc, 8, input.RequirePoint(input.StartName, "Başlangıç"),
                input.Observations.Count == 0 ? (double?)null : input.Observations[0].AngleGon);
            for (int i = 0; i < result.Legs.Count; i++)
            {
                TraverseLegResult leg = result.Legs[i];
                int measureRow = 9 + i * 2;
                int pointRow = measureRow + 1;
                SetCell(calc, "B" + measureRow, leg.AngleCorrectionGon * 10000.0);
                SetCell(calc, "C" + measureRow, leg.BearingGon);
                SetCell(calc, "D" + measureRow, leg.DistanceM);
                SetCell(calc, "E" + measureRow, leg.AdjustedDY);
                SetCell(calc, "F" + measureRow, leg.AdjustedDX);
                SurveyPoint p = result.Points.FirstOrDefault(x => TraverseInput.NormalizeName(x.Name) == TraverseInput.NormalizeName(leg.ToName));
                if (p != null)
                    FillPointRow(calc, pointRow, p, i + 1 < input.Observations.Count ? (double?)input.Observations[i + 1].AngleGon : null);
            }
            int forwardBearingRow = 9 + result.Legs.Count * 2;
            int forwardRow = forwardBearingRow + 1;
            SetCell(calc, "C" + forwardBearingRow, result.ExpectedEndBearingGon);
            FillControl(calc, forwardRow, input.FindPoint(input.ForwardReferenceName), input.ForwardReferenceName);
            int footer = 23 + extraCalc;
            SetCell(calc, "A" + footer, "[β]:");
            SetCell(calc, "B" + footer, result.CalculatedEndBearingGon);
            SetCell(calc, "D" + footer, result.TotalDistanceM);
            SetCell(calc, "E" + footer, result.Legs.Sum(l => l.AdjustedDY));
            SetCell(calc, "F" + footer, result.Legs.Sum(l => l.AdjustedDX));
            SetCell(calc, "G" + footer, result.ExpectedEndY - input.RequirePoint(input.StartName, "Başlangıç").Y);
            SetCell(calc, "H" + footer, result.ExpectedEndX - input.RequirePoint(input.StartName, "Başlangıç").X);
            SetCell(calc, "B" + (footer + 1), result.ExpectedEndBearingGon);
            SetCell(calc, "E" + (footer + 1), "fy: " + F(result.Fy * 100.0, 0) + "cm");
            SetCell(calc, "F" + (footer + 1), "fx: " + F(result.Fx * 100.0, 0) + "cm");
            SetCell(calc, "A" + (footer + 2), "Fβ:");
            SetCell(calc, "B" + (footer + 2), F(result.AngularMisclosureGon * 10000.0, 0) + "cc");
            SetCell(calc, "C" + (footer + 2), "Max Fβ:");
            SetCell(calc, "D" + (footer + 2), F(result.AngularToleranceGon * 10000.0, 0) + "cc");
            SetCell(calc, "B" + (footer + 4), "Max Boyuna Hata");
            SetCell(calc, "D" + (footer + 4), ": " + F(result.CoordinateToleranceM * 100.0, 0) + "cm");
            SetCell(calc, "E" + (footer + 4), "fl: " + F(result.Fy * 100.0, 0) + "cm");
            SetCell(calc, "B" + (footer + 5), "Max Enine Hata");
            SetCell(calc, "D" + (footer + 5), ": " + F(result.CoordinateToleranceM * 50.0, 0) + "cm");
            SetCell(calc, "E" + (footer + 5), "fq: " + F(result.Fx * 100.0, 0) + "cm");
            SetCell(calc, "B" + (footer + 6), "Lineer Kapanma Hatası");
            SetCell(calc, "D" + (footer + 6), ": " + F(result.Fs * 100.0, 0) + "cm");
            SetCell(calc, "E" + (footer + 6), "fs: " + F(result.Fs * 100.0, 0) + "cm");
            SetCell(calc, "A" + (footer + 7), ReportWriter.LegalText);
            SetCell(calc, "A" + (footer + 8), Attribution(input));
            if (dayaliRasat)
            {
                FillDayaliAngleSheet(angleSheet, input);
                FillDayaliEdgeSheet(edgeSheet, input, result);
            }
            ReplaceSheet(zip, "xl/worksheets/sheet1.xml", summary);
            ReplaceSheet(zip, "xl/worksheets/sheet2.xml", calc);
            if (dayaliRasat)
            {
                ReplaceSheet(zip, "xl/worksheets/sheet3.xml", angleSheet);
                ReplaceSheet(zip, "xl/worksheets/sheet4.xml", edgeSheet);
            }
        }

        private static void FillDayaliAngleSheet(XDocument doc, TraverseInput input)
        {
            var groups = new System.Collections.Generic.List<System.Collections.Generic.List<RawRasatObservation>>();
            foreach (RawRasatObservation raw in input.RawRasatObservations)
            {
                string key = TraverseInput.NormalizeName(raw.StationName);
                if (groups.Count == 0 || TraverseInput.NormalizeName(groups[groups.Count - 1][0].StationName) != key)
                    groups.Add(new System.Collections.Generic.List<RawRasatObservation>());
                groups[groups.Count - 1].Add(raw);
            }

            int footer = 6 + input.RawRasatObservations.Count;
            PrepareDynamicRows(doc, 6, input.RawRasatObservations.Count + 1, 6, footer);
            SetCell(doc, "C2", ":" + TextOr(input.CityName, ""));
            SetCell(doc, "C3", ":" + TextOr(input.RouteNumber, "1"));
            int row = 6;
            foreach (var group in groups)
            {
                int firstRow = row;
                double previousFace1 = 0.0, previousFace2 = 0.0;
                for (int i = 0; i < group.Count; i++, row++)
                {
                    RawRasatObservation raw = group[i];
                    if (i == 0) SetCell(doc, "A" + row, raw.StationName);
                    SetCell(doc, "B" + row, raw.TargetName);
                    SetCell(doc, "C" + row, raw.Face1Gon);
                    SetCell(doc, "D" + row, raw.Face2Gon);
                    double reduced1 = i == 0 ? 0.0 : GonMath.Normalize(raw.Face1Gon - previousFace1);
                    double reduced2 = i == 0 ? 0.0 : GonMath.Normalize(raw.Face2Gon - previousFace2);
                    SetCell(doc, "E" + row, reduced1);
                    SetCell(doc, "F" + row, reduced2);
                    SetCell(doc, "G" + row, (reduced1 + reduced2) / 2.0);
                    previousFace1 = raw.Face1Gon;
                    previousFace2 = raw.Face2Gon;
                }
                if (row - firstRow > 1) AddMergeRange(doc, "A" + firstRow + ":A" + (row - 1));
            }
            SetCell(doc, "A" + footer, Attribution(input));
            AddMergeRange(doc, "A" + footer + ":G" + footer);
            NormalizeSheetRows(doc);
        }

        private static void FillDayaliEdgeSheet(XDocument doc, TraverseInput input, TraverseResult result)
        {
            int firstFooter = 6 + result.Legs.Count;
            int attribution = firstFooter + 1;
            PrepareDynamicRows(doc, 6, result.Legs.Count + 2, 6, attribution);
            SetCell(doc, "C2", ":" + TextOr(input.CityName, ""));
            SetCell(doc, "C3", ":" + TextOr(input.RouteNumber, "1"));
            for (int i = 0; i < result.Legs.Count; i++)
            {
                TraverseLegResult leg = result.Legs[i];
                int row = 6 + i;
                double first, second, average, difference;
                ReportWriter.GetEdgeMeasurements(input, leg, out first, out second, out average, out difference);
                SetCell(doc, "A" + row, leg.FromName + "<-->" + leg.ToName);
                SetCell(doc, "C" + row, first);
                SetCell(doc, "D" + row, second);
                SetCell(doc, "E" + row, average);
                SetCell(doc, "F" + row, difference);
                SetCell(doc, "G" + row, 0.006 * Math.Sqrt(Math.Max(0.0, average)) + 0.02);
                AddMergeRange(doc, "A" + row + ":B" + row);
            }
            SetCell(doc, "A" + firstFooter, "Hata sınırı: D = 0.006 × √S + 0.02 m");
            SetCell(doc, "A" + attribution, Attribution(input));
            AddMergeRange(doc, "A" + firstFooter + ":G" + firstFooter);
            AddMergeRange(doc, "A" + attribution + ":G" + attribution);
            NormalizeSheetRows(doc);
        }

        private static void PrepareDynamicRows(XDocument doc, int firstRow, int count, int prototypeRow, int finalRow)
        {
            XElement data = doc.Root.Element(MainNs + "sheetData");
            XElement prototype = data.Elements(MainNs + "row").FirstOrDefault(r => (int)r.Attribute("r") == prototypeRow);
            if (prototype == null) throw new InvalidDataException("Excel rapor şablonunda biçim satırı bulunamadı: " + prototypeRow);
            XElement template = new XElement(prototype);
            foreach (XElement row in data.Elements(MainNs + "row").Where(r => (int)r.Attribute("r") >= firstRow).ToList()) row.Remove();
            for (int i = 0; i < count; i++)
            {
                int rowNumber = firstRow + i;
                XElement clone = new XElement(template);
                clone.SetAttributeValue("r", rowNumber);
                foreach (XElement cell in clone.Elements(MainNs + "c").ToList())
                {
                    cell.SetAttributeValue("r", ReplaceAddressRow((string)cell.Attribute("r"), rowNumber));
                    ClearValue(cell);
                }
                data.Add(clone);
            }
            XElement merges = doc.Root.Element(MainNs + "mergeCells");
            if (merges != null)
            {
                foreach (XElement merge in merges.Elements(MainNs + "mergeCell").Where(m => AddressRow(((string)m.Attribute("ref")).Split(':').Last()) >= firstRow).ToList()) merge.Remove();
                merges.SetAttributeValue("count", merges.Elements(MainNs + "mergeCell").Count());
            }
            XElement dimension = doc.Root.Element(MainNs + "dimension");
            if (dimension != null) dimension.SetAttributeValue("ref", "A1:G" + Math.Max(5, finalRow));
        }

        private static void AddMergeRange(XDocument doc, string range)
        {
            XElement merges = doc.Root.Element(MainNs + "mergeCells");
            if (merges == null)
            {
                merges = new XElement(MainNs + "mergeCells");
                doc.Root.Element(MainNs + "sheetData").AddAfterSelf(merges);
            }
            merges.Add(new XElement(MainNs + "mergeCell", new XAttribute("ref", range)));
            merges.SetAttributeValue("count", merges.Elements(MainNs + "mergeCell").Count());
        }

        private static void NormalizeSheetRows(XDocument doc)
        {
            XElement data = doc.Root.Element(MainNs + "sheetData");
            var rows = data.Elements(MainNs + "row").OrderBy(r => (int)r.Attribute("r")).ToArray();
            foreach (XElement row in rows) OrderCells(row);
            data.RemoveNodes();
            foreach (XElement row in rows) data.Add(row);
        }

        private static void FillOpen(ZipArchive zip, TraverseInput input, TraverseResult result)
        {
            XDocument calc = ReadSheet(zip, "xl/worksheets/sheet1.xml");
            XDocument summary = ReadSheet(zip, "xl/worksheets/sheet2.xml");
            int extraCalc = Math.Max(0, result.Legs.Count - 5) * 2;
            if (extraCalc > 0) InsertRows(calc, 20, extraCalc, 19, false);
            int summaryCount = result.Points.Count + 1;
            int extraSummary = Math.Max(0, summaryCount - 8);
            if (extraSummary > 0) InsertRows(summary, 14, extraSummary, 13, true);
            SetCell(calc, "A2", "Şehir/Kasaba Adı:" + TextOr(input.CityName, ""));
            SetCell(calc, "A3", "Güzergah No     :" + TextOr(input.RouteNumber, "1"));
            SetCell(summary, "A3", "Şehir/Kasaba Adı:" + TextOr(input.CityName, ""));
            SetCell(summary, "A4", "Güzergah No     :" + TextOr(input.RouteNumber, "1"));
            FillControl(calc, 7, input.FindPoint(input.BackReferenceName), input.BackReferenceName);
            SetCell(calc, "C8", result.StartBearingGon);
            FillPointRow(calc, 9, input.RequirePoint(input.StartName, "Başlangıç"), input.Observations.Count > 0 ? (double?)input.Observations[0].AngleGon : null);
            for (int i = 0; i < result.Legs.Count; i++)
            {
                TraverseLegResult leg = result.Legs[i];
                int measureRow = 10 + i * 2; int pointRow = measureRow + 1;
                SetCell(calc, "C" + measureRow, leg.BearingGon); SetCell(calc, "D" + measureRow, leg.DistanceM); SetCell(calc, "E" + measureRow, leg.AdjustedDY); SetCell(calc, "F" + measureRow, leg.AdjustedDX);
                SurveyPoint point = result.Points.FirstOrDefault(p => TraverseInput.NormalizeName(p.Name) == TraverseInput.NormalizeName(leg.ToName));
                if (point != null) FillPointRow(calc, pointRow, point, i + 1 < input.Observations.Count ? (double?)input.Observations[i + 1].AngleGon : null);
            }
            SetCell(calc, "A" + (22 + extraCalc), "Açık poligonda kapanış hatası hesaplanmaz.");
            SurveyPoint back = input.RequirePoint(input.BackReferenceName, "Semt Alınan");
            SetCell(summary, "A7", back.Name); SetCell(summary, "B7", back.Y); SetCell(summary, "C7", back.X); SetCell(summary, "D7", back.Z); SetCell(summary, "E7", "Semt Alınan");
            for (int i = 0; i < result.Points.Count; i++)
            {
                SurveyPoint p = result.Points[i]; int row = 8 + i;
                SetCell(summary, "A" + row, p.Name); SetCell(summary, "B" + row, p.Y); SetCell(summary, "C" + row, p.X); SetCell(summary, "D" + row, p.Z);
                SetCell(summary, "E" + row, i == 0 ? "Başlangıç" : "Yeni Nokta");
            }
            SetCell(summary, "A" + (15 + extraSummary), Attribution(input));
            ReplaceSheet(zip, "xl/worksheets/sheet1.xml", calc);
            ReplaceSheet(zip, "xl/worksheets/sheet2.xml", summary);
        }

        private static void FillClosed(ZipArchive zip, TraverseInput input, TraverseResult result)
        {
            XDocument summary = ReadSheet(zip, "xl/worksheets/sheet1.xml");
            XDocument calc = ReadSheet(zip, "xl/worksheets/sheet2.xml");
            XDocument edges = ReadSheet(zip, "xl/worksheets/sheet3.xml");
            int extraSummary = Math.Max(0, result.Points.Count - 8);
            if (extraSummary > 0) InsertRows(summary, 14, extraSummary, 13, false);
            int extraCalc = Math.Max(0, result.Legs.Count - 6) * 2;
            if (extraCalc > 0) InsertRows(calc, 19, extraCalc, 18, false);
            int extraEdges = Math.Max(0, result.Legs.Count - 7);
            if (extraEdges > 0) InsertRows(edges, 13, extraEdges, 11, false);
            SetCell(summary, "C2", ":" + TextOr(input.CityName, "")); SetCell(summary, "C3", ":" + TextOr(input.RouteNumber, "1"));
            for (int i = 0; i < result.Points.Count; i++)
            {
                SurveyPoint p = result.Points[i]; int r = 6 + i;
                SetCell(summary, "A" + r, p.Name); SetCell(summary, "B" + r, p.Y); SetCell(summary, "C" + r, p.X); SetCell(summary, "D" + r, p.Z); SetCell(summary, "E" + r, i == 0 ? "Başlangıç" : "Yeni Nokta");
            }
            SetCell(summary, "A" + (14 + extraSummary), Attribution(input));
            SetCell(calc, "C2", ":" + TextOr(input.CityName, "")); SetCell(calc, "C3", ":" + TextOr(input.RouteNumber, "1"));
            FillControl(calc, 6, input.FindPoint(input.BackReferenceName), input.BackReferenceName);
            SetCell(calc, "C7", result.StartBearingGon);
            FillPointRow(calc, 8, input.RequirePoint(input.StartName, "Başlangıç"), input.Observations.Count > 0 ? (double?)input.Observations[0].AngleGon : null);
            for (int i = 0; i < result.Legs.Count; i++)
            {
                var leg = result.Legs[i]; int mr = 9 + i * 2; int pr = mr + 1;
                SetCell(calc, "B" + mr, leg.AngleCorrectionGon * 10000.0); SetCell(calc, "C" + mr, leg.BearingGon); SetCell(calc, "D" + mr, leg.DistanceM); SetCell(calc, "E" + mr, leg.AdjustedDY); SetCell(calc, "F" + mr, leg.AdjustedDX);
                var p = result.Points.FirstOrDefault(x => TraverseInput.NormalizeName(x.Name) == TraverseInput.NormalizeName(leg.ToName));
                if (p != null) FillPointRow(calc, pr, p, i + 1 < input.Observations.Count ? (double?)input.Observations[i + 1].AngleGon : null);
            }
            int forwardBearingRow = 9 + result.Legs.Count * 2;
            SetCell(calc, "C" + forwardBearingRow, result.ExpectedEndBearingGon);
            FillControl(calc, forwardBearingRow + 1, input.FindPoint(input.ForwardReferenceName), input.ForwardReferenceName);
            int footer = 23 + extraCalc;
            SetCell(calc, "A" + footer, "Fβ:"); SetCell(calc, "B" + footer, result.AngularMisclosureGon * 10000.0); SetCell(calc, "C" + footer, "Max Fβ:"); SetCell(calc, "D" + footer, result.AngularToleranceGon * 10000.0);
            SetCell(calc, "A" + (footer + 1), "fy"); SetCell(calc, "B" + (footer + 1), result.Fy); SetCell(calc, "C" + (footer + 1), "fx"); SetCell(calc, "D" + (footer + 1), result.Fx);
            SetCell(calc, "A" + (footer + 2), "Lineer Kapanma Hatası"); SetCell(calc, "B" + (footer + 2), result.Fs);
            SetCell(calc, "A" + (footer + 4), ReportWriter.LegalText); SetCell(calc, "A" + (footer + 5), Attribution(input));
            SetCell(edges, "B2", TextOr(input.CityName, "")); SetCell(edges, "B3", TextOr(input.RouteNumber, "1"));
            for (int i = 0; i < result.Legs.Count; i++)
            {
                var leg = result.Legs[i]; int r = 6 + i;
                double first, second, average, difference;
                ReportWriter.GetEdgeMeasurements(input, leg, out first, out second, out average, out difference);
                double tol = 0.006 * Math.Sqrt(Math.Max(0, average)) + 0.02;
                SetCell(edges, "A" + r, leg.FromName + "<-->" + leg.ToName); SetCell(edges, "B" + r, first); SetCell(edges, "C" + r, second); SetCell(edges, "D" + r, average); SetCell(edges, "E" + r, difference); SetCell(edges, "F" + r, tol);
            }
            SetCell(edges, "B" + (13 + extraEdges), "D=0.006*Sqr(S)+0.02m"); SetCell(edges, "B" + (14 + extraEdges), Attribution(input));
            ReplaceSheet(zip, "xl/worksheets/sheet1.xml", summary); ReplaceSheet(zip, "xl/worksheets/sheet2.xml", calc); ReplaceSheet(zip, "xl/worksheets/sheet3.xml", edges);
        }

        private static void FillControl(XDocument doc, int row, SurveyPoint point, string name)
        {
            if (point == null) return;
            SetCell(doc, "A" + row, name); SetCell(doc, "G" + row, point.Y); SetCell(doc, "H" + row, point.X); SetCell(doc, "I" + row, name);
        }

        private static void FillPointRow(XDocument doc, int row, SurveyPoint point, double? angle)
        {
            SetCell(doc, "A" + row, point.Name); SetCell(doc, "I" + row, point.Name);
            if (angle.HasValue) SetCell(doc, "B" + row, angle.Value);
            SetCell(doc, "G" + row, point.Y); SetCell(doc, "H" + row, point.X);
        }

        private static XDocument ReadSheet(ZipArchive zip, string path)
        {
            var entry = zip.GetEntry(path);
            if (entry == null) throw new InvalidDataException("Excel şablonunda çalışma sayfası bulunamadı: " + path);
            using (var stream = entry.Open()) return XDocument.Load(stream);
        }

        private static void ReplaceSheet(ZipArchive zip, string path, XDocument doc)
        {
            var old = zip.GetEntry(path); if (old != null) old.Delete();
            var entry = zip.CreateEntry(path, CompressionLevel.Optimal);
            using (var stream = entry.Open())
            using (var writer = new StreamWriter(stream, new UTF8Encoding(false))) doc.Save(writer, SaveOptions.DisableFormatting);
        }

        private static void SetCell(XDocument doc, string address, string value)
        {
            XElement cell = EnsureCell(doc, address);
            ClearValue(cell);
            if (value == null) return;
            cell.SetAttributeValue("t", "inlineStr");
            var text = new XElement(MainNs + "t", value);
            if (value.Length > 0 && (Char.IsWhiteSpace(value[0]) || Char.IsWhiteSpace(value[value.Length - 1]))) text.SetAttributeValue(XmlNs + "space", "preserve");
            cell.Add(new XElement(MainNs + "is", text));
        }

        private static void SetCell(XDocument doc, string address, double value)
        {
            XElement cell = EnsureCell(doc, address);
            ClearValue(cell);
            cell.SetAttributeValue("t", null);
            cell.Add(new XElement(MainNs + "v", value.ToString("0.############", CultureInfo.InvariantCulture)));
        }

        private static void SetCell(XDocument doc, string address, int value) { SetCell(doc, address, (double)value); }

        private static XElement EnsureCell(XDocument doc, string address)
        {
            int rowNumber = AddressRow(address);
            XElement data = doc.Root.Element(MainNs + "sheetData");
            XElement row = data.Elements(MainNs + "row").FirstOrDefault(x => (int)x.Attribute("r") == rowNumber);
            if (row == null)
            {
                row = new XElement(MainNs + "row", new XAttribute("r", rowNumber));
                data.Add(row);
            }
            XElement cell = row.Elements(MainNs + "c").FirstOrDefault(x => (string)x.Attribute("r") == address);
            if (cell == null)
            {
                cell = new XElement(MainNs + "c", new XAttribute("r", address));
                row.Add(cell);
                OrderCells(row);
            }
            return cell;
        }

        private static void ClearValue(XElement cell)
        {
            cell.Attribute("t")?.Remove();
            cell.Elements(MainNs + "f").Remove(); cell.Elements(MainNs + "v").Remove(); cell.Elements(MainNs + "is").Remove();
        }

        private static void InsertRows(XDocument doc, int start, int count, int prototypeRow, bool addSummaryMerges)
        {
            if (count <= 0) return;
            XElement data = doc.Root.Element(MainNs + "sheetData");
            XElement prototype = data.Elements(MainNs + "row").FirstOrDefault(r => (int)r.Attribute("r") == prototypeRow);
            if (prototype == null) throw new InvalidDataException("Excel şablonunda stil satırı yok: " + prototypeRow);
            var clones = Enumerable.Range(0, count).Select(_ => new XElement(prototype)).ToArray();
            foreach (var row in data.Elements(MainNs + "row").Where(r => (int)r.Attribute("r") >= start).ToList())
            {
                int newRow = (int)row.Attribute("r") + count;
                row.SetAttributeValue("r", newRow);
                foreach (var cell in row.Elements(MainNs + "c")) cell.SetAttributeValue("r", ReplaceAddressRow((string)cell.Attribute("r"), newRow));
            }
            for (int i = 0; i < count; i++)
            {
                int rowNo = start + i;
                XElement clone = clones[i];
                clone.SetAttributeValue("r", rowNo);
                foreach (var cell in clone.Elements(MainNs + "c").ToList())
                {
                    cell.SetAttributeValue("r", ReplaceAddressRow((string)cell.Attribute("r"), rowNo));
                    ClearValue(cell);
                }
                data.Add(clone);
            }
            var sorted = data.Elements(MainNs + "row").OrderBy(r => (int)r.Attribute("r")).ToArray();
            data.RemoveNodes(); foreach (var row in sorted) data.Add(row);
            XElement merges = doc.Root.Element(MainNs + "mergeCells");
            if (merges != null)
            {
                foreach (var m in merges.Elements(MainNs + "mergeCell")) m.SetAttributeValue("ref", ShiftRange((string)m.Attribute("ref"), start, count));
                if (addSummaryMerges)
                {
                    for (int i = 0; i < count; i++) merges.Add(new XElement(MainNs + "mergeCell", new XAttribute("ref", "E" + (start + i) + ":G" + (start + i))));
                    merges.SetAttributeValue("count", merges.Elements(MainNs + "mergeCell").Count());
                }
            }
            XElement dimension = doc.Root.Element(MainNs + "dimension");
            if (dimension != null) dimension.SetAttributeValue("ref", ShiftRange((string)dimension.Attribute("ref"), start, count));
        }

        private static string ShiftRange(string range, int start, int count)
        {
            if (String.IsNullOrEmpty(range)) return range;
            string[] parts = range.Split(':');
            for (int i = 0; i < parts.Length; i++)
            {
                int row = AddressRow(parts[i]);
                if (row >= start) parts[i] = ReplaceAddressRow(parts[i], row + count);
                else if (parts.Length > 1 && i == 1 && AddressRow(parts[0]) < start && row >= start) parts[i] = ReplaceAddressRow(parts[i], row + count);
            }
            return String.Join(":", parts);
        }

        private static int AddressRow(string address)
        {
            int i = 0; while (i < address.Length && Char.IsLetter(address[i])) i++;
            int row; return Int32.TryParse(address.Substring(i).Replace("$", ""), out row) ? row : 1;
        }

        private static string ReplaceAddressRow(string address, int row)
        {
            if (String.IsNullOrEmpty(address)) return address;
            int i = 0; while (i < address.Length && (Char.IsLetter(address[i]) || address[i] == '$')) i++;
            return address.Substring(0, i) + row.ToString(CultureInfo.InvariantCulture);
        }

        private static void OrderCells(XElement row)
        {
            var cells = row.Elements(MainNs + "c").OrderBy(c => ColumnIndex((string)c.Attribute("r"))).ToArray();
            row.RemoveNodes(); foreach (var cell in cells) row.Add(cell);
        }

        private static int ColumnIndex(string address)
        {
            int value = 0;
            foreach (char c in address.TakeWhile(Char.IsLetter)) value = value * 26 + Char.ToUpperInvariant(c) - 'A' + 1;
            return value;
        }

        private static string Attribution(TraverseInput input)
        {
            return "Hesap; " + input.CalculationDate.ToString("dd.MM.yyyy", CultureInfo.GetCultureInfo("tr-TR")) + " tarihinde " + TextOr(input.OperatorName, Environment.MachineName) + " tarafından yapılmıştır.";
        }

        private static string TextOr(string value, string fallback) { return String.IsNullOrWhiteSpace(value) ? fallback : value.Trim(); }
        private static string F(double value, int digits) { return value.ToString("F" + digits, CultureInfo.InvariantCulture); }
    }
}
