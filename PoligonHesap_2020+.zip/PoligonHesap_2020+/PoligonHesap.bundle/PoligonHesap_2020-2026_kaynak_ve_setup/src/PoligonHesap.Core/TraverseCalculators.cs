using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PoligonHesap.Core
{
    public static class TraverseCalculators
    {
        public static TraverseResult CalculateOpen(TraverseInput input)
        {
            input.ValidateCommon();
            if (input.Observations.Count < 1) throw new ArgumentException("Açık poligon için en az bir istasyon satırı gerekir.");
            var back = input.RequirePoint(input.BackReferenceName, "Semt alınan");
            var start = input.RequirePoint(input.StartName, "Başlangıç");
            var result = new TraverseResult { Mode = TraverseMode.Acik, StartBearingGon = GonMath.Bearing(back.Y, back.X, start.Y, start.X), HasKnownEnd = false };
            result.Points.Add(start.Copy());
            double bearing = result.StartBearingGon;
            double y = start.Y;
            double x = start.X;
            string currentName = start.Name;
            for (int i = 0; i < input.Observations.Count; i++)
            {
                var obs = input.Observations[i];
                if (obs.DistanceM <= 0.0) throw new ArgumentException("Açık poligon kenar uzunluğu pozitif olmalıdır: " + obs.StationName);
                bearing = GonMath.Normalize(bearing + input.TurnDirection * (obs.AngleGon - 200.0));
                double radians = bearing * Math.PI / 200.0;
                double dy = obs.DistanceM * Math.Sin(radians);
                double dx = obs.DistanceM * Math.Cos(radians);
                y += dy;
                x += dx;
                string nextName = i + 1 < input.Observations.Count
                    ? input.Observations[i + 1].StationName
                    : (String.IsNullOrWhiteSpace(input.NewEndName) ? NextStationName(obs.StationName) : input.NewEndName.Trim());
                var leg = new TraverseLegResult
                {
                    FromName = currentName,
                    ToName = nextName,
                    AngleGon = obs.AngleGon,
                    BearingGon = bearing,
                    DistanceM = obs.DistanceM,
                    RawDY = dy,
                    RawDX = dx,
                    AdjustedDY = dy,
                    AdjustedDX = dx,
                    Y = y,
                    X = x
                };
                result.Legs.Add(leg);
                result.Points.Add(new SurveyPoint(nextName, y, x));
                result.TotalDistanceM += obs.DistanceM;
                currentName = nextName;
            }
            result.Notes = "Açık poligon: yeni son nokta hesaplandı; bilinen kapanış dayanağına bağlama veya kapanma düzeltmesi uygulanmadı.";
            return result;
        }

        public static TraverseResult CalculateClosed(TraverseInput input)
        {
            input.ValidateCommon();
            if (input.Observations.Count < 3) throw new ArgumentException("Kapalı poligon için en az üç açı istasyonu gerekir.");
            var back = input.RequirePoint(input.BackReferenceName, "Semt alınan");
            var start = input.RequirePoint(input.StartName, "Başlangıç");
            var end = input.RequirePoint(input.EndName, "Son");
            var forward = input.RequirePoint(input.ForwardReferenceName, "Semt kapanan");
            if (TraverseInput.NormalizeName(input.Observations[0].StationName) != TraverseInput.NormalizeName(input.StartName))
                throw new ArgumentException("Özet güzergâhının ilk noktası başlangıç alanıyla aynı değil: " + input.StartName);
            if (TraverseInput.NormalizeName(input.Observations[input.Observations.Count - 1].StationName) != TraverseInput.NormalizeName(input.EndName))
                throw new ArgumentException("Özet güzergâhının son noktası son alanıyla aynı değil: " + input.EndName);

            int n = input.Observations.Count;
            int legs = n - 1;
            double startBearing = GonMath.Bearing(back.Y, back.X, start.Y, start.X);
            double expectedEndBearing = GonMath.Bearing(end.Y, end.X, forward.Y, forward.X);
            double calculatedEndBearing = startBearing;
            for (int i = 0; i < n; i++)
                calculatedEndBearing = GonMath.Normalize(calculatedEndBearing + input.TurnDirection * (input.Observations[i].AngleGon - 200.0));

            double angularError = GonMath.Difference(calculatedEndBearing, expectedEndBearing);
            double angleTolerance = 3.0 * 2.0 * Math.Sqrt(n) / 1000.0;
            double remainingCc = -angularError * 10000.0;
            double[] angleCorrections = new double[n];
            for (int i = 0; i < n; i++)
            {
                double cc = GonMath.RoundVba(remainingCc / (n - i), 0);
                angleCorrections[i] = cc / 10000.0;
                remainingCc -= cc;
            }

            var result = new TraverseResult
            {
                Mode = TraverseMode.Kapali,
                StartBearingGon = startBearing,
                ExpectedEndBearingGon = expectedEndBearing,
                CalculatedEndBearingGon = calculatedEndBearing,
                AngularMisclosureGon = angularError,
                AngularToleranceGon = angleTolerance,
                HasKnownEnd = true,
                ExpectedEndY = end.Y,
                ExpectedEndX = end.X,
                AngularTolerancePassed = Math.Abs(angularError) <= angleTolerance
            };
            result.Points.Add(start.Copy());

            double sumDY = 0.0;
            double sumDX = 0.0;
            double[] bearings = new double[legs];
            double[] rawDY = new double[legs];
            double[] rawDX = new double[legs];
            double[] lengths = new double[legs];
            double direction = startBearing;
            for (int i = 0; i < legs; i++)
            {
                var obs = input.Observations[i];
                if (obs.DistanceM <= 0.0) throw new ArgumentException("Kapalı poligon kenar uzunluğu pozitif olmalıdır: " + obs.StationName);
                direction = GonMath.Normalize(direction + input.TurnDirection * (obs.AngleGon + angleCorrections[i] - 200.0));
                double radians = direction * Math.PI / 200.0;
                double dy = obs.DistanceM * Math.Sin(radians);
                double dx = obs.DistanceM * Math.Cos(radians);
                bearings[i] = direction;
                rawDY[i] = dy;
                rawDX[i] = dx;
                lengths[i] = obs.DistanceM;
                sumDY += dy;
                sumDX += dx;
                result.TotalDistanceM += obs.DistanceM;
            }
            if (result.TotalDistanceM <= 0.0) throw new ArgumentException("Kapalı poligon toplam kenar uzunluğu sıfır.");

            // Correct end X is deliberately resolved from EndName, not StartName.
            // This fixes the source-level DblXcoor(baslangicIdx) endpoint-index defect.
            result.Fy = sumDY - (end.Y - start.Y);
            result.Fx = sumDX - (end.X - start.X);
            result.Fs = Math.Sqrt(result.Fy * result.Fy + result.Fx * result.Fx);
            result.CoordinateToleranceM = 0.01 + result.TotalDistanceM * 0.0002;
            result.ClosureRatio = result.Fs == 0.0 ? Double.PositiveInfinity : result.TotalDistanceM / result.Fs;
            result.CoordinateTolerancePassed = result.Fs <= result.CoordinateToleranceM;

            double y = start.Y;
            double x = start.X;
            string currentName = start.Name;
            for (int i = 0; i < legs; i++)
            {
                var obs = input.Observations[i];
                double adjustedDY = rawDY[i] - result.Fy * (lengths[i] / result.TotalDistanceM);
                double adjustedDX = rawDX[i] - result.Fx * (lengths[i] / result.TotalDistanceM);
                y += adjustedDY;
                x += adjustedDX;
                string nextName = input.Observations[i + 1].StationName;
                var leg = new TraverseLegResult
                {
                    FromName = currentName,
                    ToName = nextName,
                    AngleGon = obs.AngleGon,
                    AngleCorrectionGon = angleCorrections[i],
                    BearingGon = bearings[i],
                    DistanceM = lengths[i],
                    RawDY = rawDY[i],
                    RawDX = rawDX[i],
                    AdjustedDY = adjustedDY,
                    AdjustedDX = adjustedDX,
                    Y = y,
                    X = x
                };
                result.Legs.Add(leg);
                result.Points.Add(new SurveyPoint(nextName, y, x));
                currentName = nextName;
            }
            result.Notes = "Kapalı poligon: açı düzeltmesi kalan cc değerini sırayla dağıtır; koordinat kapanması kenar uzunluklarına orantılı (Bowditch) dağıtılır.";
            return result;
        }

        public static TraverseResult CalculateDayali(TraverseInput input)
        {
            input.ValidateCommon();
            if (input.Observations.Count < 3) throw new ArgumentException("Dayalı poligon için en az üç açı istasyonu gerekir.");
            var back = input.RequirePoint(input.BackReferenceName, "Semt alınan");
            var start = input.RequirePoint(input.StartName, "Başlangıç");
            var end = input.RequirePoint(input.EndName, "Son");
            var forward = input.RequirePoint(input.ForwardReferenceName, "Semt kapanan");

            int angleCount = input.Observations.Count;
            int legs = angleCount - 1;
            int legacyRouteCount = angleCount + 2;
            double startBearing = GonMath.RoundVba(GonMath.Bearing(back.Y, back.X, start.Y, start.X), 4);
            double endBearing = GonMath.RoundVba(GonMath.Bearing(end.Y, end.X, forward.Y, forward.X), 4);
            double sumAngles = input.Observations.Sum(o => o.AngleGon) + startBearing;
            double normalizedSum = GonMath.Normalize(sumAngles - angleCount * 200.0);
            double fbGon = normalizedSum - endBearing;
            double fbCc = fbGon * 10000.0;
            double angleToleranceCc = Math.Floor(1.5 * Math.Sqrt(legacyRouteCount - 2) * 100.0);

            // Port of the legacy cumulative, rounded correction distribution.
            double remainingCc = -fbCc;
            double[] correctionCc = new double[angleCount];
            for (int i = 0; i < angleCount; i++)
            {
                double divisor = angleCount - i;
                correctionCc[i] = GonMath.RoundVba(remainingCc / divisor, 0);
                remainingCc -= correctionCc[i];
            }

            var result = new TraverseResult
            {
                Mode = TraverseMode.Dayali,
                StartBearingGon = startBearing,
                ExpectedEndBearingGon = endBearing,
                CalculatedEndBearingGon = normalizedSum,
                AngularMisclosureGon = fbGon,
                AngularToleranceGon = angleToleranceCc / 10000.0,
                HasKnownEnd = true,
                ExpectedEndY = end.Y,
                ExpectedEndX = end.X,
                AngularTolerancePassed = Math.Abs(fbCc) <= angleToleranceCc
            };

            var bearings = new double[legs];
            var dY = new double[legs];
            var dX = new double[legs];
            var lengths = new double[legs];
            double direction = startBearing;
            double sumDY = 0.0;
            double sumDX = 0.0;
            for (int i = 0; i < legs; i++)
            {
                var obs = input.Observations[i];
                if (obs.DistanceM <= 0.0) throw new ArgumentException("Dayalı poligon kenar uzunluğu pozitif olmalıdır: " + obs.StationName);
                int correctionIndex = angleCount - 1 - i;
                direction = GonMath.Normalize(direction + input.TurnDirection * (obs.AngleGon + correctionCc[correctionIndex] / 10000.0 - 200.0));
                direction = GonMath.RoundVba(direction, 4);
                double radians = direction * Math.PI / 200.0;
                double dy = obs.DistanceM * Math.Sin(radians);
                double dx = obs.DistanceM * Math.Cos(radians);
                if (input.Precision == CoordinatePrecision.Millimeter)
                {
                    dy = GonMath.RoundVba(dy, 3);
                    dx = GonMath.RoundVba(dx, 3);
                }
                else
                {
                    dy = GonMath.RoundVba(dy, 2);
                    dx = GonMath.RoundVba(dx, 2);
                }
                bearings[i] = direction;
                dY[i] = dy;
                dX[i] = dx;
                lengths[i] = obs.DistanceM;
                sumDY += dy;
                sumDX += dx;
                result.TotalDistanceM += obs.DistanceM;
            }
            double sDist = Math.Sqrt(sumDY * sumDY + sumDX * sumDX);
            if (sDist <= 0.0) throw new ArgumentException("Dayalı poligon hesaplanan güzergâh uzunluğu sıfır.");
            double fyM = (end.Y - start.Y) - sumDY;
            double fxM = (end.X - start.X) - sumDX;
            double flM = ((fyM * sumDY) + (fxM * sumDX)) / sDist;
            double fqM = ((fyM * sumDX) - (fxM * sumDY)) / sDist;
            result.Fy = fyM;
            result.Fx = fxM;
            result.Fs = Math.Sqrt(fyM * fyM + fxM * fxM);

            // Default regulation profile is the source's BÖHYY-2025 selection.
            double flToleranceM = 0.05 + 0.04 * Math.Sqrt(legacyRouteCount - 3);
            double fqToleranceM = 0.05 + 0.15 * (sDist / 1000.0);
            double fsToleranceM = 0.009 * Math.Sqrt(result.TotalDistanceM);
            result.CoordinateToleranceM = fsToleranceM;
            result.CoordinateTolerancePassed = Math.Abs(flM) <= flToleranceM && Math.Abs(fqM) <= fqToleranceM && result.Fs <= fsToleranceM;

            double scale = input.Precision == CoordinatePrecision.Millimeter ? 1000.0 : 100.0;
            double fyUnits = Math.Floor(GonMath.RoundVba(fyM, input.Precision == CoordinatePrecision.Millimeter ? 3 : 2) * scale);
            double fxUnits = Math.Floor(GonMath.RoundVba(fxM, input.Precision == CoordinatePrecision.Millimeter ? 3 : 2) * scale);
            int[] vy = DistributeLegacyResidual(fyUnits, lengths);
            int[] vx = DistributeLegacyResidual(fxUnits, lengths);
            double signY = fyUnits < 0.0 ? -1.0 : 1.0;
            double signX = fxUnits < 0.0 ? -1.0 : 1.0;

            double y = start.Y;
            double x = start.X;
            result.Points.Add(start.Copy());
            string currentName = start.Name;
            for (int i = 0; i < legs; i++)
            {
                double adjustedDY = dY[i] + (vy[i] * signY / scale);
                double adjustedDX = dX[i] + (vx[i] * signX / scale);
                int digits = input.Precision == CoordinatePrecision.Millimeter ? 3 : 2;
                y = GonMath.RoundVba(y + adjustedDY, digits);
                x = GonMath.RoundVba(x + adjustedDX, digits);
                string nextName = input.Observations[i + 1].StationName;
                var leg = new TraverseLegResult
                {
                    FromName = currentName,
                    ToName = nextName,
                    AngleGon = input.Observations[i].AngleGon,
                    AngleCorrectionGon = correctionCc[angleCount - 1 - i] / 10000.0,
                    BearingGon = bearings[i],
                    DistanceM = lengths[i],
                    RawDY = dY[i],
                    RawDX = dX[i],
                    AdjustedDY = adjustedDY,
                    AdjustedDX = adjustedDX,
                    Y = y,
                    X = x
                };
                result.Legs.Add(leg);
                result.Points.Add(new SurveyPoint(nextName, y, x));
                currentName = nextName;
            }
            result.Notes = "Dayalı poligon: mevcut açı düzeltme sırası ve mm/cm biriminde tamsayı koordinat düzeltmesi korunmuştur; kapanış noktası kontrol koordinatı ile karşılaştırılır.";
            return result;
        }

        private static int[] DistributeLegacyResidual(double signedUnits, double[] lengths)
        {
            int n = lengths.Length;
            int[] allocation = new int[n];
            double amount = Math.Abs(signedUnits);
            if (amount == 0.0) return allocation;
            double total = lengths.Sum();
            double remainingLength = total;
            double average = amount / n;
            double[] ideal = new double[n];
            for (int i = 0; i < n; i++) ideal[i] = amount * lengths[i] / total;
            int guard = 0;
            int assigned;
            do
            {
                assigned = allocation.Sum(v => (int)Math.Abs(v));
                for (int i = 0; i < n; i++)
                {
                    if (ideal[i] < average && average < 1.0)
                    {
                        if (allocation[i] == 0) remainingLength -= lengths[i];
                        continue;
                    }
                    if ((ideal[i] > average && average < 1.0) || ideal[i] >= 1.0)
                    {
                        if (remainingLength <= 0.0) remainingLength = total;
                        allocation[i] = (int)GonMath.RoundVba(amount * lengths[i] / remainingLength, 0);
                    }
                }
                assigned = allocation.Sum(v => (int)Math.Abs(v));
                if (assigned >= amount) break;
                for (int i = 0; i < n; i++)
                    if (allocation[i] != 0) ideal[i] = amount * lengths[i] / Math.Max(remainingLength, 1e-12);
                average = amount / n;
                guard++;
            } while (guard < 1000);

            int difference = (int)Math.Round(amount, MidpointRounding.ToEven) - allocation.Sum(v => Math.Abs(v));
            if (difference != 0)
            {
                int idx = Array.IndexOf(lengths, lengths.Max());
                allocation[idx] += difference;
            }
            for (int i = 0; i < allocation.Length; i++) allocation[i] = Math.Abs(allocation[i]);
            return allocation;
        }

        private static string NextStationName(string name)
        {
            string text = (name ?? String.Empty).Trim();
            if (text.Length == 0) return "SON";
            int index = text.Length;
            while (index > 0 && Char.IsDigit(text[index - 1])) index--;
            if (index < text.Length)
            {
                string prefix = text.Substring(0, index);
                long number;
                if (Int64.TryParse(text.Substring(index), NumberStyles.Integer, CultureInfo.InvariantCulture, out number))
                    return prefix + (number + 1).ToString(CultureInfo.InvariantCulture).PadLeft(text.Length - index, '0');
            }
            return text + "_SON";
        }
    }
}
