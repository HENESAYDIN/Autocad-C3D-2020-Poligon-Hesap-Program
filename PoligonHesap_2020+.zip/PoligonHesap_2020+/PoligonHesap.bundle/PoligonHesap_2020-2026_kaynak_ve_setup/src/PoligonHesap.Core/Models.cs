using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace PoligonHesap.Core
{
    public enum TraverseMode
    {
        Dayali,
        Acik,
        Kapali
    }

    public enum CoordinatePrecision
    {
        Centimeter = 2,
        Millimeter = 3
    }

    public sealed class SurveyPoint
    {
        public string Name { get; set; }
        public double Y { get; set; }
        public double X { get; set; }
        public double Z { get; set; }

        public SurveyPoint() { }

        public SurveyPoint(string name, double y, double x, double z = 0.0)
        {
            Name = name ?? String.Empty;
            Y = y;
            X = x;
            Z = z;
        }

        public SurveyPoint Copy()
        {
            return new SurveyPoint(Name, Y, X, Z);
        }
    }

    public sealed class TraverseObservation
    {
        public string StationName { get; set; }
        public double AngleGon { get; set; }
        public double DistanceM { get; set; }

        public TraverseObservation() { }

        public TraverseObservation(string stationName, double angleGon, double distanceM)
        {
            StationName = stationName ?? String.Empty;
            AngleGon = angleGon;
            DistanceM = distanceM;
        }
    }

    public sealed class TraverseInput
    {
        public string BackReferenceName { get; set; }
        public string StartName { get; set; }
        public string EndName { get; set; }
        public string ForwardReferenceName { get; set; }
        public string NewEndName { get; set; }
        public string CityName { get; set; }
        public string RouteNumber { get; set; }
        public string OperatorName { get; set; }
        public DateTime CalculationDate { get; set; }
        public CoordinatePrecision Precision { get; set; }
        public int TurnDirection { get; set; }
        public List<SurveyPoint> ControlPoints { get; private set; }
        public List<TraverseObservation> Observations { get; private set; }
        public List<RawRasatObservation> RawRasatObservations { get; private set; }
        public bool ObservationsFromRasat { get; set; }

        public TraverseInput()
        {
            ControlPoints = new List<SurveyPoint>();
            Observations = new List<TraverseObservation>();
            RawRasatObservations = new List<RawRasatObservation>();
            ObservationsFromRasat = false;
            CityName = String.Empty;
            RouteNumber = "1";
            OperatorName = Environment.MachineName;
            CalculationDate = DateTime.Now;
            Precision = CoordinatePrecision.Millimeter;
            TurnDirection = 1;
        }

        public SurveyPoint FindPoint(string name)
        {
            string target = NormalizeName(name);
            return ControlPoints.FirstOrDefault(p => NormalizeName(p.Name) == target);
        }

        public void ValidateCommon()
        {
            if (ControlPoints.Count == 0)
                throw new ArgumentException("Nokta koordinatları yüklenmedi.");
            if (Observations.Count == 0)
                throw new ArgumentException("Özet açı/kenar satırları yüklenmedi.");
            if (TurnDirection != 1 && TurnDirection != -1)
                throw new ArgumentException("Dönüş yönü yalnızca +1 veya -1 olabilir.");
            var duplicate = ControlPoints.GroupBy(p => NormalizeName(p.Name)).FirstOrDefault(g => g.Count() > 1);
            if (duplicate != null)
                throw new ArgumentException("Nokta listesinde yinelenen ad var: " + duplicate.First().Name);
            foreach (var p in ControlPoints)
            {
                if (String.IsNullOrWhiteSpace(p.Name) || Double.IsNaN(p.Y) || Double.IsNaN(p.X) || Double.IsInfinity(p.Y) || Double.IsInfinity(p.X))
                    throw new ArgumentException("Nokta adı/koordinatı geçersiz.");
            }
            foreach (var o in Observations)
            {
                if (String.IsNullOrWhiteSpace(o.StationName) || Double.IsNaN(o.AngleGon) || Double.IsInfinity(o.AngleGon))
                    throw new ArgumentException("Açı kaydında istasyon adı veya açı değeri geçersiz.");
                if (o.AngleGon < 0.0 || o.AngleGon >= 400.0)
                    throw new ArgumentException("Açı 0–400 gon aralığında olmalıdır: " + o.StationName);
            }
        }

        public SurveyPoint RequirePoint(string name, string role)
        {
            var p = FindPoint(name);
            if (p == null)
                throw new ArgumentException(role + " noktası koordinat dosyasında bulunamadı: " + name);
            return p;
        }

        public static string NormalizeName(string name)
        {
            return (name ?? String.Empty).Replace('\u00a0', ' ').Trim().ToUpperInvariant();
        }
    }

    public sealed class TraverseLegResult
    {
        public string FromName { get; set; }
        public string ToName { get; set; }
        public double AngleGon { get; set; }
        public double AngleCorrectionGon { get; set; }
        public double BearingGon { get; set; }
        public double DistanceM { get; set; }
        public double RawDY { get; set; }
        public double RawDX { get; set; }
        public double AdjustedDY { get; set; }
        public double AdjustedDX { get; set; }
        public double Y { get; set; }
        public double X { get; set; }
    }

    public sealed class TraverseResult
    {
        public TraverseMode Mode { get; set; }
        public List<SurveyPoint> Points { get; private set; }
        public List<TraverseLegResult> Legs { get; private set; }
        public double StartBearingGon { get; set; }
        public double ExpectedEndBearingGon { get; set; }
        public double CalculatedEndBearingGon { get; set; }
        public double AngularMisclosureGon { get; set; }
        public double AngularToleranceGon { get; set; }
        public double TotalDistanceM { get; set; }
        public double Fy { get; set; }
        public double Fx { get; set; }
        public double Fs { get; set; }
        public double CoordinateToleranceM { get; set; }
        public double ClosureRatio { get; set; }
        public double ExpectedEndY { get; set; }
        public double ExpectedEndX { get; set; }
        public bool HasKnownEnd { get; set; }
        public bool AngularTolerancePassed { get; set; }
        public bool CoordinateTolerancePassed { get; set; }
        public string Notes { get; set; }

        public TraverseResult()
        {
            Points = new List<SurveyPoint>();
            Legs = new List<TraverseLegResult>();
            Notes = String.Empty;
        }

        public string AngularMisclosureCc
        {
            get { return (AngularMisclosureGon * 10000.0).ToString("0.00", CultureInfo.InvariantCulture); }
        }

        public string AngularToleranceCc
        {
            get { return (AngularToleranceGon * 10000.0).ToString("0.00", CultureInfo.InvariantCulture); }
        }
    }

    public static class GonMath
    {
        public static double Normalize(double gon)
        {
            gon %= 400.0;
            if (gon < 0.0) gon += 400.0;
            return gon;
        }

        // Returns a-b in (-200, 200], matching the VBA helper.
        public static double Difference(double a, double b)
        {
            double d = a - b;
            while (d > 200.0) d -= 400.0;
            while (d <= -200.0) d += 400.0;
            return d;
        }

        // Survey convention in the source: Y is easting, X is northing; zero gon points north.
        public static double Bearing(double fromY, double fromX, double toY, double toX)
        {
            double dy = toY - fromY;
            double dx = toX - fromX;
            if (Math.Abs(dy) < 1e-10 && Math.Abs(dx) < 1e-10)
                throw new ArgumentException("Semt için iki noktanın koordinatları aynı.");
            return Normalize(Math.Atan2(dy, dx) * 200.0 / Math.PI);
        }

        public static double RoundVba(double value, int digits)
        {
            return Math.Round(value, digits, MidpointRounding.ToEven);
        }

        public static double ParseNumber(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) return 0.0;
            string text = value.Trim();
            double result;
            if (Double.TryParse(text, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out result)) return result;
            if (Double.TryParse(text, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.GetCultureInfo("tr-TR"), out result)) return result;
            throw new FormatException("Sayısal değer okunamadı: " + value);
        }
    }
}
