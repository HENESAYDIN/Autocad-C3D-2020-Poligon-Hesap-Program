using System;
using System.Globalization;
using System.Text;

namespace PoligonHesap.Core
{
    /// <summary>
    /// Encodes non-ASCII characters using AutoCAD's DXF Unicode escape notation.
    /// R12 DXF is an ANSI-code-page format; ASCII escapes preserve Unicode text
    /// independently of the machine code page used by the native DXF exporter.
    /// </summary>
    public static class DxfTextEncoding
    {
        public static string EscapeNonAscii(string value)
        {
            if (value == null) return String.Empty;

            var encoded = new StringBuilder(value.Length);
            foreach (char character in value)
            {
                if (character <= 0x7f)
                {
                    encoded.Append(character);
                }
                else
                {
                    encoded.Append("\\U+");
                    encoded.Append(((int)character).ToString("X4", CultureInfo.InvariantCulture));
                }
            }
            return encoded.ToString();
        }
    }
}
