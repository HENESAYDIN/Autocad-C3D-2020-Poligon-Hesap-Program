using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace PoligonHesap.Core
{
    public static class DxfWriter
    {
        private sealed class Bounds
        {
            public double MinE, MaxE, MinN, MaxN;
        }

        private static readonly string[] LayerNames = { "0", "PH_Limit", "PH_GYazi", "PH_Yazi", "PH_Grid", "PH_EskiPol", "PH_PolAdi", "PH_PolKot", "PH_YeniPol", "PH_Guzg", "PH_PolCiz" };
        // ACI colors and layer roles follow Pol2020.dvb / KVO_HazirlaKatmanlar.
        private static readonly short[] LayerColors = { 7, 5, 7, 7, 7, 2, 6, 3, 1, 4, 7 };

        public static string Write(string path, TraverseResult result)
        {
            return Write(path, new TraverseInput { RouteNumber = "1" }, result);
        }

        public static string Write(string path, TraverseInput input, TraverseResult result)
        {
            return Write(path, input, result, false);
        }

        public static string Write(string path, TraverseInput input, TraverseResult result, bool includeReportTable)
        {
            if (String.IsNullOrWhiteSpace(path)) throw new ArgumentException("DXF kayıt yolu boş olamaz.", "path");
            if (input == null) throw new ArgumentNullException("input");
            if (result == null || result.Points.Count < 2) throw new ArgumentException("DXF için en az iki hesaplanmış nokta gerekir.");

            Bounds bounds = GetBounds(input, result);
            double extent = Math.Max(bounds.MaxE - bounds.MinE, bounds.MaxN - bounds.MinN);
            double h = Math.Max(1.0, extent / 55.0);
            Bounds viewBounds = GetViewBounds(bounds, result, h, includeReportTable);
            const double viewAspect = 1.6;
            double viewHeight = Math.Max(viewBounds.MaxN - viewBounds.MinN, (viewBounds.MaxE - viewBounds.MinE) / viewAspect) * 1.08;
            Encoding encoding = Encoding.GetEncoding(1254);

            string fullPath = Path.GetFullPath(path);
            string folder = Path.GetDirectoryName(fullPath);
            if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
            string tempPath = fullPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using (var w = new StreamWriter(tempPath, false, encoding))
                {
                    w.NewLine = "\r\n";
                    Header(w, bounds, viewBounds, viewHeight);
                    Tables(w, viewBounds, viewHeight, viewAspect);
                    Blocks(w);
                    Pair(w, 0, "SECTION"); Pair(w, 2, "ENTITIES");
                    DrawPlot(w, input, result, bounds, h);
                    if (includeReportTable) DrawReportTable(w, input, result, bounds.MaxE + h * 3.0, bounds.MaxN, h);
                    Pair(w, 0, "ENDSEC"); Pair(w, 0, "EOF");
                }
                AddHandlesAndUpdateSeed(tempPath);
                return CommitWithFallback(tempPath, fullPath);
            }
            finally
            {
                if (File.Exists(tempPath)) File.Delete(tempPath);
            }
        }

        private static string CommitWithFallback(string tempPath, string requestedPath)
        {
            if (File.Exists(requestedPath))
            {
                if (CanReplace(requestedPath))
                {
                    try
                    {
                        File.Delete(requestedPath);
                        File.Move(tempPath, requestedPath);
                        return requestedPath;
                    }
                    catch (IOException) { /* A CAD process may have acquired the file after CanReplace. */ }
                    catch (UnauthorizedAccessException) { /* Try a new sibling name rather than failing the calculation. */ }
                }
                return MoveToVersionedPath(tempPath, requestedPath);
            }

            try
            {
                File.Move(tempPath, requestedPath);
                return requestedPath;
            }
            catch (IOException)
            {
                if (!File.Exists(requestedPath)) throw;
                return MoveToVersionedPath(tempPath, requestedPath);
            }
        }

        private static bool CanReplace(string path)
        {
            try
            {
                using (new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
                return true;
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        private static string MoveToVersionedPath(string tempPath, string requestedPath)
        {
            string folder = Path.GetDirectoryName(requestedPath);
            string stem = Path.GetFileNameWithoutExtension(requestedPath);
            string extension = Path.GetExtension(requestedPath);
            for (int suffix = 2; suffix < 10000; suffix++)
            {
                string candidate = Path.Combine(folder, stem + "_" + suffix.ToString(CultureInfo.InvariantCulture) + extension);
                if (File.Exists(candidate)) continue;
                try
                {
                    File.Move(tempPath, candidate);
                    return candidate;
                }
                catch (IOException)
                {
                    if (!File.Exists(candidate)) throw;
                }
            }
            throw new IOException("DXF dosyası kullanımda ve boş alternatif dosya adı bulunamadı: " + requestedPath);
        }

        private static Bounds GetBounds(TraverseInput input, TraverseResult result)
        {
            List<SurveyPoint> points = input.ControlPoints.Concat(result.Points).ToList();
            double minE = points.Min(p => p.Y), maxE = points.Max(p => p.Y);
            double minN = points.Min(p => p.X), maxN = points.Max(p => p.X);
            // Exact 100 m rounding and 100/200 m margins used by Pol2020.dvb KVO_Ciz.
            double yMin = Math.Floor(minE / 100.0) * 100.0 - 100.0;
            double yMax = Math.Floor(maxE / 100.0) * 100.0 + 200.0;
            double xMin = Math.Floor(minN / 100.0) * 100.0 - 100.0;
            double xMax = Math.Floor(maxN / 100.0) * 100.0 + 200.0;
            if (yMax <= yMin) yMax = yMin + 200.0;
            if (xMax <= xMin) xMax = xMin + 200.0;
            return new Bounds { MinE = yMin, MaxE = yMax, MinN = xMin, MaxN = xMax };
        }

        private static Bounds GetViewBounds(Bounds bounds, TraverseResult result, double h, bool includeReportTable)
        {
            double minE = bounds.MinE - Math.Max(5.0, h * 1.2);
            double maxE = bounds.MaxE + Math.Max(5.0, h * 0.5);
            double minN = bounds.MinN - Math.Max(5.0, h * 4.0);
            double maxN = bounds.MaxN + Math.Max(5.0, h * 4.0);
            if (includeReportTable)
            {
                maxE = Math.Max(maxE, bounds.MaxE + h * 3.0 + 127.0);
                minN = Math.Min(minN, bounds.MaxN - 40.0 - result.Points.Count * 6.0);
            }
            return new Bounds { MinE = minE, MaxE = maxE, MinN = minN, MaxN = maxN };
        }

        private static void Header(StreamWriter w, Bounds bounds, Bounds viewBounds, double viewHeight)
        {
            Pair(w, 0, "SECTION"); Pair(w, 2, "HEADER");
            Pair(w, 9, "$ACADVER"); Pair(w, 1, "AC1009");
            Pair(w, 9, "$DWGCODEPAGE"); Pair(w, 3, "ANSI_1254");
            Pair(w, 9, "$COORDS"); Pair(w, 70, "0");
            Pair(w, 9, "$LTSCALE"); Pair(w, 40, "25.0");
            Pair(w, 9, "$HANDLING"); Pair(w, 70, "1");
            Pair(w, 9, "$HANDSEED"); Pair(w, 5, "1");
            Pair(w, 9, "$EXTMIN"); Pair(w, 10, N(viewBounds.MinE)); Pair(w, 20, N(viewBounds.MinN)); Pair(w, 30, "0.0");
            Pair(w, 9, "$EXTMAX"); Pair(w, 10, N(viewBounds.MaxE)); Pair(w, 20, N(viewBounds.MaxN)); Pair(w, 30, "0.0");
            Pair(w, 9, "$LIMMIN"); Pair(w, 10, N(bounds.MinE)); Pair(w, 20, N(bounds.MinN));
            Pair(w, 9, "$LIMMAX"); Pair(w, 10, N(bounds.MaxE)); Pair(w, 20, N(bounds.MaxN));
            Pair(w, 9, "$VIEWCTR"); Pair(w, 10, N((viewBounds.MinE + viewBounds.MaxE) / 2.0)); Pair(w, 20, N((viewBounds.MinN + viewBounds.MaxN) / 2.0));
            Pair(w, 9, "$VIEWDIR"); Pair(w, 10, "0.0"); Pair(w, 20, "0.0"); Pair(w, 30, "1.0");
            Pair(w, 9, "$VIEWSIZE"); Pair(w, 40, N(viewHeight));
            Pair(w, 9, "$PDMODE"); Pair(w, 70, "32"); Pair(w, 9, "$PDSIZE"); Pair(w, 40, "2.5");
            Pair(w, 9, "$INSBASE"); Pair(w, 10, "0.0"); Pair(w, 20, "0.0"); Pair(w, 30, "0.0");
            Pair(w, 9, "$TEXTSTYLE"); Pair(w, 7, "PH-TSTYLE"); Pair(w, 9, "$CLAYER"); Pair(w, 8, "0");
            Pair(w, 9, "$LUNITS"); Pair(w, 70, "2"); Pair(w, 9, "$LUPREC"); Pair(w, 70, "3");
            Pair(w, 0, "ENDSEC");
        }

        private static void Tables(StreamWriter w, Bounds viewBounds, double viewHeight, double viewAspect)
        {
            Pair(w, 0, "SECTION"); Pair(w, 2, "TABLES");
            Pair(w, 0, "TABLE"); Pair(w, 2, "VPORT"); Pair(w, 70, "1");
            Pair(w, 0, "VPORT"); Pair(w, 2, "*ACTIVE"); Pair(w, 70, "0");
            Pair(w, 10, "0.0"); Pair(w, 20, "0.0"); Pair(w, 11, "1.0"); Pair(w, 21, "1.0");
            Pair(w, 12, N((viewBounds.MinE + viewBounds.MaxE) / 2.0)); Pair(w, 22, N((viewBounds.MinN + viewBounds.MaxN) / 2.0));
            Pair(w, 13, "0.0"); Pair(w, 23, "0.0"); Pair(w, 14, "0.5"); Pair(w, 24, "0.5"); Pair(w, 15, "0.5"); Pair(w, 25, "0.5");
            Pair(w, 16, "0.0"); Pair(w, 26, "0.0"); Pair(w, 36, "1.0"); Pair(w, 17, "0.0"); Pair(w, 27, "0.0"); Pair(w, 37, "0.0");
            Pair(w, 40, N(viewHeight)); Pair(w, 41, N(viewAspect)); Pair(w, 42, "50.0"); Pair(w, 43, "0.0"); Pair(w, 44, "0.0");
            Pair(w, 50, "0.0"); Pair(w, 51, "0.0"); Pair(w, 71, "0"); Pair(w, 72, "100"); Pair(w, 73, "1"); Pair(w, 74, "3");
            Pair(w, 75, "0"); Pair(w, 76, "0"); Pair(w, 77, "0"); Pair(w, 78, "0"); Pair(w, 0, "ENDTAB");
            Pair(w, 0, "TABLE"); Pair(w, 2, "LTYPE"); Pair(w, 70, "4");
            Pair(w, 0, "LTYPE"); Pair(w, 2, "ByBlock"); Pair(w, 70, "0"); Pair(w, 3, "" ); Pair(w, 72, "65"); Pair(w, 73, "0"); Pair(w, 40, "0.0");
            Pair(w, 0, "LTYPE"); Pair(w, 2, "ByLayer"); Pair(w, 70, "0"); Pair(w, 3, "" ); Pair(w, 72, "65"); Pair(w, 73, "0"); Pair(w, 40, "0.0");
            Pair(w, 0, "LTYPE"); Pair(w, 2, "Continuous"); Pair(w, 70, "0"); Pair(w, 3, "Solid line"); Pair(w, 72, "65"); Pair(w, 73, "0"); Pair(w, 40, "0.0");
            // HIDDEN is bundled so the DXF does not depend on the recipient's loaded linetype table.
            Pair(w, 0, "LTYPE"); Pair(w, 2, "HIDDEN"); Pair(w, 70, "0"); Pair(w, 3, "Hidden __ __ __ __"); Pair(w, 72, "65"); Pair(w, 73, "2"); Pair(w, 40, "0.75");
            Pair(w, 49, "0.5"); Pair(w, 74, "0"); Pair(w, 49, "-0.25"); Pair(w, 74, "0");
            Pair(w, 0, "ENDTAB");
            Pair(w, 0, "TABLE"); Pair(w, 2, "LAYER"); Pair(w, 70, LayerNames.Length.ToString(CultureInfo.InvariantCulture));
            for (int i = 0; i < LayerNames.Length; i++)
            {
                string ltype = LayerNames[i] == "PH_Grid" ? "HIDDEN" : "Continuous";
                Pair(w, 0, "LAYER"); Pair(w, 2, LayerNames[i]); Pair(w, 70, "0"); Pair(w, 62, LayerColors[i].ToString(CultureInfo.InvariantCulture)); Pair(w, 6, ltype);
            }
            Pair(w, 0, "ENDTAB");
            Pair(w, 0, "TABLE"); Pair(w, 2, "STYLE"); Pair(w, 70, "2");
            Pair(w, 0, "STYLE"); Pair(w, 2, "Standard"); Pair(w, 70, "0"); Pair(w, 40, "0.0"); Pair(w, 41, "1.0"); Pair(w, 50, "0.0"); Pair(w, 71, "0"); Pair(w, 42, "2.5"); Pair(w, 3, "arial.ttf"); Pair(w, 4, "");
            Pair(w, 0, "STYLE"); Pair(w, 2, "PH-TSTYLE"); Pair(w, 70, "0"); Pair(w, 40, "0.0"); Pair(w, 41, "1.0"); Pair(w, 50, "0.0"); Pair(w, 71, "0"); Pair(w, 42, "2.5"); Pair(w, 3, "arial.ttf"); Pair(w, 4, "");
            Pair(w, 0, "ENDTAB");
            EmptyTable(w, "VIEW");
            EmptyTable(w, "UCS");
            Pair(w, 0, "TABLE"); Pair(w, 2, "APPID"); Pair(w, 70, "1");
            Pair(w, 0, "APPID"); Pair(w, 2, "ACAD"); Pair(w, 70, "0"); Pair(w, 0, "ENDTAB");
            WriteDefaultDimStyle(w);
            Pair(w, 0, "ENDSEC");
        }

        private static void AddHandlesAndUpdateSeed(string path)
        {
            Encoding encoding = Encoding.GetEncoding(1254);
            string[] lines = File.ReadAllText(path, encoding).Split(new[] { "\r\n" }, StringSplitOptions.None);
            int count = lines.Length;
            if (count > 0 && lines[count - 1].Length == 0) count--;
            if (count % 2 != 0) throw new InvalidDataException("DXF group-code stream contains an incomplete pair.");

            var output = new List<string>(count + 512);
            int nextHandle = 1;
            for (int i = 0; i < count; i += 2)
            {
                int code = Int32.Parse(lines[i].Trim(), CultureInfo.InvariantCulture);
                string value = lines[i + 1];
                output.Add(lines[i]);
                output.Add(value);
                if (code == 0 && RequiresHandle(value.Trim()))
                {
                    output.Add("5");
                    output.Add(nextHandle.ToString("X", CultureInfo.InvariantCulture));
                    nextHandle++;
                }
            }

            bool seedUpdated = false;
            for (int i = 0; i + 3 < output.Count; i += 2)
            {
                if (output[i].Trim() == "9" && output[i + 1].Trim() == "$HANDSEED")
                {
                    if (output[i + 2].Trim() != "5") throw new InvalidDataException("$HANDSEED must use group code 5.");
                    output[i + 3] = nextHandle.ToString("X", CultureInfo.InvariantCulture);
                    seedUpdated = true;
                    break;
                }
            }
            if (!seedUpdated) throw new InvalidDataException("DXF header is missing $HANDSEED.");

            File.WriteAllText(path, String.Join("\r\n", output) + "\r\n", encoding);
        }

        private static bool RequiresHandle(string recordType)
        {
            switch (recordType.ToUpperInvariant())
            {
                case "VPORT": case "LTYPE": case "LAYER": case "STYLE": case "VIEW": case "UCS": case "APPID": case "DIMSTYLE":
                case "BLOCK": case "ENDBLK": case "LINE": case "POINT": case "CIRCLE": case "TEXT":
                    return true;
                default:
                    return false;
            }
        }

        private static void EmptyTable(StreamWriter w, string name)
        {
            Pair(w, 0, "TABLE"); Pair(w, 2, name); Pair(w, 70, "0"); Pair(w, 0, "ENDTAB");
        }

        private static void WriteDefaultDimStyle(StreamWriter w)
        {
            Pair(w, 0, "TABLE"); Pair(w, 2, "DIMSTYLE"); Pair(w, 70, "1");
            Pair(w, 0, "DIMSTYLE"); Pair(w, 2, "STANDARD"); Pair(w, 70, "0");
            Pair(w, 3, ""); Pair(w, 4, ""); Pair(w, 5, ""); Pair(w, 6, ""); Pair(w, 7, "");
            Pair(w, 40, "1.0"); Pair(w, 41, "0.18"); Pair(w, 42, "0.0625"); Pair(w, 43, "0.38"); Pair(w, 44, "0.18");
            Pair(w, 45, "0.0"); Pair(w, 46, "0.0"); Pair(w, 47, "0.0"); Pair(w, 48, "0.0");
            Pair(w, 140, "0.18"); Pair(w, 141, "0.09"); Pair(w, 142, "0.0"); Pair(w, 143, "25.4");
            Pair(w, 144, "1.0"); Pair(w, 145, "0.0"); Pair(w, 146, "1.0"); Pair(w, 147, "0.09");
            Pair(w, 71, "0"); Pair(w, 72, "0"); Pair(w, 73, "1"); Pair(w, 74, "1");
            Pair(w, 75, "0"); Pair(w, 76, "0"); Pair(w, 77, "0"); Pair(w, 78, "0");
            Pair(w, 170, "0"); Pair(w, 171, "2"); Pair(w, 172, "0"); Pair(w, 173, "0");
            Pair(w, 174, "0"); Pair(w, 175, "0"); Pair(w, 176, "0"); Pair(w, 177, "0"); Pair(w, 178, "0");
            Pair(w, 0, "ENDTAB");
        }

        private static void Blocks(StreamWriter w)
        {
            Pair(w, 0, "SECTION"); Pair(w, 2, "BLOCKS");
            WriteEmptyBlock(w, "$MODEL_SPACE", false);
            WriteEmptyBlock(w, "$PAPER_SPACE", true);
            Pair(w, 0, "ENDSEC");
        }

        private static void WriteEmptyBlock(StreamWriter w, string name, bool paperSpace)
        {
            Pair(w, 0, "BLOCK");
            if (paperSpace) Pair(w, 67, "1");
            Pair(w, 8, "0"); Pair(w, 2, name); Pair(w, 70, "0");
            Pair(w, 10, "0.0"); Pair(w, 20, "0.0"); Pair(w, 30, "0.0"); Pair(w, 3, name); Pair(w, 1, "");
            Pair(w, 0, "ENDBLK");
            if (paperSpace) Pair(w, 67, "1");
            Pair(w, 8, "0");
        }

        private static void DrawPlot(StreamWriter w, TraverseInput input, TraverseResult result, Bounds b, double h)
        {
            // Survey Y is CAD X/easting; survey X is CAD Y/northing, as in Pol2020.dvb.
            Line(w, "PH_Limit", b.MinE, b.MinN, b.MaxE, b.MinN);
            Line(w, "PH_Limit", b.MaxE, b.MinN, b.MaxE, b.MaxN);
            Line(w, "PH_Limit", b.MaxE, b.MaxN, b.MinE, b.MaxN);
            Line(w, "PH_Limit", b.MinE, b.MaxN, b.MinE, b.MinN);
            for (double e = b.MinE; e <= b.MaxE + 0.001; e += 100.0)
                Line(w, "PH_Grid", e, b.MinN, e, b.MaxN);
            for (double n = b.MinN; n <= b.MaxN + 0.001; n += 100.0)
                Line(w, "PH_Grid", b.MinE, n, b.MaxE, n);

            // DVB convention: northing labels on the left, easting labels along the bottom.
            for (double e = b.MinE; e <= b.MaxE + 0.001; e += 100.0)
                TextCenter(w, "PH_GYazi", F(e, 0), e, b.MinN - 3.0, 2.0, 90.0);
            for (double n = b.MinN; n <= b.MaxN + 0.001; n += 100.0)
                TextCenter(w, "PH_GYazi", F(n, 0), b.MinE - 3.0, n, 2.0, 0.0);

            double centerE = (b.MinE + b.MaxE) / 2.0;
            TextCenter(w, "PH_Yazi", "POLİGON KANAVASI", centerE, b.MaxN + h * 3.0, h * 1.25, 0.0);
            Text(w, "PH_Yazi", "Şehir/Kasaba Adı: " + Safe(input.CityName), b.MinE + 4.0, b.MaxN - h * 1.5, h * 0.80, 0.0);
            Text(w, "PH_Yazi", "Güzergah No: " + Safe(input.RouteNumber), b.MinE + 4.0, b.MaxN - h * 2.7, h * 0.80, 0.0);
            TextCenter(w, "PH_Yazi", "1:1000", centerE, b.MinN - h * 3.0, h, 0.0);

            DrawRoute(w, input, result, h);
        }

        private static void DrawRoute(StreamWriter w, TraverseInput input, TraverseResult result, double h)
        {
            for (int i = 0; i < result.Legs.Count; i++)
            {
                TraverseLegResult leg = result.Legs[i];
                SurveyPoint from = result.Points.FirstOrDefault(p => TraverseInput.NormalizeName(p.Name) == TraverseInput.NormalizeName(leg.FromName));
                SurveyPoint to = result.Points.FirstOrDefault(p => TraverseInput.NormalizeName(p.Name) == TraverseInput.NormalizeName(leg.ToName));
                if (from == null || to == null) continue;
                Line(w, "PH_Guzg", from.Y, from.X, to.Y, to.X);
                if (i == 0) DrawStartTick(w, from.Y, from.X, to.Y, to.X, h);
                if (i == result.Legs.Count - 1) DrawArrow(w, from.Y, from.X, to.Y, to.X, h);
            }

            if (result.Points.Count > 1)
            {
                SurveyPoint first = result.Points[0], second = result.Points[1];
                double midE = (first.Y + second.Y) / 2.0, midN = (first.X + second.X) / 2.0;
                Circle(w, "PH_Guzg", midE, midN, h * 1.2);
                TextCenter(w, "PH_Guzg", Safe(input.RouteNumber), midE, midN, h, 0.0);
            }

            foreach (SurveyPoint control in input.ControlPoints)
            {
                Point(w, "PH_EskiPol", control.Y, control.X, 0.0);
                Circle(w, "PH_EskiPol", control.Y, control.X, Math.Max(0.3, h * 0.42));
                Text(w, "PH_PolAdi", control.Name, control.Y + h * 0.8, control.X + h * 0.8, h * 0.75, 0.0);
                Text(w, "PH_PolKot", F(control.Z, 0), control.Y + h * 0.8, control.X - h * 0.65, h * 0.65, 0.0);
            }
            foreach (SurveyPoint point in result.Points.Where(p => input.FindPoint(p.Name) == null))
            {
                Point(w, "PH_YeniPol", point.Y, point.X, 0.0);
                Circle(w, "PH_YeniPol", point.Y, point.X, Math.Max(0.28, h * 0.38));
                Text(w, "PH_PolAdi", point.Name, point.Y + h * 0.8, point.X + h * 0.8, h * 0.75, 0.0);
            }
        }

        private static void DrawReportTable(StreamWriter w, TraverseInput input, TraverseResult result, double x, double top, double h)
        {
            const double width = 125.0;
            double[] widths = { 10, 15, 14, 14, 14, 14, 16, 16, 12 };
            double[] col = new double[widths.Length + 1]; col[0] = x;
            for (int i = 0; i < widths.Length; i++) col[i + 1] = col[i] + widths[i];
            string layer = "PH_PolCiz";
            double titleBottom = top - 7.5;
            Line(w, layer, col[0], top, col[9], top);
            TextCenter(w, layer, "P O L İ G O N   H E S A B I", x + width / 2.0, top - 3.75, 2.5, 0.0);
            Line(w, layer, col[0], titleBottom, col[9], titleBottom);
            Text(w, layer, "Şehir/Kasaba Adı: " + Safe(input.CityName), x + 1.0, top - 9.0, 1.5, 0.0);
            Text(w, layer, "Güzergah No: " + Safe(input.RouteNumber), x + 1.0, top - 11.5, 1.5, 0.0);
            double metaBottom = top - 12.5;
            Line(w, layer, col[0], metaBottom, col[9], metaBottom);

            TextCenter(w, layer, "Nokta", Mid(col[0], col[1]), top - 14.5, 1.35, 0.0);
            TextCenter(w, layer, "Kırılma", Mid(col[1], col[2]), top - 14.5, 1.35, 0.0);
            TextCenter(w, layer, "Açıklık", Mid(col[2], col[3]), top - 14.5, 1.35, 0.0);
            TextCenter(w, layer, "Kenarlar", Mid(col[3], col[4]), top - 14.5, 1.35, 0.0);
            TextCenter(w, layer, "Koordinat Farkları", Mid(col[4], col[6]), top - 14.5, 1.35, 0.0);
            TextCenter(w, layer, "Koordinatlar", Mid(col[6], col[8]), top - 14.5, 1.35, 0.0);
            TextCenter(w, layer, "Nokta", Mid(col[8], col[9]), top - 14.5, 1.35, 0.0);
            string[] secondHeader = { "No", "Açısı β", "Açısı α", "S(m)", "ΔY(m)", "ΔX(m)", "Y(m)", "X(m)", "No" };
            for (int c = 0; c < secondHeader.Length; c++) TextCenter(w, layer, secondHeader[c], Mid(col[c], col[c + 1]), top - 17.5, 1.25, 0.0);
            double headerBottom = top - 20.0;
            Line(w, layer, col[0], headerBottom, col[9], headerBottom);

            double rowY = top - 22.5;
            for (int i = 0; i < result.Points.Count; i++)
            {
                SurveyPoint point = result.Points[i];
                TraverseLegResult leg = result.Legs.FirstOrDefault(l => TraverseInput.NormalizeName(l.FromName) == TraverseInput.NormalizeName(point.Name));
                string[] upper =
                {
                    point.Name,
                    leg == null ? String.Empty : F(leg.AngleGon, 4),
                    leg == null ? String.Empty : F(leg.BearingGon, 4),
                    String.Empty, String.Empty, String.Empty,
                    F(point.Y, 3), F(point.X, 3), point.Name
                };
                for (int c = 0; c < upper.Length; c++) TextCenter(w, layer, upper[c], Mid(col[c], col[c + 1]), rowY, 1.4, 0.0);
                if (leg != null)
                {
                    TextCenter(w, layer, F(leg.DistanceM, 3), Mid(col[3], col[4]), rowY - 3.0, 1.35, 0.0);
                    TextCenter(w, layer, F(leg.AdjustedDY, 3), Mid(col[4], col[5]), rowY - 3.0, 1.35, 0.0);
                    TextCenter(w, layer, F(leg.AdjustedDX, 3), Mid(col[5], col[6]), rowY - 3.0, 1.35, 0.0);
                }
                double lineY = rowY - 4.5;
                Line(w, layer, col[0], lineY, col[9], lineY);
                rowY -= 6.0;
            }
            double dataBottom = rowY + 1.5;
            double firstInfoY = dataBottom - 4.0;
            int footerRows = result.Mode == TraverseMode.Acik ? 2 : 3;
            double frameBottom = firstInfoY - (footerRows - 1) * 3.0 - 2.0;
            for (int c = 0; c < col.Length; c++)
            {
                bool outer = c == 0 || c == col.Length - 1;
                double startY = outer ? top : (c == 5 || c == 7 ? top - 16.25 : metaBottom);
                Line(w, layer, col[c], startY, col[c], outer ? frameBottom : dataBottom);
            }
            Line(w, layer, col[0], dataBottom, col[col.Length - 1], dataBottom);
            Line(w, layer, col[0], frameBottom, col[col.Length - 1], frameBottom);

            double infoY = firstInfoY;
            double sumDy = result.Legs.Sum(l => l.AdjustedDY);
            double sumDx = result.Legs.Sum(l => l.AdjustedDX);
            double sumBeta = input.Observations.Sum(o => o.AngleGon);
            TextCenter(w, layer, "[β]: " + F(sumBeta, 4), Mid(col[1], col[2]), infoY, 1.05, 0.0);
            TextCenter(w, layer, "[S]: " + F(result.TotalDistanceM, 2), Mid(col[3], col[4]), infoY, 1.05, 0.0);
            TextCenter(w, layer, "[ΔY]: " + F(sumDy, 2), Mid(col[4], col[5]), infoY, 1.05, 0.0);
            TextCenter(w, layer, "[ΔX]: " + F(sumDx, 2), Mid(col[5], col[6]), infoY, 1.05, 0.0);
            if (result.Mode == TraverseMode.Acik)
            {
                TextCenter(w, layer, "Açık poligonda kapanış hatası hesaplanmaz.", x + width / 2.0, infoY - 3.0, 1.3, 0.0);
            }
            else
            {
                infoY -= 3.0;
                TextCenter(w, layer, "Fβ=" + F(result.AngularMisclosureGon * 10000.0, 0) + "cc", Mid(col[1], col[2]), infoY, 1.05, 0.0);
                infoY -= 3.0;
                TextCenter(w, layer, "fl=" + F(result.Fy * 100.0, 0) + "cm", Mid(col[1], col[2]), infoY, 0.95, 0.0);
                TextCenter(w, layer, "fq=" + F(result.Fx * 100.0, 0) + "cm", Mid(col[2], col[3]), infoY, 0.95, 0.0);
                TextCenter(w, layer, "fs=" + F(result.Fs * 100.0, 0) + "cm", Mid(col[3], col[4]), infoY, 0.95, 0.0);
                TextCenter(w, layer, "fy=" + F(result.Fy * 100.0, 0) + "cm", Mid(col[4], col[5]), infoY, 0.95, 0.0);
                TextCenter(w, layer, "fx=" + F(result.Fx * 100.0, 0) + "cm", Mid(col[5], col[6]), infoY, 0.95, 0.0);
            }
            double legalY = frameBottom - 3.0;
            if (result.Mode != TraverseMode.Acik)
                Text(w, layer, ReportWriter.LegalText, x + 2.0, legalY, 1.1, 0.0);
            Text(w, layer, "Hesap; " + input.CalculationDate.ToString("dd.MM.yyyy", CultureInfo.GetCultureInfo("tr-TR")) + " tarihinde " + Safe(input.OperatorName) + " tarafından yapılmıştır.", x + 2.0, legalY - 3.0, 1.2, 0.0);
        }

        private static double Mid(double a, double b) { return (a + b) / 2.0; }

        private static void DrawStartTick(StreamWriter w, double x1, double y1, double x2, double y2, double h)
        {
            double dx = x2 - x1, dy = y2 - y1, len = Math.Sqrt(dx * dx + dy * dy);
            if (len <= 1e-8) return;
            double px = -dy / len * h * 1.5, py = dx / len * h * 1.5;
            Line(w, "PH_Guzg", x1 - px, y1 - py, x1 + px, y1 + py);
        }

        private static void DrawArrow(StreamWriter w, double x1, double y1, double x2, double y2, double h)
        {
            double dx = x2 - x1, dy = y2 - y1, len = Math.Sqrt(dx * dx + dy * dy);
            if (len <= 1e-8) return;
            double ux = dx / len, uy = dy / len;
            double ax = (x1 + x2) / 2.0 + ux * h, ay = (y1 + y2) / 2.0 + uy * h;
            double bx = ax - ux * h * 2.0, by = ay - uy * h * 2.0;
            Line(w, "PH_Guzg", ax, ay, bx - uy * h, by + ux * h);
            Line(w, "PH_Guzg", ax, ay, bx + uy * h, by - ux * h);
        }

        private static void Line(StreamWriter w, string layer, double x1, double y1, double x2, double y2)
        {
            Pair(w, 0, "LINE"); Pair(w, 8, layer); Pair(w, 10, N(x1)); Pair(w, 20, N(y1)); Pair(w, 30, "0.0"); Pair(w, 11, N(x2)); Pair(w, 21, N(y2)); Pair(w, 31, "0.0");
        }

        private static void Point(StreamWriter w, string layer, double x, double y, double z)
        {
            Pair(w, 0, "POINT"); Pair(w, 8, layer); Pair(w, 10, N(x)); Pair(w, 20, N(y)); Pair(w, 30, N(z));
        }

        private static void Circle(StreamWriter w, string layer, double x, double y, double radius)
        {
            Pair(w, 0, "CIRCLE"); Pair(w, 8, layer); Pair(w, 10, N(x)); Pair(w, 20, N(y)); Pair(w, 30, "0.0"); Pair(w, 40, N(radius));
        }

        private static void Text(StreamWriter w, string layer, string text, double x, double y, double height, double rotation)
        {
            WriteText(w, layer, text, x, y, height, rotation, false);
        }

        private static void TextCenter(StreamWriter w, string layer, string text, double x, double y, double height, double rotation)
        {
            WriteText(w, layer, text, x, y, height, rotation, true);
        }

        private static void WriteText(StreamWriter w, string layer, string text, double x, double y, double height, double rotation, bool centered)
        {
            string cleanText = Safe(text);
            if (String.IsNullOrWhiteSpace(cleanText)) return;
            Pair(w, 0, "TEXT"); Pair(w, 8, layer); Pair(w, 10, N(x)); Pair(w, 20, N(y)); Pair(w, 30, "0.0"); Pair(w, 40, N(height)); Pair(w, 1, cleanText); Pair(w, 50, N(rotation)); Pair(w, 7, "PH-TSTYLE");
            if (centered) { Pair(w, 72, "1"); Pair(w, 73, "0"); Pair(w, 11, N(x)); Pair(w, 21, N(y)); Pair(w, 31, "0.0"); }
        }

        private static string Safe(string text) { return (text ?? String.Empty).Replace("\r", " ").Replace("\n", " "); }
        private static string F(double v, int digits) { return v.ToString("F" + digits, CultureInfo.InvariantCulture); }
        private static string N(double value) { return value.ToString("0.########", CultureInfo.InvariantCulture); }
        private static void Pair(StreamWriter w, int code, string value) { w.WriteLine(code.ToString(CultureInfo.InvariantCulture)); w.WriteLine(value); }
    }
}
