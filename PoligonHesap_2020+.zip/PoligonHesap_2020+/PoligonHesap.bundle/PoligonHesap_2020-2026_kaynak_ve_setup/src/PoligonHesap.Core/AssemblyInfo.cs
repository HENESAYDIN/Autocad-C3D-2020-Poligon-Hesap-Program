using System.Reflection;

[assembly: AssemblyTitle("Poligon Hesap Core")]
[assembly: AssemblyProduct("Poligon Hesap")]
[assembly: AssemblyCompany("PoligonHesap")]
[assembly: AssemblyDescription("Shared calculation and report engine")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
