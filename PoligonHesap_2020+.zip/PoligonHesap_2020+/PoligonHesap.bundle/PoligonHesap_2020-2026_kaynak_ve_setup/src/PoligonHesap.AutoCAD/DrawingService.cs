using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Autodesk.AutoCAD.Colors;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using PoligonHesap.Core;

namespace PoligonHesap.AutoCAD
{
    internal static class DrawingService
    {
        private static readonly string[] Layers = { "PH_Limit", "PH_GYazi", "PH_Yazi", "PH_Grid", "PH_EskiPol", "PH_PolAdi", "PH_PolKot", "PH_YeniPol", "PH_Guzg", "PH_PolCiz" };
        // AutoCAD ACI and role mapping follows Pol2020.dvb KVO_HazirlaKatmanlar.
        private static readonly short[] Colors = { 5, 7, 7, 7, 2, 6, 3, 1, 4, 7 };
        private const string TextStyleName = "PH-TSTYLE";
        private sealed class Bounds { public double MinE, MaxE, MinN, MaxN; }
        private sealed class TableSegment { public TraverseLegResult Leg; public bool ShowDistance; }

        public static void Draw(Database db, TraverseInput input, TraverseResult result)
        {
            if (db == null) throw new ArgumentNullException("db");
            if (input == null) throw new ArgumentNullException("input");
            if (result == null || result.Points.Count < 2) throw new InvalidOperationException("Önce en az iki noktalı bir hesap yapılmalıdır.");
            EnsureHiddenLinetype(db);
            Bounds bounds = GetBounds(input, result);
            double h = TextHeight(bounds);
            using (var tr = db.TransactionManager.StartTransaction())
            {
                for (int i = 0; i < Layers.Length; i++)
                    EnsureLayer(db, tr, Layers[i], Colors[i], Layers[i] == "PH_Grid" ? "HIDDEN" : "Continuous", Layers[i] == "PH_Limit" ? LineWeight.LineWeight030 : LineWeight.LineWeight015);
                ObjectId textStyleId = EnsureTextStyle(db, tr);
                var blockTable = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                var model = (BlockTableRecord)tr.GetObject(blockTable[BlockTableRecord.ModelSpace], OpenMode.ForWrite);
                ClearPreviousPoligonDrawing(tr, model);
                DrawGrid(db, tr, model, textStyleId, input, bounds, h);
                DrawRoute(db, tr, model, textStyleId, input, result, h);
                tr.Commit();
            }
        }

        public static void DrawCalculationTable(Database db, TraverseInput input, TraverseResult result, Point3d topLeft)
        {
            if (db == null) throw new ArgumentNullException("db");
            if (input == null || result == null) throw new ArgumentNullException("Hesap girdisi/sonucu boş olamaz.");
            if (result.Points.Count == 0) throw new InvalidOperationException("Hesaplanmış koordinat bulunamadı.");
            EnsureHiddenLinetype(db);
            using (var tr = db.TransactionManager.StartTransaction())
            {
                EnsureLayer(db, tr, "PH_PolCiz", 7, "Continuous", LineWeight.LineWeight015);
                ObjectId styleId = EnsureTextStyle(db, tr);
                var blockTable = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                var model = (BlockTableRecord)tr.GetObject(blockTable[BlockTableRecord.ModelSpace], OpenMode.ForWrite);
                DrawTable(db, tr, model, styleId, input, result, topLeft.X, topLeft.Y);
                tr.Commit();
            }
        }

        private static void EnsureHiddenLinetype(Database db)
        {
            try { db.LoadLineTypeFile("HIDDEN", "acad.lin"); }
            catch
            {
                try { db.LoadLineTypeFile("HIDDEN", "acadiso.lin"); }
                catch { /* Existing drawings may already have HIDDEN loaded. */ }
            }
        }

        private static Bounds GetBounds(TraverseInput input, TraverseResult result)
        {
            var points = input.ControlPoints.Concat(result.Points).ToList();
            double minE = points.Min(p => p.Y), maxE = points.Max(p => p.Y);
            double minN = points.Min(p => p.X), maxN = points.Max(p => p.X);
            // Match the source DXF writer's 100 m rounding and DVB's frame margin.
            double e0 = Math.Floor(minE / 100.0) * 100.0 - 100.0;
            double e1 = Math.Floor(maxE / 100.0) * 100.0 + 200.0;
            double n0 = Math.Floor(minN / 100.0) * 100.0 - 100.0;
            double n1 = Math.Floor(maxN / 100.0) * 100.0 + 200.0;
            if (e1 <= e0) e1 = e0 + 200.0;
            if (n1 <= n0) n1 = n0 + 200.0;
            return new Bounds { MinE = e0, MaxE = e1, MinN = n0, MaxN = n1 };
        }

        private static double TextHeight(Bounds b)
        {
            double extent = Math.Max(b.MaxE - b.MinE, b.MaxN - b.MinN);
            return Math.Max(1.0, extent / 55.0);
        }

        private static void DrawGrid(Database db, Transaction tr, BlockTableRecord model, ObjectId styleId, TraverseInput input, Bounds b, double h)
        {
            AddLine(db, tr, model, "PH_Limit", b.MinE, b.MinN, b.MaxE, b.MinN);
            AddLine(db, tr, model, "PH_Limit", b.MaxE, b.MinN, b.MaxE, b.MaxN);
            AddLine(db, tr, model, "PH_Limit", b.MaxE, b.MaxN, b.MinE, b.MaxN);
            AddLine(db, tr, model, "PH_Limit", b.MinE, b.MaxN, b.MinE, b.MinN);
            for (double e = Math.Ceiling(b.MinE / 100.0) * 100.0; e <= b.MaxE; e += 100.0)
                AddLine(db, tr, model, "PH_Grid", e, b.MinN, e, b.MaxN, 25.0);
            for (double n = Math.Ceiling(b.MinN / 100.0) * 100.0; n <= b.MaxN; n += 100.0)
                AddLine(db, tr, model, "PH_Grid", b.MinE, n, b.MaxE, n, 25.0);

            // The DVB uses vertical easting labels below the frame and horizontal northing labels at left.
            for (double e = Math.Ceiling(b.MinE / 100.0) * 100.0; e <= b.MaxE; e += 100.0)
                AddCenteredText(db, tr, model, styleId, "PH_GYazi", F(e, 0), e, b.MinN - 3.0, 2.0, Math.PI / 2.0);
            for (double n = Math.Ceiling(b.MinN / 100.0) * 100.0; n <= b.MaxN; n += 100.0)
                AddCenteredText(db, tr, model, styleId, "PH_GYazi", F(n, 0), b.MinE - 3.0, n, 2.0);

            double centerE = (b.MinE + b.MaxE) / 2.0;
            AddCenteredText(db, tr, model, styleId, "PH_Yazi", "POLİGON KANAVASI", centerE, b.MaxN + h * 3.0, h * 1.25);
            AddText(db, tr, model, styleId, "PH_Yazi", "Şehir/Kasaba Adı: " + SafeText(input.CityName), b.MinE + 4.0, b.MaxN - h * 1.5, h * 0.80);
            AddText(db, tr, model, styleId, "PH_Yazi", "Güzergah No: " + SafeText(input.RouteNumber), b.MinE + 4.0, b.MaxN - h * 2.7, h * 0.80);
            AddCenteredText(db, tr, model, styleId, "PH_Yazi", "1:1000", centerE, b.MinN - h * 3.0, h);
        }

        private static void DrawRoute(Database db, Transaction tr, BlockTableRecord model, ObjectId styleId, TraverseInput input, TraverseResult result, double h)
        {
            using (var polyline = new Polyline())
            {
                polyline.SetDatabaseDefaults(db); polyline.Layer = "PH_Guzg";
                for (int i = 0; i < result.Points.Count; i++) polyline.AddVertexAt(i, new Point2d(result.Points[i].Y, result.Points[i].X), 0.0, 0.0, 0.0);
                polyline.Closed = false; model.AppendEntity(polyline); tr.AddNewlyCreatedDBObject(polyline, true);
            }
            if (result.Legs.Count > 0)
            {
                SurveyPoint first = result.Points[0], second = result.Points[1];
                AddStartTick(db, tr, model, first.Y, first.X, second.Y, second.X, Math.Max(h, 1.0));
                SurveyPoint lastFrom = result.Points[result.Points.Count - 2], lastTo = result.Points[result.Points.Count - 1];
                DrawArrow(db, tr, model, lastFrom.Y, lastFrom.X, lastTo.Y, lastTo.X, Math.Max(h, 1.0));
            }
            foreach (SurveyPoint control in input.ControlPoints)
            {
                AddPoint(db, tr, model, "PH_EskiPol", control.Y, control.X);
                AddCircle(db, tr, model, "PH_EskiPol", control.Y, control.X, Math.Max(h * 0.42, 0.3));
                AddText(db, tr, model, styleId, "PH_PolAdi", control.Name, control.Y + h * 0.8, control.X + h * 0.8, h * 0.75);
                AddText(db, tr, model, styleId, "PH_PolKot", F(control.Z, 0), control.Y + h * 0.8, control.X - h * 0.65, h * 0.65);
            }
            foreach (SurveyPoint point in result.Points.Where(p => input.FindPoint(p.Name) == null))
            {
                AddPoint(db, tr, model, "PH_YeniPol", point.Y, point.X);
                AddCircle(db, tr, model, "PH_YeniPol", point.Y, point.X, Math.Max(h * 0.38, 0.28));
                AddText(db, tr, model, styleId, "PH_PolAdi", point.Name, point.Y + h * 0.8, point.X + h * 0.8, h * 0.75);
            }
            if (result.Points.Count > 1)
            {
                SurveyPoint first = result.Points[0], second = result.Points[1];
                double midE = (first.Y + second.Y) / 2.0, midN = (first.X + second.X) / 2.0;
                AddCircle(db, tr, model, "PH_Guzg", midE, midN, h * 1.2);
                AddCenteredText(db, tr, model, styleId, "PH_Guzg", SafeText(input.RouteNumber), midE, midN, h);
            }
        }

        private static void DrawTable(Database db, Transaction tr, BlockTableRecord model, ObjectId styleId, TraverseInput input, TraverseResult result, double x, double top)
        {
            // DVB PT_CreateTableDrwgExact column breaks: 0, 10, 25, 40, 55, 70, 85, 100, 115, 125.
            double[] widths = { 10, 15, 15, 15, 15, 15, 15, 15, 10 };
            double[] col = new double[widths.Length + 1]; col[0] = x;
            for (int i = 0; i < widths.Length; i++) col[i + 1] = col[i] + widths[i];
            const string layer = "PH_PolCiz";
            AddLine(db, tr, model, layer, col[0], top, col[9], top);
            AddCenteredText(db, tr, model, styleId, layer, "P O L İ G O N   H E S A B I", x + 62.5, top - 4.5, 2.5);
            AddLine(db, tr, model, layer, col[0], top - 7.5, col[9], top - 7.5);
            AddText(db, tr, model, styleId, layer, "Şehir/Kasaba Adı: " + SafeText(input.CityName), x + 1.0, top - 8.75, 1.5);
            AddText(db, tr, model, styleId, layer, "Güzergah No: " + SafeText(input.RouteNumber), x + 1.0, top - 11.25, 1.5);
            double metaBottom = top - 12.5;
            AddLine(db, tr, model, layer, col[0], metaBottom, col[9], metaBottom);

            AddCenteredText(db, tr, model, styleId, layer, "Nokta", Mid(col[0], col[1]), top - 14.5, 1.4);
            AddCenteredText(db, tr, model, styleId, layer, "Kırılma", Mid(col[1], col[2]), top - 14.5, 1.4);
            AddCenteredText(db, tr, model, styleId, layer, "Açıklık", Mid(col[2], col[3]), top - 14.5, 1.4);
            AddCenteredText(db, tr, model, styleId, layer, "Kenarlar", Mid(col[3], col[4]), top - 14.5, 1.4);
            AddCenteredText(db, tr, model, styleId, layer, "Koordinat Farkları", Mid(col[4], col[6]), top - 14.5, 1.35);
            AddCenteredText(db, tr, model, styleId, layer, "Koordinatlar", Mid(col[6], col[8]), top - 14.5, 1.35);
            AddCenteredText(db, tr, model, styleId, layer, "Nokta", Mid(col[8], col[9]), top - 14.5, 1.4);
            AddLine(db, tr, model, layer, col[4], top - 16.25, col[8], top - 16.25);
            string[] headers = { "No", "Açısı β", "Açısı α", "S(m)", "ΔY(m)", "ΔX(m)", "Y(m)", "X(m)", "No" };
            for (int c = 0; c < headers.Length; c++) AddCenteredText(db, tr, model, styleId, layer, headers[c], Mid(col[c], col[c + 1]), top - 18.25, 1.25);
            double headerBottom = top - 20.0;
            AddLine(db, tr, model, layer, col[0], headerBottom, col[9], headerBottom);

            var points = new List<SurveyPoint>();
            SurveyPoint back = input.FindPoint(input.BackReferenceName);
            SurveyPoint forward = input.FindPoint(input.ForwardReferenceName);
            if (back != null) points.Add(back);
            points.AddRange(result.Points);
            if (forward != null) points.Add(forward);

            var segments = new List<TableSegment>();
            if (back != null && result.Points.Count > 0)
            {
                SurveyPoint first = result.Points[0];
                segments.Add(new TableSegment { Leg = ControlSegment(back, first, result.StartBearingGon), ShowDistance = false });
            }
            foreach (TraverseLegResult leg in result.Legs) segments.Add(new TableSegment { Leg = leg, ShowDistance = true });
            if (forward != null && result.Points.Count > 0)
            {
                SurveyPoint last = result.Points[result.Points.Count - 1];
                segments.Add(new TableSegment { Leg = ControlSegment(last, forward, result.ExpectedEndBearingGon), ShowDistance = false });
            }

            double rowY = top - 22.5;
            double lastRowY = rowY;
            for (int i = 0; i < points.Count; i++)
            {
                SurveyPoint point = points[i];
                TraverseObservation stationAngle = input.Observations.FirstOrDefault(o => TraverseInput.NormalizeName(o.StationName) == TraverseInput.NormalizeName(point.Name));
                string angle = stationAngle == null ? String.Empty : F(stationAngle.AngleGon, 4);
                string[] pointCells = { point.Name, angle, String.Empty, String.Empty, String.Empty, String.Empty, F(point.Y, 3), F(point.X, 3), point.Name };
                for (int c = 0; c < pointCells.Length; c++) AddCenteredText(db, tr, model, styleId, layer, pointCells[c], Mid(col[c], col[c + 1]), rowY, 1.35);
                lastRowY = rowY;
                rowY -= 3.0;

                if (i < segments.Count)
                {
                    TraverseLegResult leg = segments[i].Leg;
                    AddCenteredText(db, tr, model, styleId, layer, F(leg.BearingGon, 4), Mid(col[2], col[3]), rowY, 1.3);
                    if (segments[i].ShowDistance)
                    {
                        AddCenteredText(db, tr, model, styleId, layer, F(leg.DistanceM, 3), Mid(col[3], col[4]), rowY, 1.3);
                        AddCenteredText(db, tr, model, styleId, layer, F(leg.AdjustedDY, 3), Mid(col[4], col[5]), rowY, 1.3);
                        AddCenteredText(db, tr, model, styleId, layer, F(leg.AdjustedDX, 3), Mid(col[5], col[6]), rowY, 1.3);
                    }
                    lastRowY = rowY;
                    rowY -= 3.0;
                }
            }
            double dataBottom = lastRowY - 2.0;
            int footerRows = result.Mode == TraverseMode.Acik ? 2 : 3;
            double firstInfoY = dataBottom - 4.0;
            double bottom = firstInfoY - (footerRows - 1) * 3.0 - 2.0;
            for (int c = 0; c < col.Length; c++)
            {
                bool outer = c == 0 || c == 9;
                double startY = outer ? top : (c == 5 || c == 7 ? top - 16.25 : metaBottom);
                AddLine(db, tr, model, layer, col[c], startY, col[c], outer ? bottom : dataBottom);
            }
            AddLine(db, tr, model, layer, col[0], dataBottom, col[9], dataBottom);
            AddLine(db, tr, model, layer, col[0], bottom, col[9], bottom);

            double infoY = firstInfoY;
            double sumDy = result.Legs.Sum(l => l.AdjustedDY), sumDx = result.Legs.Sum(l => l.AdjustedDX);
            double sumBeta = input.Observations.Sum(o => o.AngleGon);
            AddCenteredText(db, tr, model, styleId, layer, "[β]: " + F(sumBeta, 4), Mid(col[1], col[2]), infoY, 1.05);
            AddCenteredText(db, tr, model, styleId, layer, "[S]: " + F(result.TotalDistanceM, 2), Mid(col[3], col[4]), infoY, 1.05);
            AddCenteredText(db, tr, model, styleId, layer, "[ΔY]: " + F(sumDy, 2), Mid(col[4], col[5]), infoY, 1.05);
            AddCenteredText(db, tr, model, styleId, layer, "[ΔX]: " + F(sumDx, 2), Mid(col[5], col[6]), infoY, 1.05);
            if (result.Mode == TraverseMode.Acik)
                AddCenteredText(db, tr, model, styleId, layer, "Açık poligonda kapanış hatası hesaplanmaz.", x + 62.5, infoY - 3.0, 1.3);
            else
            {
                infoY -= 3.0;
                AddCenteredText(db, tr, model, styleId, layer, "Fβ=" + F(result.AngularMisclosureGon * 10000.0, 0) + "cc", Mid(col[1], col[2]), infoY, 1.05);
                infoY -= 3.0;
                AddCenteredText(db, tr, model, styleId, layer, "fl=" + F(result.Fy * 100.0, 0) + "cm", Mid(col[1], col[2]), infoY, 0.95);
                AddCenteredText(db, tr, model, styleId, layer, "fq=" + F(result.Fx * 100.0, 0) + "cm", Mid(col[2], col[3]), infoY, 0.95);
                AddCenteredText(db, tr, model, styleId, layer, "fs=" + F(result.Fs * 100.0, 0) + "cm", Mid(col[3], col[4]), infoY, 0.95);
                AddCenteredText(db, tr, model, styleId, layer, "fy=" + F(result.Fy * 100.0, 0) + "cm", Mid(col[4], col[5]), infoY, 0.95);
                AddCenteredText(db, tr, model, styleId, layer, "fx=" + F(result.Fx * 100.0, 0) + "cm", Mid(col[5], col[6]), infoY, 0.95);
            }
            double legalY = bottom - 3.0;
            if (result.Mode != TraverseMode.Acik)
                AddText(db, tr, model, styleId, layer, ReportWriter.LegalText, x + 2.0, legalY, 1.1);
            AddText(db, tr, model, styleId, layer, "Hesap; " + input.CalculationDate.ToString("dd.MM.yyyy", CultureInfo.GetCultureInfo("tr-TR")) + " tarihinde " + SafeText(input.OperatorName) + " tarafından yapılmıştır.", x + 2.0, legalY - 3.0, 1.2);
        }

        private static TraverseLegResult ControlSegment(SurveyPoint from, SurveyPoint to, double bearing)
        {
            return new TraverseLegResult
            {
                FromName = from.Name, ToName = to.Name, BearingGon = bearing,
                DistanceM = Math.Sqrt(Math.Pow(to.Y - from.Y, 2.0) + Math.Pow(to.X - from.X, 2.0)),
                AdjustedDY = to.Y - from.Y, AdjustedDX = to.X - from.X
            };
        }

        private static double Mid(double a, double b) { return (a + b) / 2.0; }

        private static void DrawArrow(Database db, Transaction tr, BlockTableRecord model, double x1, double y1, double x2, double y2, double size)
        {
            double dx = x2 - x1, dy = y2 - y1, length = Math.Sqrt(dx * dx + dy * dy); if (length <= 1e-8) return;
            double ux = dx / length, uy = dy / length, mx = (x1 + x2) / 2.0, my = (y1 + y2) / 2.0;
            double ax = mx + ux * size, ay = my + uy * size, bx = ax - ux * size * 2.0, by = ay - uy * size * 2.0;
            AddLine(db, tr, model, "PH_Guzg", ax, ay, bx - uy * size, by + ux * size);
            AddLine(db, tr, model, "PH_Guzg", ax, ay, bx + uy * size, by - ux * size);
        }

        private static void AddStartTick(Database db, Transaction tr, BlockTableRecord model, double x1, double y1, double x2, double y2, double size)
        {
            double dx = x2 - x1, dy = y2 - y1, length = Math.Sqrt(dx * dx + dy * dy); if (length <= 1e-8) return;
            double px = -dy / length * size * 1.5, py = dx / length * size * 1.5;
            AddLine(db, tr, model, "PH_Guzg", x1 - px, y1 - py, x1 + px, y1 + py);
        }

        private static void ClearPreviousPoligonDrawing(Transaction tr, BlockTableRecord model)
        {
            var stale = new List<ObjectId>();
            foreach (ObjectId id in model)
            {
                var entity = tr.GetObject(id, OpenMode.ForRead, false) as Entity;
                if (entity != null && Layers.Contains(entity.Layer)) stale.Add(id);
            }
            foreach (ObjectId id in stale)
            {
                var entity = tr.GetObject(id, OpenMode.ForWrite, false) as Entity;
                if (entity != null && !entity.IsErased) entity.Erase();
            }
        }

        private static void AddLine(Database db, Transaction tr, BlockTableRecord model, string layer, double x1, double y1, double x2, double y2, double linetypeScale = 1.0)
        {
            using (var entity = new Line(new Point3d(x1, y1, 0.0), new Point3d(x2, y2, 0.0)))
            {
                entity.SetDatabaseDefaults(db); entity.Layer = layer; entity.LinetypeScale = linetypeScale; model.AppendEntity(entity); tr.AddNewlyCreatedDBObject(entity, true);
            }
        }

        private static void AddPoint(Database db, Transaction tr, BlockTableRecord model, string layer, double x, double y)
        {
            using (var entity = new DBPoint(new Point3d(x, y, 0.0))) { entity.SetDatabaseDefaults(db); entity.Layer = layer; model.AppendEntity(entity); tr.AddNewlyCreatedDBObject(entity, true); }
        }

        private static void AddCircle(Database db, Transaction tr, BlockTableRecord model, string layer, double x, double y, double radius)
        {
            using (var entity = new Circle(new Point3d(x, y, 0.0), Vector3d.ZAxis, radius)) { entity.SetDatabaseDefaults(db); entity.Layer = layer; model.AppendEntity(entity); tr.AddNewlyCreatedDBObject(entity, true); }
        }

        private static void AddText(Database db, Transaction tr, BlockTableRecord model, ObjectId styleId, string layer, string text, double x, double y, double height)
        {
            AddTextCore(db, tr, model, styleId, layer, text, x, y, height, false, 0.0);
        }

        private static void AddCenteredText(Database db, Transaction tr, BlockTableRecord model, ObjectId styleId, string layer, string text, double x, double y, double height, double rotation = 0.0)
        {
            AddTextCore(db, tr, model, styleId, layer, text, x, y, height, true, rotation);
        }

        private static void AddTextCore(Database db, Transaction tr, BlockTableRecord model, ObjectId styleId, string layer, string text, double x, double y, double height, bool centered, double rotation)
        {
            using (var entity = new DBText())
            {
                entity.SetDatabaseDefaults(db); entity.Layer = layer; entity.TextStyleId = styleId; entity.Height = height; entity.TextString = SafeText(text); entity.Rotation = rotation;
                entity.Position = new Point3d(x, y, 0.0);
                if (centered)
                {
                    entity.HorizontalMode = TextHorizontalMode.TextCenter;
                    entity.AlignmentPoint = new Point3d(x, y, 0.0);
                    entity.AdjustAlignment(db);
                }
                model.AppendEntity(entity); tr.AddNewlyCreatedDBObject(entity, true);
            }
        }

        private static void EnsureLayer(Database db, Transaction tr, string name, short colorIndex, string linetypeName, LineWeight lineWeight)
        {
            var layers = (LayerTable)tr.GetObject(db.LayerTableId, OpenMode.ForRead);
            LayerTableRecord layer;
            if (layers.Has(name))
            {
                layer = (LayerTableRecord)tr.GetObject(layers[name], OpenMode.ForWrite);
            }
            else
            {
                layers.UpgradeOpen();
                layer = new LayerTableRecord();
                layer.Name = name;
                layers.Add(layer);
                tr.AddNewlyCreatedDBObject(layer, true);
            }
            layer.Color = Color.FromColorIndex(ColorMethod.ByAci, colorIndex);
            layer.LineWeight = lineWeight;
            var linetypes = (LinetypeTable)tr.GetObject(db.LinetypeTableId, OpenMode.ForRead);
            if (linetypes.Has(linetypeName)) layer.LinetypeObjectId = linetypes[linetypeName];
            else if (linetypes.Has("Continuous")) layer.LinetypeObjectId = linetypes["Continuous"];
        }

        private static ObjectId EnsureTextStyle(Database db, Transaction tr)
        {
            var styles = (TextStyleTable)tr.GetObject(db.TextStyleTableId, OpenMode.ForRead);
            TextStyleTableRecord style;
            if (styles.Has(TextStyleName)) style = (TextStyleTableRecord)tr.GetObject(styles[TextStyleName], OpenMode.ForWrite);
            else
            {
                styles.UpgradeOpen();
                style = new TextStyleTableRecord(); style.Name = TextStyleName;
                styles.Add(style); tr.AddNewlyCreatedDBObject(style, true);
            }
            style.FileName = "arial.ttf";
            style.BigFontFileName = String.Empty;
            style.ObliquingAngle = 0.0;
            style.XScale = 1.0;
            return style.ObjectId;
        }

        private static string SafeText(string value) { return (value ?? String.Empty).Replace("\r", " ").Replace("\n", " "); }
        private static string F(double value, int digits) { return value.ToString("F" + digits, CultureInfo.InvariantCulture); }
    }
}
