using System;
using System.Globalization;
using System.IO;
using System.Text;
using Autodesk.AutoCAD.DatabaseServices;
using PoligonHesap.Core;

namespace PoligonHesap.AutoCAD
{
    /// <summary>
    /// Production DXF path: build the map in an isolated AutoCAD database and let
    /// AutoCAD's own R12 serializer write the interchange file.
    /// </summary>
    internal static class AutoCadDxfExporter
    {
        public static string Write(string path, TraverseInput input, TraverseResult result)
        {
            if (String.IsNullOrWhiteSpace(path)) throw new ArgumentException("DXF kayıt yolu boş olamaz.", "path");
            if (input == null) throw new ArgumentNullException("input");
            if (result == null || result.Points.Count < 2) throw new ArgumentException("DXF için en az iki hesaplanmış nokta gerekir.");

            string fullPath = Path.GetFullPath(path);
            string folder = Path.GetDirectoryName(fullPath);
            if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
            string tempPath = Path.Combine(folder, Path.GetFileNameWithoutExtension(fullPath) + "." + Guid.NewGuid().ToString("N") + ".dxf");
            bool preserveDiagnostic = false;
            try
            {
                using (var db = new Database(true, true))
                {
                    DrawingService.Draw(db, input, result);
                    EscapeNonAsciiTextForR12(db);
                    db.UpdateExt(true);
                    db.DxfOut(tempPath, 16, DwgVersion.AC1009);
                }
                // AutoCAD may omit or replace legacy metadata; preserve raw bytes while fixing codepage/font records.
                Encoding latin1 = Encoding.GetEncoding(28591);
                string dxfText = File.ReadAllText(tempPath, latin1);
                File.WriteAllText(tempPath, DxfR12PostProcessor.Normalize(dxfText), latin1);
                ValidateR12File(tempPath);
                return CommitWithFallback(tempPath, fullPath);
            }
            catch (InvalidDataException ex)
            {
                preserveDiagnostic = true;
                throw new InvalidDataException(ex.Message + " Geçici DXF teşhis dosyası: " + tempPath, ex);
            }
            finally
            {
                if (!preserveDiagnostic && File.Exists(tempPath)) File.Delete(tempPath);
            }
        }

        private static void ValidateR12File(string path)
        {
            var info = new FileInfo(path);
            if (!info.Exists || info.Length < 512) throw new InvalidDataException("AutoCAD R12 DXF çıktısı boş veya eksik.");
            string text = File.ReadAllText(path, Encoding.ASCII).Replace("\r\n", "\n").Replace('\r', '\n');
            string[] lines = text.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            if (text.IndexOf("arial.ttf", StringComparison.OrdinalIgnoreCase) < 0)
                throw new InvalidDataException("AutoCAD R12 DXF çıktısında Arial (arial.ttf) yazı stili bulunamadı.");
            string detectedVersion = null;
            for (int i = 0; i + 3 < lines.Length; i++)
            {
                if (lines[i].Trim() == "9" && lines[i + 1].Trim() == "$ACADVER" && lines[i + 2].Trim() == "1")
                {
                    detectedVersion = lines[i + 3].Trim();
                    break;
                }
            }
            bool eofFound = lines.Length >= 2 && lines[lines.Length - 2].Trim() == "0" && lines[lines.Length - 1].Trim() == "EOF";
            if (!String.Equals(detectedVersion, "AC1009", StringComparison.Ordinal) || !eofFound)
            {
                string version = detectedVersion ?? "bulunamadı";
                string eof = eofFound ? "EOF bulundu" : "EOF bulunamadı";
                throw new InvalidDataException("AutoCAD DXF doğrulaması başarısız: bulunan $ACADVER='" + version + "'; " + eof + ". Teşhis çıktısı geçici dosyada korunacak.");
            }
        }

        private static void EscapeNonAsciiTextForR12(Database db)
        {
            using (var tr = db.TransactionManager.StartTransaction())
            {
                var blockTable = (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                var model = (BlockTableRecord)tr.GetObject(blockTable[BlockTableRecord.ModelSpace], OpenMode.ForRead);
                foreach (ObjectId id in model)
                {
                    var text = tr.GetObject(id, OpenMode.ForWrite, false) as DBText;
                    if (text == null) continue;
                    string escaped = DxfTextEncoding.EscapeNonAscii(text.TextString);
                    if (!String.Equals(escaped, text.TextString, StringComparison.Ordinal)) text.TextString = escaped;
                }
                tr.Commit();
            }
        }

        private static string CommitWithFallback(string tempPath, string requestedPath)
        {
            if (!File.Exists(requestedPath))
            {
                try { File.Move(tempPath, requestedPath); return requestedPath; }
                catch (IOException) { if (!File.Exists(requestedPath)) throw; }
            }
            else if (CanReplace(requestedPath))
            {
                try { File.Replace(tempPath, requestedPath, null); return requestedPath; }
                catch (IOException) { /* Keep the old output and use a numbered sibling. */ }
                catch (UnauthorizedAccessException) { /* Keep the old output and use a numbered sibling. */ }
            }
            return MoveToVersionedPath(tempPath, requestedPath);
        }

        private static bool CanReplace(string path)
        {
            try { using (new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { } return true; }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        private static string MoveToVersionedPath(string tempPath, string requestedPath)
        {
            string folder = Path.GetDirectoryName(requestedPath);
            string stem = Path.GetFileNameWithoutExtension(requestedPath);
            string extension = Path.GetExtension(requestedPath);
            for (int suffix = 2; suffix < 10000; suffix++)
            {
                string candidate = Path.Combine(folder, stem + "_" + suffix.ToString(CultureInfo.InvariantCulture) + extension);
                if (File.Exists(candidate)) continue;
                try { File.Move(tempPath, candidate); return candidate; }
                catch (IOException) { if (!File.Exists(candidate)) throw; }
            }
            throw new IOException("DXF dosyası kullanımda ve boş alternatif dosya adı bulunamadı: " + requestedPath);
        }
    }
}
