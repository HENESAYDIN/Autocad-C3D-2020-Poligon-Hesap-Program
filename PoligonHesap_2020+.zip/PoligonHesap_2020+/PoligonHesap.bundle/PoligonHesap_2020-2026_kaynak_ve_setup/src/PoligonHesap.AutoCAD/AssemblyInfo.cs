using System.Reflection;

#if NETCOREAPP
[assembly: System.Runtime.Versioning.SupportedOSPlatform("windows")]
#endif

[assembly: AssemblyTitle("Poligon Hesap AutoCAD Add-in")]
[assembly: AssemblyProduct("Poligon Hesap")]
[assembly: AssemblyCompany("PoligonHesap")]
[assembly: AssemblyDescription("Release-specific AutoCAD/Civil 3D plugin")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
