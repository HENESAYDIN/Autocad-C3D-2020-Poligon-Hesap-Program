using System;
using System.Diagnostics;
using System.Windows.Input;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.Windows;
using System.Windows;
using System.Windows.Media;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace PoligonHesap.AutoCAD
{
    internal static class RibbonService
    {
        private const string TabId = "POLHESAP_RIBBON_TAB";
        private static bool _listening;
        private static readonly ICommand CommandHandler = new AutoCadRibbonCommandHandler();
        private static readonly ImageSource PoligonIcon = CreatePoligonIcon();

        public static void Initialize()
        {
            try
            {
                if (ComponentManager.Ribbon != null)
                {
                    EnsureTab();
                    return;
                }

                if (!_listening)
                {
                    ComponentManager.ItemInitialized += OnRibbonItemInitialized;
                    _listening = true;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("PoligonHesap Ribbon başlangıç hatası: " + ex);
            }
        }

        private static void OnRibbonItemInitialized(object sender, RibbonItemEventArgs e)
        {
            if (ComponentManager.Ribbon == null) return;
            ComponentManager.ItemInitialized -= OnRibbonItemInitialized;
            _listening = false;
            try { EnsureTab(); }
            catch (Exception ex) { Debug.WriteLine("PoligonHesap Ribbon oluşturma hatası: " + ex); }
        }

        private static void EnsureTab()
        {
            RibbonControl ribbon = ComponentManager.Ribbon;
            if (ribbon == null) return;

            foreach (RibbonTab existing in ribbon.Tabs)
                if (String.Equals(existing.Id, TabId, StringComparison.Ordinal)) return;

            var tab = new RibbonTab { Id = TabId, Title = "POLİGON HESAP" };
            var panelSource = new RibbonPanelSource { Title = "Poligon Hesabı" };
            var panel = new RibbonPanel { Source = panelSource };
            panelSource.Items.Add(new RibbonButton
            {
                Id = "PH_POLIGON_HESABI",
                Name = "PH_POLIGON_HESABI",
                Text = "Poligon Hesabı",
                ShowText = true,
                ShowImage = true,
                Size = RibbonItemSize.Large,
                LargeImage = PoligonIcon,
                CommandParameter = "POLHESAP",
                CommandHandler = CommandHandler,
                ToolTip = "Poligon Hesabı formunu açar."
            });

            tab.Panels.Add(panel);
            ribbon.Tabs.Add(tab);
            tab.IsActive = true;
        }

        private static ImageSource CreatePoligonIcon()
        {
            var group = new DrawingGroup();
            var background = new RectangleGeometry(new Rect(1.0, 1.0, 30.0, 30.0), 5.0, 5.0);
            group.Children.Add(new GeometryDrawing(
                new SolidColorBrush(Color.FromRgb(28, 43, 62)),
                new Pen(new SolidColorBrush(Color.FromRgb(65, 88, 112)), 1.0),
                background));

            var route = new StreamGeometry();
            using (StreamGeometryContext ctx = route.Open())
            {
                ctx.BeginFigure(new Point(6.0, 23.0), false, false);
                ctx.PolyLineTo(new PointCollection
                {
                    new Point(11.0, 15.0), new Point(16.0, 18.0),
                    new Point(22.0, 8.0), new Point(27.0, 12.0)
                }, true, true);
            }
            route.Freeze();
            group.Children.Add(new GeometryDrawing(null,
                new Pen(new SolidColorBrush(Color.FromRgb(76, 201, 240)), 2.4), route));

            Point[] stations = { new Point(6.0, 23.0), new Point(11.0, 15.0), new Point(16.0, 18.0), new Point(22.0, 8.0), new Point(27.0, 12.0) };
            for (int i = 0; i < stations.Length; i++)
            {
                var marker = new EllipseGeometry(stations[i], 2.0, 2.0);
                var fill = new SolidColorBrush(i == 0 || i == stations.Length - 1 ? Color.FromRgb(255, 193, 7) : Color.FromRgb(245, 248, 250));
                group.Children.Add(new GeometryDrawing(fill, new Pen(new SolidColorBrush(Color.FromRgb(28, 43, 62)), 0.7), marker));
            }

            var image = new DrawingImage(group);
            if (image.CanFreeze) image.Freeze();
            return image;
        }

        private sealed class AutoCadRibbonCommandHandler : ICommand
        {
            public event EventHandler CanExecuteChanged { add { } remove { } }

            public bool CanExecute(object parameter) { return parameter is RibbonButton; }

            public void Execute(object parameter)
            {
                RibbonButton button = parameter as RibbonButton;
                if (button == null) return;
                string command = Convert.ToString(button.CommandParameter);
                if (String.IsNullOrWhiteSpace(command)) return;

                Document doc = AcadApp.DocumentManager.MdiActiveDocument;
                if (doc == null)
                {
                    AcadApp.ShowAlertDialog("Önce bir AutoCAD çizimi açın.");
                    return;
                }

                doc.SendStringToExecute("\u0003\u0003" + command + " ", true, false, true);
            }
        }
    }
}
