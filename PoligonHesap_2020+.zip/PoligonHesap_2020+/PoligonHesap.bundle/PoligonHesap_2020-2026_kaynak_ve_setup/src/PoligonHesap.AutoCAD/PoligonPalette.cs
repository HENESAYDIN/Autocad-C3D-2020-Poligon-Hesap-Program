using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Autodesk.AutoCAD.ApplicationServices;
using PoligonHesap.Core;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace PoligonHesap.AutoCAD
{
    // The legacy UserForm is the primary workflow; it is intentionally not a dockable palette.
    internal sealed class PoligonPalette : Form
    {
        private readonly RadioButton _dayali = new RadioButton();
        private readonly RadioButton _acik = new RadioButton();
        private readonly RadioButton _kapali = new RadioButton();
        private readonly RadioButton _mm = new RadioButton();
        private readonly RadioButton _cm = new RadioButton();
        private readonly RadioButton _rightTurn = new RadioButton();
        private readonly RadioButton _leftTurn = new RadioButton();
        private readonly TextBox _city = new TextBox();
        private readonly TextBox _routeNo = new TextBox();
        private readonly TextBox _operator = new TextBox();
        private readonly DateTimePicker _date = new DateTimePicker();
        private readonly TextBox _back = new TextBox();
        private readonly TextBox _start = new TextBox();
        private readonly TextBox _end = new TextBox();
        private readonly TextBox _forward = new TextBox();
        private readonly TextBox _newEnd = new TextBox();
        private readonly Label _pointPath = new Label();
        private readonly Label _rasatPath = new Label();
        private readonly Label _summaryPath = new Label();
        private readonly Label _status = new Label();
        private readonly DataGridView _controls = new DataGridView();
        private readonly DataGridView _rasat = new DataGridView();
        private readonly DataGridView _observations = new DataGridView();
        private readonly DataGridView _results = new DataGridView();
        private readonly TabControl _dataTabs = new TabControl();
        private readonly ToolTip _toolTip = new ToolTip();
        private readonly List<RawRasatObservation> _rawObservations = new List<RawRasatObservation>();
        private string _coordinateFile;
        private string _outputDirectory;
        private string _xlsxPath;
        private string _dxfPath;
        private LegacyReportSet _reports;
        private TraverseResult _lastResult;
        private bool _preferSummaryRoute;

        public PoligonPalette()
        {
            Text = "Poligon Hesabı";
            Width = 1400;
            Height = 900;
            MinimumSize = new Size(1120, 760);
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            Font = new Font("Arial", 10.0f, FontStyle.Regular);
            AutoScaleMode = AutoScaleMode.Font;
            BuildUi();
            UpdateModeControls();
        }

        private void BuildUi()
        {
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 8, Padding = new Padding(10) };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 68));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 82));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 76));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            Controls.Add(root);

            var banner = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(38, 58, 83), Padding = new Padding(9, 3, 8, 3) };
            banner.Controls.Add(new Label { Dock = DockStyle.Left, Width = 320, Text = "POLİGON HESABI", ForeColor = Color.White, Font = new Font(Font, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft });
            banner.Controls.Add(new Label { Dock = DockStyle.Right, Width = 290, Text = "AutoCAD / Civil 3D  |  Poligon Hesabı", ForeColor = Color.Gainsboro, TextAlign = ContentAlignment.MiddleRight });
            root.Controls.Add(banner, 0, 0);

            root.Controls.Add(BuildMetadata(), 0, 1);
            root.Controls.Add(BuildOptions(), 0, 2);
            root.Controls.Add(BuildRoutePanel(), 0, 3);
            root.Controls.Add(BuildFilePanel(), 0, 4);
            root.Controls.Add(BuildDataTabs(), 0, 5);
            root.Controls.Add(BuildActions(), 0, 6);
            _status.Dock = DockStyle.Fill;
            _status.BorderStyle = BorderStyle.Fixed3D;
            _status.TextAlign = ContentAlignment.MiddleLeft;
            _status.Padding = new Padding(8, 3, 8, 3);
            _status.AutoEllipsis = false;
            _status.Text = "Nokta koordinatlarını ve Rasat/Özet girdisini yükleyin; güzergâhı kontrol edip hesaplayın.";
            root.Controls.Add(_status, 0, 7);
        }

        private Control BuildMetadata()
        {
            var group = new GroupBox { Text = "Proje bilgileri", Dock = DockStyle.Fill, Padding = new Padding(8, 3, 8, 4) };
            var row = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 8, RowCount = 1, Padding = new Padding(4, 3, 4, 1) };
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 118)); row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 102)); row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112)); row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 52)); row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            AddField(row, 0, "Şehir/Kasaba", _city);
            AddField(row, 2, "Güzergâh No", _routeNo); _routeNo.Text = "1";
            AddField(row, 4, "Hesabı Yapan", _operator); _operator.Text = Environment.MachineName;
            _date.Format = DateTimePickerFormat.Short; _date.Dock = DockStyle.Fill;
            AddField(row, 6, "Tarih", _date);
            group.Controls.Add(row);
            return group;
        }

        private Control BuildOptions()
        {
            var outer = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1 };
            outer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34));
            outer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            outer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 36));
            var mode = new GroupBox { Text = "Poligon türü", Dock = DockStyle.Fill };
            var modes = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Padding = new Padding(8, 7, 2, 0) };
            _dayali.Text = "Dayalı"; _dayali.Checked = true; _dayali.AutoSize = true;
            _acik.Text = "Açık"; _acik.AutoSize = true;
            _kapali.Text = "Kapalı"; _kapali.AutoSize = true;
            _dayali.CheckedChanged += ModeChanged; _acik.CheckedChanged += ModeChanged; _kapali.CheckedChanged += ModeChanged;
            modes.Controls.Add(_dayali); modes.Controls.Add(_acik); modes.Controls.Add(_kapali); mode.Controls.Add(modes);
            var precision = new GroupBox { Text = "Koordinat hassasiyeti", Dock = DockStyle.Fill };
            var precisions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Padding = new Padding(8, 7, 2, 0) };
            _mm.Text = "mm (3 hane)"; _mm.Checked = true; _mm.AutoSize = true;
            _cm.Text = "cm (2 hane)"; _cm.AutoSize = true;
            precisions.Controls.Add(_mm); precisions.Controls.Add(_cm); precision.Controls.Add(precisions);
            var direction = new GroupBox { Text = "Açı yönü", Dock = DockStyle.Fill };
            var directions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Padding = new Padding(8, 7, 2, 0) };
            _rightTurn.Text = "Sağ dönüş"; _rightTurn.Checked = true; _rightTurn.AutoSize = true;
            _leftTurn.Text = "Sol dönüş"; _leftTurn.AutoSize = true;
            directions.Controls.Add(_rightTurn); directions.Controls.Add(_leftTurn); direction.Controls.Add(directions);
            outer.Controls.Add(mode, 0, 0); outer.Controls.Add(precision, 1, 0); outer.Controls.Add(direction, 2, 0);
            return outer;
        }

        private Control BuildRoutePanel()
        {
            var group = new GroupBox { Text = "Güzergâh ve dayanaklar", Dock = DockStyle.Fill, Padding = new Padding(7, 2, 7, 5) };
            var row = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 10, RowCount = 1, Padding = new Padding(4, 4, 4, 1) };
            for (int i = 0; i < 5; i++) { row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, i == 4 ? 98 : 118)); row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20)); }
            AddField(row, 0, "Semt Alınan", _back);
            AddField(row, 2, "Başlangıç", _start);
            AddField(row, 4, "Son", _end);
            AddField(row, 6, "Semt Kapanan", _forward);
            AddField(row, 8, "Açık Son Adı", _newEnd);
            group.Controls.Add(row);
            return group;
        }

        private Control BuildFilePanel()
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1, Padding = new Padding(0, 1, 0, 1) };
            for (int i = 0; i < 3; i++) panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
            panel.Controls.Add(FileChoice("Nokta Koordinatları", "Nokta Al…", _pointPath, LoadPoints), 0, 0);
            panel.Controls.Add(FileChoice("Rasat Karnesi", "Rasat Al…", _rasatPath, LoadRasat), 1, 0);
            panel.Controls.Add(FileChoice("Özet Karne", "Özet Al…", _summaryPath, LoadSummary), 2, 0);
            return panel;
        }

        private Control FileChoice(string title, string buttonText, Label pathLabel, EventHandler click)
        {
            var group = new GroupBox { Text = title, Dock = DockStyle.Fill, Padding = new Padding(5, 1, 5, 2) };
            var row = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(3, 3, 3, 2) };
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 105)); row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            var button = new Button { Text = buttonText, Dock = DockStyle.Fill, Height = 34, Margin = new Padding(3) };
            button.Click += click;
            _toolTip.SetToolTip(button, title + " dosyasını seçip ilgili tabloya yükler.");
            pathLabel.Dock = DockStyle.Fill; pathLabel.AutoEllipsis = true; pathLabel.TextAlign = ContentAlignment.MiddleLeft; pathLabel.ForeColor = Color.DimGray; pathLabel.Padding = new Padding(5, 0, 3, 0);
            row.Controls.Add(button, 0, 0); row.Controls.Add(pathLabel, 1, 0); group.Controls.Add(row);
            return group;
        }

        private Control BuildDataTabs()
        {
            _dataTabs.Dock = DockStyle.Fill;
            _dataTabs.TabPages.Add(CreateGridPage("Nokta Koordinatları", _controls));
            _dataTabs.TabPages.Add(CreateGridPage("Rasat Ölçüleri", _rasat));
            _dataTabs.TabPages.Add(CreateGridPage("Özet / Güzergâh", _observations));
            _dataTabs.TabPages.Add(CreateGridPage("Hesaplanan Noktalar", _results));
            ConfigureGrid(_controls); AddColumn(_controls, "Name", "Nokta", 120); AddColumn(_controls, "Y", "Y / Doğu (m)", 150); AddColumn(_controls, "X", "X / Kuzey (m)", 150); AddColumn(_controls, "Z", "Kot (m)", 100);
            ConfigureGrid(_rasat); AddColumn(_rasat, "Station", "İstasyon", 120); AddColumn(_rasat, "Target", "Hedef", 120); AddColumn(_rasat, "F1", "Yüz I (gon)", 130); AddColumn(_rasat, "F2", "Yüz II (gon)", 130); AddColumn(_rasat, "Distance", "Yatay Kenar (m)", 150);
            ConfigureGrid(_observations); AddColumn(_observations, "Station", "İstasyon", 150); AddColumn(_observations, "Angle", "Açı (gon)", 150); AddColumn(_observations, "Distance", "Kenar (m)", 150);
            _observations.CellBeginEdit += delegate { _preferSummaryRoute = true; };
            ConfigureGrid(_results); AddColumn(_results, "Station", "Nokta", 150); AddColumn(_results, "Y", "Y / Doğu (m)", 170); AddColumn(_results, "X", "X / Kuzey (m)", 170); AddColumn(_results, "Bearing", "Semt (gon)", 150);
            return _dataTabs;
        }

        private TabPage CreateGridPage(string title, DataGridView grid)
        {
            var page = new TabPage(title); page.Controls.Add(grid); return page;
        }

        private Control BuildActions()
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(2, 2, 2, 0) };
            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var row = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Padding = new Padding(2, 3, 0, 0), AutoScroll = true };
            row.Controls.Add(ActionButton("Güzergâh Kur", BuildRoute));
            row.Controls.Add(ActionButton("Veri Kontrolü", CheckData));
            row.Controls.Add(ActionButton("Hesapla", Calculate, true));
            row.Controls.Add(ActionButton("Hesap Raporu", OpenReports));
            row.Controls.Add(ActionButton("Excel'i Aç", OpenWorkbook));
            row.Controls.Add(ActionButton("AutoCAD'e Çiz", DrawInCad));
            row.Controls.Add(ActionButton("Çıktı Klasörü", OpenOutputFolder));
            row.Controls.Add(ActionButton("Kapat", delegate { Close(); }));
            var help = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, ForeColor = Color.FromArgb(75, 75, 75), Text = "İşlem sırası: Nokta koordinatı yükle → Rasat veya Özet yükle → güzergâh/dayanakları kontrol et → Hesapla. Kanava çiziminde hesap tablosu isteğe bağlıdır." };
            panel.Controls.Add(row, 0, 0); panel.Controls.Add(help, 0, 1);
            return panel;
        }

        private Button ActionButton(string text, EventHandler click, bool primary = false)
        {
            var b = new Button { Text = text, AutoSize = true, Height = 36, MinimumSize = new Size(100, 34), Margin = new Padding(4, 0, 4, 0), Padding = new Padding(7, 2, 7, 2), Font = new Font(Font, primary ? FontStyle.Bold : FontStyle.Regular) };
            if (primary) { b.BackColor = Color.FromArgb(38, 93, 148); b.ForeColor = Color.White; b.FlatStyle = FlatStyle.Flat; }
            _toolTip.SetToolTip(b, ActionDescription(text));
            b.Click += click; return b;
        }

        private static string ActionDescription(string text)
        {
            if (text == "Güzergâh Kur") return "Özet Karne yüklüyse mevcut satırları kullanır; yoksa Rasat ölçülerinden güzergâh zinciri kurar.";
            if (text == "Veri Kontrolü") return "Koordinat, açı/kenar ve dayanak alanlarının tutarlılığını kontrol eder.";
            if (text == "Hesapla") return "Seçilen poligon türünü hesaplar ve rapor/Excel/DXF çıktıları üretir.";
            if (text == "AutoCAD'e Çiz") return "Önce kanavayı çizer; sonra hesap tablosu ekleme ve yer seçimini sorar.";
            if (text == "Hesap Raporu") return "Hesap, açı, kenar ve koordinat raporlarını açar.";
            if (text == "Excel'i Aç") return "Biçimli Excel hesap karnesini açar.";
            if (text == "Çıktı Klasörü") return "Oluşturulan TXT, XLSX, CSV ve DXF dosyalarının klasörünü açar.";
            return "Poligon Hesabı penceresini kapatır.";
        }

        private static void AddField(TableLayoutPanel row, int column, string title, Control editor)
        {
            var label = new Label { Text = title, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true };
            editor.Dock = DockStyle.Fill; editor.Margin = new Padding(2, 4, 8, 3);
            row.Controls.Add(label, column, 0); row.Controls.Add(editor, column + 1, 0);
        }

        private static void ConfigureGrid(DataGridView grid)
        {
            grid.Dock = DockStyle.Fill;
            grid.AllowUserToAddRows = true; grid.AllowUserToDeleteRows = true;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.RowHeadersVisible = false; grid.SelectionMode = DataGridViewSelectionMode.CellSelect;
            grid.BackgroundColor = SystemColors.Window; grid.MultiSelect = false;
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(245, 248, 251);
        }

        private static void AddColumn(DataGridView grid, string name, string title, int width)
        {
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = name, HeaderText = title, Width = width, SortMode = DataGridViewColumnSortMode.NotSortable });
        }

        private void ModeChanged(object sender, EventArgs e) { UpdateModeControls(); }
        private void UpdateModeControls()
        {
            bool open = _acik.Checked;
            _end.Enabled = !open; _forward.Enabled = !open; _newEnd.Enabled = open;
        }

        private TraverseMode SelectedMode()
        {
            return _acik.Checked ? TraverseMode.Acik : (_kapali.Checked ? TraverseMode.Kapali : TraverseMode.Dayali);
        }

        private void LoadPoints(object sender, EventArgs e)
        {
            using (var dialog = new OpenFileDialog { Filter = "Koordinatlar (*.ncn;*.txt;*.csv;*.xls;*.xlsx)|*.ncn;*.txt;*.csv;*.xls;*.xlsx|Tüm dosyalar (*.*)|*.*" })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    var points = SurveyTextReader.ReadControlPoints(dialog.FileName);
                    _controls.Rows.Clear(); foreach (var p in points) _controls.Rows.Add(p.Name, F(p.Y), F(p.X), F(p.Z));
                    _coordinateFile = dialog.FileName; _pointPath.Text = Path.GetFileName(dialog.FileName);
                    _status.Text = Path.GetFileName(dialog.FileName) + " yüklendi: " + points.Count + " nokta.";
                }
                catch (Exception ex) { ShowError("Nokta koordinatları", ex); }
            }
        }

        private void LoadRasat(object sender, EventArgs e)
        {
            using (var dialog = new OpenFileDialog { Filter = "Rasat dosyaları (*.txt;*.csv;*.xls;*.xlsx)|*.txt;*.csv;*.xls;*.xlsx|Tüm dosyalar (*.*)|*.*" })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    _rawObservations.Clear(); _rawObservations.AddRange(SurveyTextReader.ReadRasat(dialog.FileName));
                    _preferSummaryRoute = false;
                    _rasat.Rows.Clear();
                    foreach (var r in _rawObservations) _rasat.Rows.Add(r.StationName, r.TargetName, F(r.Face1Gon), F(r.Face2Gon), F(r.DistanceM));
                    _rasatPath.Text = Path.GetFileName(dialog.FileName);
                    _status.Text = Path.GetFileName(dialog.FileName) + " yüklendi: " + _rawObservations.Count + " yön/kenar satırı. Dayalı modda dayanak alanlarını doldurup Güzergâh Kur'a basın.";
                    _dataTabs.SelectedIndex = 1;
                }
                catch (Exception ex) { ShowError("Rasat karnesi", ex); }
            }
        }

        private void LoadSummary(object sender, EventArgs e)
        {
            using (var dialog = new OpenFileDialog { Filter = "Özet karne (*.txt;*.csv;*.xls;*.xlsx)|*.txt;*.csv;*.xls;*.xlsx|Tüm dosyalar (*.*)|*.*" })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    var rows = SurveyTextReader.ReadSummary(dialog.FileName);
                    _preferSummaryRoute = true;
                    _observations.Rows.Clear(); foreach (var o in rows) _observations.Rows.Add(o.StationName, F(o.AngleGon), o.DistanceM > 0 ? F(o.DistanceM) : String.Empty);
                    if (String.IsNullOrWhiteSpace(_start.Text) && rows.Count > 0) _start.Text = rows[0].StationName;
                    if (String.IsNullOrWhiteSpace(_end.Text) && rows.Count > 0 && !_acik.Checked) _end.Text = rows[rows.Count - 1].StationName;
                    _summaryPath.Text = Path.GetFileName(dialog.FileName);
                    _status.Text = Path.GetFileName(dialog.FileName) + " yüklendi: " + rows.Count + " açı/kenar satırı.";
                    _dataTabs.SelectedIndex = 2;
                }
                catch (Exception ex) { ShowError("Özet karne", ex); }
            }
        }

        private void BuildRoute(object sender, EventArgs e)
        {
            try
            {
                var summaryRows = ReadSummaryGrid();
                _rawObservations.Clear(); _rawObservations.AddRange(ReadRasatGrid());
                if (_preferSummaryRoute || (_rawObservations.Count == 0 && summaryRows.Count > 0))
                {
                    var existing = SurveyTextReader.ResolveRouteObservations(summaryRows, _rawObservations, _back.Text, _start.Text, _end.Text, _forward.Text, true);
                    _status.Text = "Özet Karne güzergâhı hazır: " + existing.Count + " açı/kenar satırı. Bu işlem için Rasat Karnesi gerekmez.";
                    _dataTabs.SelectedIndex = 2;
                    return;
                }
                if (_acik.Checked)
                {
                    if (summaryRows.Count > 0)
                    {
                        _preferSummaryRoute = true;
                        _status.Text = "Açık poligon Özet Karne güzergâhı hazır: " + summaryRows.Count + " satır. Rasat dosyası gerekmez.";
                        _dataTabs.SelectedIndex = 2;
                        return;
                    }
                    throw new InvalidOperationException("Açık poligon için Özet Karne yükleyin; Rasat'tan otomatik güzergâh kurma bu modda kullanılmaz.");
                }
                var observations = SurveyTextReader.ResolveRouteObservations(summaryRows, _rawObservations, _back.Text, _start.Text, _end.Text, _forward.Text, false);
                _observations.Rows.Clear(); foreach (var o in observations) _observations.Rows.Add(o.StationName, F(o.AngleGon), o.DistanceM > 0 ? F(o.DistanceM) : String.Empty);
                _preferSummaryRoute = false;
                _summaryPath.Text = "Rasat'tan kuruldu";
                _status.Text = "Güzergâh kuruldu: " + observations.Count + " istasyon; son kontrol açısı dahil edildi.";
                _dataTabs.SelectedIndex = 2;
            }
            catch (Exception ex) { ShowError("Güzergâh kurma", ex); }
        }

        private void CheckData(object sender, EventArgs e)
        {
            try
            {
                var input = ReadInput();
                if (input.ControlPoints.Count == 0) throw new InvalidOperationException("Nokta koordinatı yüklenmedi.");
                if (input.Observations.Count == 0) throw new InvalidOperationException("Özet Karne veya Rasat'tan kurulmuş güzergâh yok.");
                input.ValidateCommon();
                if (SelectedMode() != TraverseMode.Acik)
                {
                    input.RequirePoint(input.EndName, "Son"); input.RequirePoint(input.ForwardReferenceName, "Semt Kapanan");
                }
                _status.Text = "Veri kontrolü tamam: " + input.ControlPoints.Count + " koordinat, " + input.Observations.Count + " açı/kenar satırı.";
                MessageBox.Show(this, _status.Text, "Veri Kontrolü", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { ShowError("Veri kontrolü", ex); }
        }

        private void Calculate(object sender, EventArgs e)
        {
            try
            {
                if (_observations.Rows.Cast<DataGridViewRow>().All(r => r.IsNewRow) && _rawObservations.Count > 0 && !_acik.Checked)
                {
                    BuildRoute(null, EventArgs.Empty);
                    if (_observations.Rows.Cast<DataGridViewRow>().All(r => r.IsNewRow)) return;
                }
                var input = ReadInput();
                TraverseMode mode = SelectedMode();
                TraverseResult result = mode == TraverseMode.Acik ? TraverseCalculators.CalculateOpen(input) : (mode == TraverseMode.Kapali ? TraverseCalculators.CalculateClosed(input) : TraverseCalculators.CalculateDayali(input));
                _lastResult = result;
                PluginEntry.LatestInput = input; PluginEntry.LatestResult = result;
                PopulateResults(result);
                GenerateOutputs(input, result);
                _dataTabs.SelectedIndex = 3;
                _status.Text = BuildStatus(result) + " Çıktılar: " + _outputDirectory;
                OpenReportWindow();
            }
            catch (Exception ex) { ShowError("Hesaplama", ex); _status.Text = "Hesap yapılamadı: " + ex.Message; }
        }

        private void GenerateOutputs(TraverseInput input, TraverseResult result)
        {
            string root = !String.IsNullOrWhiteSpace(_coordinateFile) ? Path.GetDirectoryName(_coordinateFile) : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "PoligonHesap");
            string modeFolder = result.Mode == TraverseMode.Dayali ? "dayalı pol" : (result.Mode == TraverseMode.Acik ? "açık pol" : "kapalı pol");
            _outputDirectory = Path.Combine(root, "Özet Karne Çıktı", modeFolder);
            Directory.CreateDirectory(_outputDirectory);
            string stem = ReportWriter.SafeFileStem(input.RouteNumber);
            _xlsxPath = Path.Combine(_outputDirectory, result.Mode == TraverseMode.Acik ? "AcikPoligon_" + stem + ".xlsx" : "PoligonHesap_" + stem + ".xlsx");
            _dxfPath = Path.Combine(_outputDirectory, "PoligonKanava_" + stem + ".dxf");
            _reports = ReportWriter.WriteLegacySet(_outputDirectory, input, result);
            XlsxWriter.Write(_xlsxPath, input, result);
            _dxfPath = AutoCadDxfExporter.Write(_dxfPath, input, result);
        }

        private TraverseInput ReadInput()
        {
            var input = new TraverseInput
            {
                BackReferenceName = _back.Text.Trim(), StartName = _start.Text.Trim(),
                EndName = _acik.Checked ? null : _end.Text.Trim(), ForwardReferenceName = _acik.Checked ? null : _forward.Text.Trim(),
                NewEndName = _newEnd.Text.Trim(), CityName = _city.Text.Trim(), RouteNumber = _routeNo.Text.Trim(),
                OperatorName = _operator.Text.Trim(), CalculationDate = _date.Value.Date,
                Precision = _cm.Checked ? CoordinatePrecision.Centimeter : CoordinatePrecision.Millimeter,
                TurnDirection = _leftTurn.Checked ? -1 : 1,
                ObservationsFromRasat = !_preferSummaryRoute && _rawObservations.Count > 0
            };
            foreach (DataGridViewRow row in _controls.Rows)
            {
                if (row.IsNewRow) continue;
                string name = CellText(row.Cells["Name"].Value); if (String.IsNullOrWhiteSpace(name)) continue;
                input.ControlPoints.Add(new SurveyPoint(name.Trim(), Number(row.Cells["Y"].Value), Number(row.Cells["X"].Value), Number(row.Cells["Z"].Value)));
            }
            input.Observations.AddRange(ReadSummaryGrid());
            input.RawRasatObservations.AddRange(ReadRasatGrid());
            return input;
        }

        private List<TraverseObservation> ReadSummaryGrid()
        {
            var observations = new List<TraverseObservation>();
            foreach (DataGridViewRow row in _observations.Rows)
            {
                if (row.IsNewRow) continue;
                string station = CellText(row.Cells["Station"].Value);
                if (String.IsNullOrWhiteSpace(station)) continue;
                observations.Add(new TraverseObservation(station, Number(row.Cells["Angle"].Value), Number(row.Cells["Distance"].Value)));
            }
            return observations;
        }

        private List<RawRasatObservation> ReadRasatGrid()
        {
            var observations = new List<RawRasatObservation>();
            foreach (DataGridViewRow row in _rasat.Rows)
            {
                if (row.IsNewRow) continue;
                string station = CellText(row.Cells["Station"].Value);
                if (String.IsNullOrWhiteSpace(station)) continue;
                string target = CellText(row.Cells["Target"].Value);
                if (String.IsNullOrWhiteSpace(target)) throw new FormatException("Rasat satırında hedef nokta adı eksik.");
                observations.Add(new RawRasatObservation
                {
                    StationName = station,
                    TargetName = target,
                    Face1Gon = GonMath.Normalize(Number(row.Cells["F1"].Value)),
                    Face2Gon = GonMath.Normalize(Number(row.Cells["F2"].Value)),
                    DistanceM = Number(row.Cells["Distance"].Value)
                });
            }
            return observations;
        }

        private void PopulateResults(TraverseResult result)
        {
            _results.Rows.Clear();
            foreach (var point in result.Points)
            {
                var leg = result.Legs.FirstOrDefault(l => TraverseInput.NormalizeName(l.ToName) == TraverseInput.NormalizeName(point.Name));
                _results.Rows.Add(point.Name, F(point.Y), F(point.X), leg == null ? String.Empty : F(leg.BearingGon));
            }
        }

        private static string BuildStatus(TraverseResult result)
        {
            if (!result.HasKnownEnd) return "Açık poligon: " + result.Points.Count + " nokta hesaplandı; yeni uç " + result.Points[result.Points.Count - 1].Name + ". Kapanma kontrolü uygulanmaz.";
            return ReportWriter.ModeName(result.Mode) + ": FB=" + F(result.AngularMisclosureGon * 10000.0, 0) + " cc / sınır " + F(result.AngularToleranceGon * 10000.0, 0) + " cc; Fs=" + F(result.Fs, 3) + " m. Açı " + (result.AngularTolerancePassed ? "uygun" : "tolerans dışı") + ", koordinat " + (result.CoordinateTolerancePassed ? "uygun" : "tolerans dışı") + ".";
        }

        private void OpenReports(object sender, EventArgs e)
        {
            if (_reports == null) { MessageBox.Show(this, "Önce hesap yapın; rapor dosyaları otomatik üretilir.", "Hesap Raporu", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            OpenReportWindow();
        }

        private void OpenReportWindow()
        {
            if (_reports == null) return;
            var viewer = new ReportViewer(_reports, _xlsxPath, _dxfPath);
            viewer.Show(this);
        }

        private void OpenWorkbook(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(_xlsxPath) || !File.Exists(_xlsxPath)) { MessageBox.Show(this, "Önce hesaplama yapın.", "Excel", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            StartLocalFile(_xlsxPath);
        }

        private void DrawInCad(object sender, EventArgs e)
        {
            if (_lastResult == null) { MessageBox.Show(this, "Önce hesaplama yapın.", "AutoCAD'e Çiz", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            if (doc == null) { MessageBox.Show(this, "Açık AutoCAD çizimi bulunamadı.", "AutoCAD'e Çiz", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            doc.SendStringToExecute("POLHESAP_CIZ\n", true, false, false);
        }

        private void OpenOutputFolder(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(_outputDirectory) || !Directory.Exists(_outputDirectory)) { MessageBox.Show(this, "Önce hesaplama yapın.", "Çıktı Klasörü", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + _outputDirectory + "\"") { UseShellExecute = true }); }
            catch (Exception ex) { ShowError("Çıktı klasörü", ex); }
        }

        private static void StartLocalFile(string path)
        {
            Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }

        private void ShowError(string title, Exception ex)
        {
            MessageBox.Show(this, ex.Message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private static string CellText(object value) { return value == null ? String.Empty : Convert.ToString(value, CultureInfo.CurrentCulture).Trim(); }
        private static double Number(object value) { return String.IsNullOrWhiteSpace(CellText(value)) ? 0.0 : GonMath.ParseNumber(CellText(value)); }
        private static string F(double value) { return value.ToString("0.###", CultureInfo.InvariantCulture); }
        private static string F(double value, int digits) { return value.ToString("F" + digits, CultureInfo.InvariantCulture); }
    }

    internal sealed class ReportViewer : Form
    {
        private readonly LegacyReportSet _reports;
        private readonly string _xlsxPath;
        private readonly string _dxfPath;
        private readonly TabControl _tabs = new TabControl();

        public ReportViewer(LegacyReportSet reports, string xlsxPath, string dxfPath)
        {
            _reports = reports; _xlsxPath = xlsxPath; _dxfPath = dxfPath;
            Text = "Hesap Raporu"; Width = 900; Height = 620; MinimumSize = new Size(700, 450);
            StartPosition = FormStartPosition.CenterParent; Font = new Font("Segoe UI", 9.0f);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(7) };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40)); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(layout);
            var toolbar = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight };
            toolbar.Controls.Add(Button("Excel'i Aç", delegate { Open(_xlsxPath); }));
            toolbar.Controls.Add(Button("DXF Dosyasını Aç", delegate { Open(_dxfPath); }));
            toolbar.Controls.Add(Button("Çıktı Klasörü", delegate { OpenFolder(_reports.OutputDirectory); }));
            layout.Controls.Add(toolbar, 0, 0);
            _tabs.Dock = DockStyle.Fill;
            AddReportTab("Hesap Raporu", reports.CalculationPath);
            AddReportTab("Açı Raporu", reports.AnglePath);
            AddReportTab("Kenar Raporu", reports.EdgePath);
            AddReportTab("Koordinat Listesi", reports.CoordinatePath);
            layout.Controls.Add(_tabs, 0, 1);
        }

        private void AddReportTab(string title, string path)
        {
            var page = new TabPage(title);
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(5) };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 25)); layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            var pathLabel = new Label { Text = path, Dock = DockStyle.Fill, AutoEllipsis = true, ForeColor = Color.DimGray };
            var text = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, WordWrap = false, Font = new Font("Consolas", 9.0f) };
            text.Text = ReadText(path);
            layout.Controls.Add(pathLabel, 0, 0); layout.Controls.Add(text, 0, 1); page.Controls.Add(layout); _tabs.TabPages.Add(page);
            page.Enter += delegate { text.SelectionStart = 0; text.SelectionLength = 0; };
        }

        private static Button Button(string text, EventHandler handler)
        {
            var button = new Button { Text = text, AutoSize = true, Height = 29, Margin = new Padding(3) }; button.Click += handler; return button;
        }

        private static string ReadText(string path)
        {
            if (!File.Exists(path)) return "Rapor dosyası bulunamadı: " + path;
            try { return File.ReadAllText(path, Encoding.GetEncoding(1254)); }
            catch { return File.ReadAllText(path, Encoding.UTF8); }
        }

        private static void Open(string path)
        {
            if (String.IsNullOrWhiteSpace(path) || !File.Exists(path)) { MessageBox.Show("Dosya bulunamadı."); return; }
            Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }

        private static void OpenFolder(string path)
        {
            if (String.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) { MessageBox.Show("Çıktı klasörü bulunamadı."); return; }
            Process.Start(new ProcessStartInfo("explorer.exe", "\"" + path + "\"") { UseShellExecute = true });
        }
    }
}
