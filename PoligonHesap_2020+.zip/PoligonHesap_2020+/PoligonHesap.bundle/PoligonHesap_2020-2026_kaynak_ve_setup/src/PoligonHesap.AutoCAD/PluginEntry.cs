using System;
using System.Text;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using PoligonHesap.Core;
using AcadApp = Autodesk.AutoCAD.ApplicationServices.Application;

namespace PoligonHesap.AutoCAD
{
    public sealed class PluginEntry : IExtensionApplication
    {
        private static PoligonPalette _window;

        internal static TraverseInput LatestInput { get; set; }
        internal static TraverseResult LatestResult { get; set; }

        public void Initialize()
        {
#if NETCOREAPP
            // .NET 8/10 no longer register Windows code pages such as Turkish CP1254 by default.
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
#endif
            RibbonService.Initialize();
        }
        public void Terminate() { }

        [CommandMethod("POLHESAP")]
        public void ShowForm()
        {
            if (_window == null || _window.IsDisposed)
            {
                _window = new PoligonPalette();
                _window.FormClosed += delegate { _window = null; };
            }
            AcadApp.ShowModelessDialog(_window);
        }

        [CommandMethod("POLHESAP_CIZ")]
        public void DrawLatestResult()
        {
            Document doc = AcadApp.DocumentManager.MdiActiveDocument;
            if (doc == null)
            {
                AcadApp.ShowAlertDialog("Açık AutoCAD çizimi bulunamadı.");
                return;
            }
            if (LatestInput == null || LatestResult == null)
            {
                doc.Editor.WriteMessage("\nÖnce POLHESAP penceresinde hesap yapınız.");
                return;
            }
            try
            {
                using (doc.LockDocument()) DrawingService.Draw(doc.Database, LatestInput, LatestResult);
                doc.Editor.Command("_.ZOOM", "_E");
                var options = new PromptKeywordOptions("\nPoligon Hesap Tablosu kanavaya çizilsin mi? [Evet/Hayır] <Hayır>: ");
                options.Keywords.Add("Evet");
                options.Keywords.Add("Hayır");
                options.AllowNone = true;
                PromptResult answer = doc.Editor.GetKeywords(options);
                bool drawTable = answer.Status == PromptStatus.OK && String.Equals(answer.StringResult, "Evet", StringComparison.OrdinalIgnoreCase);
                if (drawTable)
                {
                    var pointOptions = new PromptPointOptions("\nHesap tablosunun sol üst köşesini istediğiniz yere tıklayın: ");
                    PromptPointResult point = doc.Editor.GetPoint(pointOptions);
                    if (point.Status == PromptStatus.OK)
                    {
                        using (doc.LockDocument()) DrawingService.DrawCalculationTable(doc.Database, LatestInput, LatestResult, point.Value);
                        doc.Editor.Command("_.ZOOM", "_E");
                        doc.Editor.WriteMessage("\nPoligonHesap: kanava ve kullanıcı tarafından konumlandırılan hesap tablosu çizildi.");
                    }
                    else doc.Editor.WriteMessage("\nHesap tablosu eklenmedi; kanava çizimi tamamlandı.");
                }
                else doc.Editor.WriteMessage("\nPoligonHesap: kanava çizildi. Hesap tablosu eklenmedi.");
            }
            catch (System.Exception ex)
            {
                AcadApp.ShowAlertDialog("Poligon çizim hatası: " + ex.Message);
            }
        }
    }
}
