# Poligon Hesap — AutoCAD/Civil 3D 2018–2026 kaynak ve kurulum mimarisi

Bu kaynak ağacı 1.0.4’teki R12 DXF codepage/font düzeltmesini korur ve AutoCAD/Civil 3D 2018–2026 için **ürün ve runtime profiline göre ayrı derlenen** eklentiler üretir. Runtime yalnızca sürüm yılıyla belirlenmediğinden 2025/2026 profilleri ürün/update düzeyine göre ayrıdır.

2020–2024 için mevcut .NET Framework profilleri ve seçim kuralları değiştirilmemiştir. .NET 8/10 profillerinde paylaşılan framework'teki Türkçe CP1254 sağlayıcısı başlangıçta kaydedilir; bu, Windows-1254 kod sayfası bulunamadığına ilişkin 2026 hata ekranını giderir. Framework DLL'i eklenti bundle'ına kopyalanmaz. Ayrıntı: [`docs/NET8-NET10-CP1254-FIX.md`](docs/NET8-NET10-CP1254-FIX.md).

Bu teslimde kullanıcıdan gelen eski 2020–2024 bundle DLL'leri korunarak `dist/PoligonHesap_Setup.exe` içine kondu; AutoCAD 2025/2026 için net8/net10 bundle'ları eklendi. 2025 DLL'leri, ilgili 2026 runtime API referanslarıyla ayrı derlenmiştir; 2025 managed API referansları bulunmadığından gerçek host uyumluluğu garanti edilmez. Kurucu `BuildVer` eşiğine göre yalnızca doğru runtime paketini yükler. Eski bundle manifesti yalnız R23.1–R24.3'e sınırlandırıldı. Ayrıntı: [`installer/combined2020-2026/README.md`](installer/combined2020-2026/README.md). Civil 3D 2025/2026 bu özel kurucuya dahil değildir.

## Tek Setup.exe, update-aware kurulum

Windows build sonunda verilecek tek kurucu `dist/PoligonHesap_Setup.exe` olur. Kurucu, Autodesk Registry `ProductInfo` kayıtlarında release series ve update/build bilgisini denetler; yalnızca algılanan ürün/runtime profillerinin izole `.bundle` klasörlerini kurar. Update filtresi kurulum anında NSIS tarafından yapılır; AutoLoader’ın kendi `RuntimeRequirements` alanı minor update seçicisi olarak kullanılmaz.

| Host | Eklenti hedefi | Güncelleme koşulu |
|---|---|---|
| AutoCAD/Civil 3D 2018 | .NET Framework 4.6 | R22.0 |
| AutoCAD/Civil 3D 2019–2020 | .NET Framework 4.7 | R23.0 / R23.1 |
| AutoCAD/Civil 3D 2021–2024 | .NET Framework 4.8 | R24.0–R24.3 |
| AutoCAD 2025 | .NET 8 veya .NET 10 | .NET 8: Update 1.3’e kadar; .NET 10: 1.4+ |
| Civil 3D 2025 | .NET 8 | Şu an yayınlanmış/doğrulanmış build listesiyle sınırlı; Autodesk .NET 10 geçiş sınırını henüz yayımlamadı |
| AutoCAD 2026 | .NET 8 veya .NET 10 | .NET 8: Update 1.1’e kadar; .NET 10: 1.2+ |
| Civil 3D 2026 | .NET 8 veya .NET 10 | .NET 8: Update 2.2.1’e kadar; .NET 10: 2.2.2+ |

Matristeki profil ve installer seçim kuralları [`installer/supported-versions.json`](installer/supported-versions.json) içindedir. 2025/2026 ürünleri farklı runtime’larda kurulmuşsa installer her host için uygun paketi seçer; Autodesk’in ürün uyumluluğu uyarısı nedeniyle aynı release ailesindeki Autodesk ürünlerini de birbiriyle uyumlu update seviyelerinde tutun.

Kurucunun ürettiği paket yapısı:

```text
Autodesk/ApplicationPlugins/
├── PoligonHesap_2018.bundle/
├── ...
├── PoligonHesap_2025-autocad-net8.bundle/
├── PoligonHesap_2025-autocad-net10.bundle/
├── PoligonHesap_2025-civil3d-net8.bundle/
├── PoligonHesap_2026-autocad-net8.bundle/
├── PoligonHesap_2026-autocad-net10.bundle/
├── PoligonHesap_2026-civil3d-net8.bundle/
└── PoligonHesap_2026-civil3d-net10.bundle/
```

Her paket yalnız kendi `Series` ve host `Platform` değerine bağlanır. Autodesk managed API DLL’leri derleme referansıdır; kurucuya kopyalanmaz.

## Windows build

Tüm profile’ların **kendi ürün/update runtime’ına ait** `accoremgd.dll`, `acdbmgd.dll`, `acmgd.dll` ve `AdWindows.dll` referanslarına erişen Windows makinesi gerekir. Eski update SDK’sı son update ile aynı klasör değilse her biri için ayrı referans dizini gösterin.

1. `installer/autodesk-managed-paths.example.json` dosyasını `installer/autodesk-managed-paths.json` olarak kopyalayın ve her `managed_api_key` için doğru gerçek API dizinini girin. Örnek dosyadaki `SDKs/...` değerleri açıklayıcı yer tutucudur.
2. Visual Studio Build Tools/MSBuild, .NET 8 ve .NET 10 SDK’ları, gerekli .NET Framework targeting pack’leri, Python 3 ve NSIS kurulu olmalı.
3. `bash build-and-test.sh` portable çekirdek testlerini ve runtime profil karar testlerini çalıştırır.
4. Windows PowerShell’de `./Build-AutoCAD2018Plus.ps1` çalıştırın. Betik tüm 14 profili fail-fast derler, ayrı bundle’ları üretir, manifestleri doğrular ve tek Setup.exe oluşturur.

Bu teslimdeki birleşik 2020–2024 + AutoCAD 2025/2026 kurucusunu yeniden üretmek için Windows PowerShell'de `./Build-AutoCAD2020-2026.ps1 -ManagedApiPathNet8 "<2026 net8 API klasörü>" -ManagedApiPathNet10 "<2026 net10 API klasörü>"` çalıştırın. Eski 2020 DLL bundle'ı `installer/combined2020-2026/LegacyBundle` içinde sağlanır; 2025 profilleri de karşılık gelen 2026 API klasörünü kullanır.

Eksik bir profilin API referansı varsa işlem Setup.exe üretmeden durur; bir yılın DLL’i başka yıla/runtime’a kopyalanmaz. 2025 Civil 3D için şu an yalnız Autodesk’in yayınladığı ve matriste allowlist’e alınmış .NET 8 build’leri kabul edilir; tanınmayan/gelecekteki build’lerde yanlış runtime kurmamak için o host paketi atlanır.

## Doğrulama ve sınırlar

- Core regression suite: **73 assertion geçti**.
- Update/runtime seçim kuralları: **15 assertion geçti**.
- 14 profile için sentetik PE fixture’larıyla tam-matris staging ve NSIS smoke testi başarılıdır; sahte DLL/EXE dağıtım paketi olarak tutulmadı.
- Bu teslimdeki birleşik Setup, eski bundle içeriği ile AutoCAD 2025/2026 için dört net8/net10 derlemesini NSIS'e gömerek üretildi. Setup payload'i açılarak toplam 5 bundle, DLL imzaları (MZ) ve manifest sürüm aralıkları doğrulandı; 2025 `V.188` → net8 / `V.189+` → net10 ve 2026 `W.178` → net8 / `W.179+` → net10 seçimleri geçti.
- Sandbox Linux ortamında gerçek AutoCAD Windows hostu yok; dolayısıyla registry'nin canlı Windows makinesinde algılanması ve eklentinin CAD içinde açılış/hesap/DXF kabul testi yapılamadı. Tam 14 profilli 2018–2026 kurucusunun üretilmesi için tüm profile'ların doğru Autodesk managed API referansları gerekir.
- Autodesk registry `ProductInfo` alt anahtarlarının 2025/2026 ürünlerinde beklenen biçimde görünmesi ve gerçek BuildVer değerleri Windows host üzerinde test edilmelidir. Özellikle Civil 3D 2025 .NET 10 güncellemesi yayımlanınca matrix/detector yeniden kaynak doğrulamasıyla güncellenmelidir.

Ayrıntılı kaynaklı sürüm/runtime tablosu: [`docs/AUTOCAD-2018-2026-COMPATIBILITY.md`](docs/AUTOCAD-2018-2026-COMPATIBILITY.md). Önceki 1.0.4 DXF incelemesi: [`docs/AUTOCAD-DXF-DIAGNOSTIC.md`](docs/AUTOCAD-DXF-DIAGNOSTIC.md).
